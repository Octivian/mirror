// 第 0.5 步｜短链解析 + 身份指纹采集
// 为什么必须做：达人广场按昵称搜是模糊匹配（实测「小师妹」返回 1000 条），只取第一页会认错人；
// 而按「抖音号」搜精确返回 1 条。所以先把用户给的短链解析出 抖音号 + 真实昵称，
// 后面 01_collect 就能用抖音号精准定位，而不是靠昵称猜。
// 流程：短链 HTTP 302 解析出 sec_uid → 用浏览器渲染分享页 → 读真实昵称/抖音号/粉丝数
// 输出 links_resolved.json：[{ idx, nickname, homepage, secUid, linkNickname, linkUniqueId, linkFans, dupOf, err }]
import fs from 'node:fs';
import { log, sleep, parseTalents } from './lib/util.mjs';
import { CDP, evalJson } from './lib/cdp.mjs';

// 始终以 talents.txt 为唯一事实来源（talents.json 是 01_collect 的派生产物，可能过期）
const all = parseTalents(fs.readFileSync('talents.txt', 'utf8'));
const OUT = 'links_resolved.json';
const prev = fs.existsSync(OUT) ? JSON.parse(fs.readFileSync(OUT, 'utf8')) : [];
const done = new Map(prev.map(x => [x.idx, x]));

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36';
const SEC = /(?:sec_uid=|secUid=|sec_user_id=)(MS4w[A-Za-z0-9_-]+)/;
const USERPATH = /\/user\/(MS4w[A-Za-z0-9_-]+)/;

async function resolveShortUrl(url) {
  let cur = url;
  for (let i = 0; i < 6; i++) {
    const sec = (cur.match(SEC) || cur.match(USERPATH) || [])[1];
    if (sec) return { secUid: sec, finalUrl: cur };
    const r = await fetch(cur, { redirect: 'manual', headers: { 'user-agent': UA } });
    const loc = r.headers.get('location');
    if (!loc) {
      const sec2 = (cur.match(SEC) || cur.match(USERPATH) || [])[1] || null;
      return { secUid: sec2, finalUrl: cur, err: sec2 ? null : `HTTP ${r.status} 无跳转` };
    }
    cur = new URL(loc, cur).toString();
  }
  const sec = (cur.match(SEC) || cur.match(USERPATH) || [])[1] || null;
  return { secUid: sec, finalUrl: cur, err: sec ? null : '跳转超过 6 层仍未取到 sec_uid' };
}

// 从分享页渲染后的文本里取身份：昵称（「关注」前一行）+ 抖音号 + 粉丝数
function parseProfileText(text) {
  const lines = String(text || '').split('\n').map(s => s.trim()).filter(Boolean);
  const iId = lines.findIndex(l => /^抖音号[：:]/.test(l));
  let nickname = null, uniqueId = null, fans = null;
  if (iId >= 0) {
    uniqueId = lines[iId].replace(/^抖音号[：:]/, '').trim() || null;
    for (let i = iId; i >= 0; i--) {
      if (lines[i] === '关注') { nickname = lines[i - 1] || null; break; }
    }
  }
  const iFans = lines.findIndex(l => l === '粉丝');
  if (iFans >= 0 && /^[\d.]+\s*(万|亿)?$/.test(lines[iFans + 1] || '')) fans = lines[iFans + 1];
  const ip = (lines.find(l => /^IP属地[：:]/.test(l)) || '').replace(/^IP属地[：:]/, '').trim() || null;
  return { nickname, uniqueId, fans, ip };
}

// 浏览器连接（用于渲染分享页；不依赖达人广场标签）
let ctl = null, ctlTabUrl = null;
async function getCtl() {
  if (ctl) return ctl;
  const list = await (await fetch(`http://${process.env.CDP_HOST || '127.0.0.1'}:${process.env.CDP_PORT || 9222}/json/list`)).json();
  const tab = list.find(t => t.type === 'page' && /life\.douyin\.com|douyin\.com/.test(t.url)) || list.find(t => t.type === 'page');
  if (!tab) throw new Error('没有可用的浏览器标签页，请确认调试浏览器已启动');
  ctl = new CDP(tab.webSocketDebuggerUrl);
  await ctl.ready;
  ctlTabUrl = tab.url;
  return ctl;
}

async function readProfileByBrowser(secUid) {
  const c = await getCtl();
  const url = `https://www.iesdouyin.com/share/user/${secUid}`;
  const t = await c.send('Target.createTarget', { url: 'about:blank' });
  try {
    const info = await (await fetch(`http://${process.env.CDP_HOST || '127.0.0.1'}:${process.env.CDP_PORT || 9222}/json/list`)).json();
    const tab = info.find(x => x.id === t.targetId);
    if (!tab) throw new Error('新标签创建失败');
    const s = new CDP(tab.webSocketDebuggerUrl);
    await s.ready;
    await s.send('Page.enable');
    await s.send('Runtime.enable');
    await s.send('Page.navigate', { url });
    await sleep(Number(process.env.PROFILE_WAIT_MS || 4500));
    const d = await evalJson(s, `(() => ({ title: document.title, text: document.body.innerText || '' }))()`);
    s.close();
    const p = parseProfileText(d.text);
    return { ...p, pageTitle: d.title };
  } finally {
    try { await c.send('Target.closeTarget', { targetId: t.targetId }); } catch (_) {}
  }
}

let ok = 0, fail = 0;
for (const t of all) {
  if (!t.homepage) { done.set(t.idx, { ...t, secUid: null, err: '未提供链接' }); fail++; continue; }
  const cached = done.get(t.idx);
  if (cached?.secUid && cached?.linkUniqueId) { ok++; continue; }
  let rec = { idx: t.idx, nickname: t.nickname, homepage: t.homepage };
  try {
    const r = await resolveShortUrl(t.homepage);
    rec = { ...rec, ...r };
    if (r.secUid) {
      try {
        const p = await readProfileByBrowser(r.secUid);
        rec.linkNickname = p.nickname || null;
        rec.linkUniqueId = p.uniqueId || null;
        rec.linkFans = p.fans || null;
        rec.linkIp = p.ip || null;
      } catch (e) {
        rec.profileErr = e.message.slice(0, 100);
      }
    }
    if (rec.secUid) ok++; else fail++;
    log(`#${t.idx} 清单「${t.nickname}」-> 链接真实「${rec.linkNickname || '?'}」抖音号 ${rec.linkUniqueId || '?'} 粉 ${rec.linkFans || '?'}`);
  } catch (e) {
    rec.err = e.message.slice(0, 100); fail++;
    log(`#${t.idx} ${t.nickname} ✗ ${rec.err}`);
  }
  done.set(t.idx, rec);
  await sleep(300 + Math.random() * 400);
}

const out = [...done.values()].sort((a, b) => a.idx - b.idx);

// 查重：同一 sec_uid / 抖音号 出现在多行 → 说明清单里链接贴重了，必须报出来
const bySec = new Map(), byUid = new Map();
for (const r of out) {
  if (r.secUid) { if (!bySec.has(r.secUid)) bySec.set(r.secUid, []); bySec.get(r.secUid).push(r.idx); }
  if (r.linkUniqueId) { if (!byUid.has(r.linkUniqueId)) byUid.set(r.linkUniqueId, []); byUid.get(r.linkUniqueId).push(r.idx); }
}
for (const r of out) {
  r.dupOf = null;
  for (const m of [bySec, byUid]) {
    for (const [, idxs] of m) {
      if (idxs.length > 1 && idxs.includes(r.idx) && idxs[0] !== r.idx) r.dupOf = idxs[0];
    }
  }
}

fs.writeFileSync(OUT, JSON.stringify(out, null, 2), 'utf8');
log(`完成：解析成功 ${ok} / 失败 ${fail} -> ${OUT}`);
const noUid = out.filter(r => r.secUid && !r.linkUniqueId).map(r => `#${r.idx} ${r.nickname}`);
if (noUid.length) log(`⚠ 未取到抖音号（将回退昵称匹配）：${noUid.join('、')}`);
const dups = out.filter(r => r.dupOf);
if (dups.length) log(`⚠ 短链重复（同一账号被贴到多行）：${dups.map(r => `#${r.idx} ${r.nickname} 与 #${r.dupOf}`).join('、')}`);
const nameDiff = out.filter(r => r.linkUniqueId && r.linkNickname && r.linkNickname.replace(/\s/g, '') !== r.nickname.replace(/\s/g, '') && !r.linkNickname.includes(r.nickname));
if (nameDiff.length) log(`⚠ 清单名与链接真实昵称不一致：${nameDiff.map(r => `#${r.idx}「${r.nickname}」-> 「${r.linkNickname}」`).join('、')}`);
if (ctl) ctl.close();
