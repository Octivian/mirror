// 第 1 步｜批量采集（API 直采 + 抖音号精确匹配）
// 核心：优先用 00_resolve_links 解析出的「抖音号」搜达人广场 —— 实测抖音号搜索精确返回 1 条，
//       昵称搜索是模糊匹配（「小师妹」返回 1000 条），只取第一页必然认错人。
// 流程：POST talent_square/talent/search（body 顶层 keyword）→ talent_list 按 sec_uid/unique_id 核对
//       → 按 field_map.json 的 jsonPaths（相对达人对象）取 5 项指标。
// 链接重复（同一账号贴到多行）的条目直接剔除，不参与排名，单独写入 excluded.json 供人工补正。
// 用法：
//   node 01_collect.mjs                 全量采集
//   node 01_collect.mjs --only 3,7      只补采指定 idx（合并写回）
//   node 01_collect.mjs --no-reload     跳过启动 reload，直接用 field_map 的 searchUrl
import fs from 'node:fs';
import path from 'node:path';
import { connectTab, startCapture, pageSnapshot, fetchPostJson } from './lib/cdp.mjs';
import { log, sleep, parseTalents, deepFind, getByPath, parseMetric } from './lib/util.mjs';

const CFG = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const FM = JSON.parse(fs.readFileSync('field_map.json', 'utf8'));
const args = process.argv.slice(2);
const oi = args.indexOf('--only');
const only = oi >= 0 ? (args[oi + 1] || '').split(',').map(Number).filter(Boolean) : null;
const noReload = args.includes('--no-reload');

const all = parseTalents(fs.readFileSync('talents.txt', 'utf8'));
const resolved = fs.existsSync('links_resolved.json') ? JSON.parse(fs.readFileSync('links_resolved.json', 'utf8')) : [];
const resByIdx = new Map(resolved.map(r => [r.idx, r]));
for (const t of all) {
  const r = resByIdx.get(t.idx) || {};
  t.secUid = r.secUid || null;
  t.linkUniqueId = r.linkUniqueId || null;
  t.linkNickname = r.linkNickname || null;
  t.dupOf = r.dupOf || null;
}
fs.writeFileSync('talents.json', JSON.stringify(all, null, 2), 'utf8');

const excluded = all.filter(t => t.dupOf).map(t => ({
  idx: t.idx, nickname: t.nickname, dupOf: t.dupOf,
  reason: `短链与第 #${t.dupOf} 号达人相同（同一账号被贴到两行），无法确认该行真实身份，已剔除不参与排名`,
}));
if (excluded.length) fs.writeFileSync('excluded.json', JSON.stringify(excluded, null, 2), 'utf8');

const pool = all.filter(t => !t.dupOf);
const targets = only ? pool.filter(t => only.includes(t.idx)) : pool;
if (!targets.length) throw new Error('没有待采集的达人。检查 talents.txt、links_resolved.json 与 --only 参数。');

const OUT = path.resolve('collect');
fs.mkdirSync(OUT, { recursive: true });
const DATA = 'talents_data.json';
let saved = fs.existsSync(DATA) ? JSON.parse(fs.readFileSync(DATA, 'utf8')) : [];

const matchRe = new RegExp(process.env.CDP_URL_MATCH || CFG.urlMatch || 'life\\.douyin\\.com', 'i');
const s = await connectTab(u => matchRe.test(u));

function guard(snap) {
  if (snap.loginHint) throw new Error('登录态失效或当前不在达人广场 —— 立即停止。请在浏览器里重新登录后重跑（已采结果已保存，可用 --only 续跑）。');
  if (snap.captchaHint) throw new Error('检测到安全验证 / 访问频繁 —— 立即停止，不做短时重试。请人工处理后再跑（风控优先）。');
}

// ---- 确定 searchUrl ----
const API = FM.api || {};
let searchUrl = API.searchUrl || null;
if (!noReload) {
  log('reload 达人广场以自动发现 search 接口 URL（适配当前登录账号）…');
  const cap = await startCapture(s);
  await s.send('Page.reload', { ignoreCache: false });
  await sleep(10000);
  guard(await pageSnapshot(s));
  await cap.stop();
  const hit = [...cap.bodies].reverse().find(b => b.url.includes('talent_square/talent/search') && !b.url.includes('config'));
  if (hit) { searchUrl = hit.url; log(`已发现 searchUrl: ${searchUrl.slice(0, 100)}…`); }
  else if (searchUrl) log('reload 未捕获 search 请求，改用 field_map.api.searchUrl');
}
if (!searchUrl) throw new Error('无法确定 search 接口 URL：去掉 --no-reload 重跑，或在 field_map.json 的 api.searchUrl 填完整 URL。');

const BASE_BODY = API.searchBody || {
  enable_filter_item_params: true,
  filter_item_params: { mediaType: ['VideoAndLive'] },
  request_source: 2, page: 1, page_size: 10, from_type: 5,
};
const MAX_PAGES = Number(process.env.MAX_PAGES || 3);

function pickTalent(list, t) {
  const uid = (t.linkUniqueId || '').toLowerCase();
  const sec = t.secUid || null;
  const bySec = sec ? list.filter(x => (x.aweme_url || '').includes(sec)) : [];
  const byUid = uid ? list.filter(x => (x.unique_id || '').toLowerCase() === uid) : [];
  const exact = list.filter(x => (x.nick_name || '') === t.nickname);
  const exactLink = t.linkNickname ? list.filter(x => (x.nick_name || '') === t.linkNickname) : [];
  const fuzzy = list.filter(x => (x.nick_name || '').includes(t.nickname) || (x.unique_id || '') === t.nickname);

  let selected = null, basis = '未匹配';
  if (bySec.length) { selected = bySec[0]; basis = 'sec_uid'; }
  else if (byUid.length) { selected = byUid[0]; basis = '抖音号'; }
  else if (exactLink.length === 1) { selected = exactLink[0]; basis = '链接昵称精确'; }
  else if (exact.length === 1) { selected = exact[0]; basis = '清单昵称精确'; }
  else if (exact.length > 1 || fuzzy.length) { selected = (exact[0] || fuzzy[0]); basis = '昵称模糊·待核对'; }

  // 有抖音号却找不到对应记录 = 该达人不在广场池（或未开通），不能拿同名的人顶替
  const uidMismatch = !!uid && byUid.length === 0 && bySec.length === 0;
  const ambiguous = basis === '昵称模糊·待核对';
  return { selected, basis, ambiguous, uidMismatch, bySec, byUid, exact, exactLink, fuzzy };
}

function readMetrics(t) {
  const metrics = {};
  for (const [key, m] of Object.entries(FM.metrics)) {
    let val = null, raw = null, usedPath = null, rawUnparsed = null;
    if (t) {
      for (const p of (m.jsonPaths || [])) {
        const rv = getByPath(t, p.startsWith('$') ? p : '$.' + p);
        if (rv == null) continue;
        if (rawUnparsed == null) rawUnparsed = String(rv);
        const v = parseMetric(rv, m.type);
        if (v != null) { val = v; raw = rv; usedPath = p; break; }
      }
      if (val == null) {
        for (const h of deepFind(t, m.jsonKeys || [], 8)) {
          const v = parseMetric(h.value, m.type);
          if (v != null) { val = v; raw = h.value; usedPath = h.path; break; }
        }
      }
    }
    metrics[key] = {
      value: val, raw: raw == null ? null : String(raw), source: val != null ? 'api' : null,
      apiPath: usedPath, missing: val == null,
      // 缺失时保留平台原文（如 "<100"），报告显示原文而不是留白，也不取边界值
      rawUnparsed: val == null ? rawUnparsed : null,
    };
  }
  return metrics;
}

function readProfile(t) {
  if (!t) return null;
  const gp = p => getByPath(t, p.startsWith('$') ? p : '$.' + p) ?? null;
  const P = (FM.api || {}).profilePaths || {};
  return {
    apiNickName: gp('nick_name'), apiUniqueId: gp('unique_id'), apiAwemeUrl: gp('aweme_url'),
    fans: gp(P.fans || 'talent_display_info.fans_count_display.statistice_value.digit_value'),
    fansText: gp('fans_count'), localFans: gp('local_fans_count'),
    city: gp('city_name') || gp('resident_city_name'),
    selfIntro: gp('self_intro'), creditScore: gp('credit_score'),
    contentLevel: gp('content_level'), liveLevel: gp('live_level'),
    avgItemPayAmt30d: gp('sale_detail.item_pay_amt_avg_30d'),
    avgFinishRate30d: gp('sale_detail.item_finish_rate_30d'),
  };
}

async function searchAll(keyword) {
  const pages = [];
  for (let page = 1; page <= MAX_PAGES; page++) {
    const resp = await fetchPostJson(s, searchUrl, { ...BASE_BODY, page, page_size: 10, keyword });
    if (resp.httpStatus === 401 || resp.httpStatus === 403) throw new Error(`接口 HTTP ${resp.httpStatus} —— 登录态疑似失效，立即停止（已采结果已保存）。`);
    const d = resp.data;
    if (!d) throw new Error(`响应非 JSON（HTTP ${resp.httpStatus}）: ${(resp.textHead || '').slice(0, 80)}`);
    if (d.status_code !== 0) throw new Error(`接口 status_code=${d.status_code} ${d.status_msg || ''}`);
    const list = d.talent_list || [];
    pages.push(...list);
    if (!d.has_more || !list.length) break;
    if (pages.length >= 30) break;
    await sleep(700 + Math.random() * 600);
  }
  return pages;
}

const results = [], failed = [];
for (let i = 0; i < targets.length; i++) {
  const t = targets[i];
  const kw = t.linkUniqueId || t.nickname;
  log(`[${i + 1}/${targets.length}] #${t.idx} ${t.nickname}${t.linkUniqueId ? `（抖音号 ${t.linkUniqueId}）` : '（无抖音号·按昵称）'}`);
  try {
    if (i % 3 === 0) guard(await pageSnapshot(s));
    const list = await searchAll(kw);
    if (!list.length) { failed.push({ ...t, err: `搜索「${kw}」无结果` }); log('  ✗ 搜索无结果'); continue; }

    const { selected, basis, ambiguous, uidMismatch } = pickTalent(list, t);
    if (!selected) { failed.push({ ...t, err: `搜到 ${list.length} 人但均不匹配（首位：${list[0].nick_name || '?'}）` }); log('  ✗ 无匹配项'); continue; }
    if (uidMismatch) {
      failed.push({ ...t, err: `抖音号 ${t.linkUniqueId} 在达人广场无记录（未入驻广场或未开通视频带货展示），不拿同名账号顶替` });
      log('  ✗ 抖音号无记录，未采（不顶替同名账号）');
      continue;
    }

    const metrics = readMetrics(selected);
    const profile = readProfile(selected);
    const got = Object.values(metrics).filter(m => !m.missing).length;
    const allMatches = list.map(x => ({ nickName: x.nick_name, uniqueId: x.unique_id, itemLevel: x.item_level, fans: x.fans_count }));
    const notes = [];
    if (ambiguous) notes.push(`昵称模糊匹配（在 ${list.length} 个候选里取首位），请用抖音号核对`);
    if (t.linkNickname && profile?.apiNickName && t.linkNickname !== profile.apiNickName) notes.push(`链接昵称「${t.linkNickname}」与广场昵称「${profile.apiNickName}」不一致`);
    if (t.nickname !== (t.linkNickname || t.nickname) && !(t.linkNickname || '').includes(t.nickname)) notes.push(`清单写「${t.nickname}」，链接真实昵称「${t.linkNickname}」（疑似错字）`);

    const rec = {
      ...t,
      collectedAt: new Date().toISOString(),
      mode: 'api',
      matchBasis: basis,
      ambiguous,
      keywordUsed: kw,
      apiFound: true,
      apiUrl: searchUrl,
      candidatesScanned: list.length,
      allMatches,
      profile,
      identityNote: notes.length ? notes.join('；') : null,
      identityNeedsCheck: ambiguous || notes.length > 0,
      metrics,
    };
    fs.writeFileSync(path.join(OUT, `${String(t.idx).padStart(2, '0')}.json`), JSON.stringify(rec, null, 2), 'utf8');

    const miss = Object.entries(metrics).filter(([, m]) => m.missing).map(([k]) => FM.metrics[k].label);
    const fanDelta = (t.labeledFans && profile?.fans) ? Math.round((profile.fans - t.labeledFans) / t.labeledFans * 100) : null;
    log(`  ✓ ${got}/5 | ${basis} ${profile?.apiNickName}(${profile?.apiUniqueId}) 粉 ${profile?.fans ?? '?'}` +
        (fanDelta != null && Math.abs(fanDelta) >= 10 ? ` | 标注粉 ${t.labeledFans} 偏差 ${fanDelta > 0 ? '+' : ''}${fanDelta}%` : '') +
        (miss.length ? ` | 缺失: ${miss.join('、')}` : '') + (notes.length ? ` | ⚠ ${notes[0]}` : ''));
    results.push(rec);
  } catch (e) {
    if (/立即停止|登录态|安全验证/.test(e.message)) throw e;
    failed.push({ ...t, err: e.message.slice(0, 120) });
    log(`  ✗ ${e.message.slice(0, 120)}`);
  }
  const merged = new Map(saved.map(r => [r.idx, r]));
  results.forEach(r => merged.set(r.idx, r));
  saved = [...merged.values()].sort((a, b) => a.idx - b.idx);
  fs.writeFileSync(DATA, JSON.stringify(saved, null, 2), 'utf8');
  fs.writeFileSync(path.join(OUT, 'failed.json'), JSON.stringify(failed, null, 2), 'utf8');
  if (i < targets.length - 1) await sleep(1000 + Math.random() * 1200);
}

log(`完成：本轮成功 ${results.length} / 失败 ${failed.length}；累计已采 ${saved.length}/${pool.length}` +
    (excluded.length ? `；剔除 ${excluded.length} 条（短链重复，见 excluded.json）` : ''));
if (failed.length) log('失败清单:', failed.map(f => `#${f.idx} ${f.nickname}: ${f.err}`).join(' | '));
log('下一步：node 02_score.mjs');
s.close();
