// 第 2 步｜综合评分：5 项指标按 config.json 的递减权重加权，输出综合排名 + 可复核的分项归一过程。
// 硬口径：
//  - 视频带货力是 Lv0–Lv8 等级，先按 level/levelMax 映射 0–100，不与金额混算。
//  - 金额与播放量用 log1p + 本批 min-max 归一，避免一个巨额值把其余人压成 0。
//  - 核销率本身有界，用线性 min-max。
//  - 缺失值不参与、不补 0；剩余权重按比例重分配，并在报告标注有效权重覆盖率。
//  - 综合分同分时，按用户给定的优先级逐级 tie-break（视频带货力 > 平均种草销售额 > …）。
import fs from 'node:fs';
import { log } from './lib/util.mjs';

const CFG = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const FM = JSON.parse(fs.readFileSync('field_map.json', 'utf8'));
const RAW = JSON.parse(fs.readFileSync('talents_data.json', 'utf8'));
if (!RAW.length) throw new Error('talents_data.json 为空，先跑 01_collect.mjs');
const EXCLUDED = fs.existsSync('excluded.json') ? JSON.parse(fs.readFileSync('excluded.json', 'utf8')) : [];

const keys = Object.keys(FM.metrics);
const W = CFG.weights, N = CFG.normalize;
const totalW = keys.reduce((a, k) => a + (W[k] || 0), 0);
if (Math.abs(totalW - 100) > 1e-6) log(`⚠ 权重合计 ${totalW}，不是 100；按比例重分配后计算（建议核对 config.json）`);

// 统一在入口规整浮点尾巴（"12.42 万" 换算可能带出 22200.000000000004）
const val = (r, k) => {
  const v = r.metrics?.[k]?.value;
  return v == null ? null : Math.round(v * 100) / 100;
};
const pools = {};
for (const k of keys) pools[k] = RAW.map(r => val(r, k)).filter(v => v != null).sort((a, b) => a - b);

const median = arr => arr.length ? (arr.length % 2 ? arr[(arr.length - 1) / 2] : (arr[arr.length / 2 - 1] + arr[arr.length / 2]) / 2) : null;
const stats = {};
for (const k of keys) {
  const p = pools[k];
  stats[k] = {
    n: p.length, min: p.length ? p[0] : null, median: median(p), max: p.length ? p[p.length - 1] : null,
    allSame: p.length > 1 && p[0] === p[p.length - 1],
  };
}

function normalize(k, v) {
  if (v == null) return null;
  if (N[k] === 'level') return Math.max(0, Math.min(100, v / (CFG.levelMax || 8) * 100));
  const p = pools[k];
  if (!p.length) return null;
  const f = N[k] === 'linear_minmax' ? (x => x) : (x => Math.log1p(Math.max(0, x)));
  const lo = Math.min(...p.map(f)), hi = Math.max(...p.map(f));
  if (hi - lo < 1e-9) return 50; // 全批同值：该维度无区分度，给中位分，并在风险列标注
  return (f(v) - lo) / (hi - lo) * 100;
}

const fmt = v => v == null ? '—' : new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 2 }).format(v);
const graded = RAW.map(r => {
  const norms = {}, parts = {};
  let acc = 0, wsum = 0;
  for (const k of keys) {
    const n = normalize(k, val(r, k));
    norms[k] = n;
    const w = W[k] || 0;
    parts[k] = { raw: val(r, k), rawText: r.metrics?.[k]?.raw ?? null, norm: n, weight: w, weighted: n == null ? null : n * w / 100 };
    if (n != null) { acc += n * w; wsum += w; }
  }
  const total = wsum > 0 ? acc / wsum : null;
  const missingKeys = keys.filter(k => norms[k] == null);
  const discrepancies = keys.filter(k => r.metrics?.[k]?.discrepancy);
  // 报价与投产参考（只用用户给的报价 + 接口的稿均种草额，纯除法，不掺任何假设）
  const gmv = val(r, 'avgSeedingGmv'), price = r.price || null;
  const roi = (gmv != null && price) ? gmv / price : null;
  // 标注粉丝 vs 广场粉丝（口径/时点可能不同，只对照不覆盖）
  const fansSquare = r.profile?.fans ?? null;
  const fansDelta = (r.labeledFans && fansSquare) ? (fansSquare - r.labeledFans) / r.labeledFans * 100 : null;
  return { ...r, norms, parts, total, weightSum: wsum, weightCoverage: wsum / totalW * 100,
           missingKeys, discrepancies, covered: keys.length - missingKeys.length,
           roi, fansSquare, fansDelta };
});

const order = CFG.tieBreakOrder?.length ? CFG.tieBreakOrder : keys;
graded.sort((a, b) => {
  if ((b.total ?? -1) !== (a.total ?? -1)) return (b.total ?? -1) - (a.total ?? -1);
  for (const k of order) {
    const x = val(a, k), y = val(b, k);
    const xv = x == null ? -Infinity : x, yv = y == null ? -Infinity : y;
    if (yv !== xv) return yv - xv;
  }
  return a.idx - b.idx;
});
graded.forEach((r, i) => {
  r.rank = i + 1;
  r.grade = r.total == null ? '—' : (r.total >= CFG.grades.S ? 'S' : r.total >= CFG.grades.A ? 'A' : r.total >= CFG.grades.B ? 'B' : 'C');
});

// 逐人数据论据与风险：只陈述能追到原始数字的事实，不写定性推测。
const rankOf = (k, v) => {
  const p = pools[k].slice().sort((a, b) => b - a);
  const i = p.indexOf(v);
  return i < 0 ? null : i + 1;
};
for (const r of graded) {
  const seg = keys.filter(k => r.norms[k] != null).map(k => {
    const m = FM.metrics[k], v = val(r, k), rk = rankOf(k, v);
    const raw = m.type === 'level' ? `Lv${v}` : `${fmt(v)}${m.unit === '%' ? '%' : ` ${m.unit}`}`;
    return `${m.label} ${raw}${rk ? `（本池第 ${rk}/${pools[k].length}）` : ''}，归一 ${r.norms[k].toFixed(1)}/100，权重 ${W[k]}`;
  });
  r.reason = `${seg.join('；')}。加权后综合 ${r.total == null ? '—' : r.total.toFixed(1)}/100，有效权重 ${r.weightSum}/${totalW}（${r.weightCoverage.toFixed(0)}%）。` +
    (r.roi != null ? `单条报价 ${fmt(r.price)} 元，稿均种草额 ${fmt(val(r, 'avgSeedingGmv'))} 元，投产参考 ${r.roi.toFixed(2)}×。` : '');

  const risks = [];
  if (r.missingKeys.length) risks.push(`缺失 ${r.missingKeys.map(k => FM.metrics[k].label).join('、')}（对应权重 ${r.missingKeys.reduce((a, k) => a + (W[k] || 0), 0)} 未参与，已按剩余权重重分配，结论稳定性下降）`);
  if (val(r, 'videoSellingPower') === 0) risks.push('视频带货力 Lv0：官方口径为「暂不符合 Lv1–Lv8 要求或存在严重违规」，需先核实原因');
  const rr = val(r, 'redeemRate30d'), rmed = stats.redeemRate30d.median;
  if (rr != null && rmed != null && rr < rmed) risks.push(`30日核销率 ${fmt(rr)}% 低于本池中位数 ${fmt(rmed)}%（支付 GMV 与核销后收入有缺口）`);
  for (const k of r.discrepancies) {
    risks.push(`${FM.metrics[k].label} 存在口径冲突，需人工核对`);
  }
  if (r.identityNeedsCheck) risks.push('昵称存在重名且未消歧（未提供主页链接 sec_uid 或有多个同名账号），已按「sec_uid > 昵称精确 > 昵称包含」取首位，请用抖音号/主页链接核对（同名仿号常为 Lv0 低量级账号）');
  else if (r.identityNote) risks.push(r.identityNote);
  for (const k of keys) if (stats[k].allSame && r.norms[k] != null) risks.push(`${FM.metrics[k].label} 全批同值，该维度无区分度，统一按 50 分计`);
  if (RAW.length < 5) risks.push(`本批仅 ${RAW.length} 位达人，min-max 为批内相对归一，样本偏小、分数不宜跨批比较`);
  if (r.fansDelta != null && Math.abs(r.fansDelta) >= 10) risks.push(`标注粉丝 ${fmt(r.labeledFans)} 与广场粉丝 ${fmt(r.fansSquare)} 相差 ${r.fansDelta > 0 ? '+' : ''}${r.fansDelta.toFixed(0)}%（两者口径/时点可能不同，评分未使用粉丝数，不影响排名）`);
  if (r.roi != null && r.roi < 1) risks.push(`稿均种草额 ${fmt(val(r, 'avgSeedingGmv'))} 元低于单条报价 ${fmt(r.price)} 元（投产比 ${r.roi.toFixed(2)}× < 1）`);
  r.risk = risks.length ? risks.join('；') : '5 项指标齐全、页面与接口口径一致；仍建议核对等级评定月份与数据快照时点。';
}

const out = {
  generatedAt: new Date().toISOString(),
  dateBj: new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 19).replace('T', ' '),
  config: CFG, fieldMap: FM, keys,
  stats,
  excluded: EXCLUDED,
  priceStats: (() => {
    const ps = graded.map(r => r.price).filter(v => v != null).sort((a, b) => a - b);
    if (!ps.length) return null;
    const med = ps.length % 2 ? ps[(ps.length - 1) / 2] : (ps[ps.length / 2 - 1] + ps[ps.length / 2]) / 2;
    return { n: ps.length, min: ps[0], max: ps[ps.length - 1], median: med };
  })(),
  overall: {
    n: graded.length,
    totalW,
    coverageMin: Math.min(...graded.map(r => r.weightCoverage)),
    coverageMax: Math.max(...graded.map(r => r.weightCoverage)),
    missingTotal: graded.reduce((a, r) => a + r.missingKeys.length, 0),
    discrepancyTotal: graded.reduce((a, r) => a + r.discrepancies.length, 0),
    identityNeedsCheck: graded.filter(r => r.identityNeedsCheck).map(r => `#${r.rank} ${r.nickname}`),
  },
  talents: graded,
};
fs.writeFileSync('score_data.json', JSON.stringify(out, null, 2), 'utf8');
log(`完成：${graded.length} 位达人，权重合计 ${totalW}，缺失项 ${out.overall.missingTotal}，口径冲突 ${out.overall.discrepancyTotal}`);
graded.slice(0, 5).forEach(r => log(`  #${r.rank} ${r.nickname} ${r.total?.toFixed(1)} 分 ${r.grade} 级（有效权重 ${r.weightSum}/${totalW}）`));
log('下一步：node 03_render.mjs');
