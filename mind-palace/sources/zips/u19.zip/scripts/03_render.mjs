// 第 3 步｜出结论页：固定 3 分页 HTML（整合结论 / 总览 / 逐人指标明细）+ 1 个带 BOM 的 CSV。
// 所有文案由 score_data.json 驱动，不写死任何人名、数字、指标值；缺失一律显示「—」。
import fs from 'node:fs';

const D = JSON.parse(fs.readFileSync('score_data.json', 'utf8'));
const { talents: P, keys, stats: S, config: CFG, fieldMap: FM, overall: O, dateBj, excluded: EX = [], priceStats: PS } = D;
const W = CFG.weights;
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const f1 = v => v == null ? '—' : Number(v).toFixed(1);
const fmt = v => v == null ? '—' : new Intl.NumberFormat('zh-CN', { maximumFractionDigits: 2 }).format(v);
const a = (url, text, cls = '') => url ? `<a href="${esc(url)}" target="_blank" rel="noopener" class="${cls}">${esc(text)}</a>` : esc(text);
const badge = (t, cls = '') => `<span class="bd ${cls}">${esc(t)}</span>`;
const gcls = g => g === 'S' ? 'gS' : g === 'A' ? 'gA' : g === 'B' ? 'gB' : 'gC';
const M = k => FM.metrics[k];
const rawOf = (r, k) => {
  const v = r.parts[k].raw;
  if (v == null) {
    const un = r.metrics?.[k]?.rawUnparsed;
    return un ? `${un}（低于平台披露下限）` : '—';
  }
  if (M(k).type === 'level') return `Lv${v}`;
  return `${fmt(v)}${M(k).unit === '%' ? '%' : ''}`;
};

function table(cols, rows, tid = '') {
  const th = cols.map(c => `<th${c.w ? ` style="min-width:${c.w}px"` : ''}>${esc(c.t)}</th>`).join('');
  const tb = rows.map(r => `<tr${r._cls ? ` class="${r._cls}"` : ''}>${cols.map(c => {
    const v = r[c.k];
    return `<td${v == null || v === '' || v === '—' ? ' class="na"' : ''}>${v == null ? '—' : (c.raw ? v : esc(v))}</td>`;
  }).join('')}</tr>`).join('');
  return `<div class="tw"><table${tid ? ` id="${tid}"` : ''}><thead><tr>${th}</tr></thead><tbody>${tb}</tbody></table></div>`;
}

// ---------- 结论页文案（全部数据驱动） ----------
const t1 = P[0];
const driver = keys.slice().sort((x, y) => (t1.parts[y].weighted ?? 0) - (t1.parts[x].weighted ?? 0))[0];
const heroLead = `${esc(t1.nickname)}（${f1(t1.total)} 分，${esc(t1.grade)} 级）综合分第一，最大贡献项是 <b>${esc(M(driver).label)}</b>`;
const lowCov = P.filter(p => p.weightCoverage < 100);
const heroCaveat = lowCov.length
  ? `本批有 ${lowCov.length} 位达人存在指标缺失（有效权重最低 ${f1(O.coverageMin)}%），缺失项权重已按比例重分配 —— 分数不与满分口径直接可比，请对照「数据完整度」列。`
  : `全批 5 项指标齐全、权重覆盖率 100%；仍建议对照下方分用途选人，综合分高不等于每个投放目标都最优。`;

const rankTable = table([
  { t: '排名', k: 'rank', raw: 1, w: 52 }, { t: '达人（点开主页）', k: 'name', raw: 1, w: 150 },
  { t: '综合分', k: 'total', raw: 1, w: 68 }, { t: '等级', k: 'grade', raw: 1, w: 60 },
  ...keys.map(k => ({ t: `${M(k).label} <small>/${W[k]}</small>`, k: k, raw: 1, w: 88 })),
  { t: '有效权重', k: 'cov', w: 82 },
  { t: '数据论据 / 为什么是这个分', k: 'reason', w: 420 }, { t: '主要风险', k: 'risk', w: 340 },
], P.map(p => ({
  _cls: p.rank <= 3 ? 'top3' : '', rank: badge('#' + p.rank, 'rank'),
  name: a(p.homepage, p.nickname, 'lnk'), total: `<b class="score">${f1(p.total)}</b>`,
  grade: badge(p.grade, gcls(p.grade)),
  ...Object.fromEntries(keys.map(k => [k, `${f1(p.parts[k].weighted)}<span class="sub">/${W[k]}</span>`])),
  cov: `${f1(p.weightCoverage)}%`, reason: esc(p.reason), risk: esc(p.risk),
})));

const COLORS = ['#2563eb', '#0891b2', '#ea580c', '#7c3aed', '#16a34a'];
const card = p => `<div class="card">
  <div class="card-h"><span class="rk">#${p.rank}</span>${a(p.homepage, p.nickname, 'lnk big')}<span class="tt">${f1(p.total)} <small>/100</small></span>${badge(p.grade, gcls(p.grade))}</div>
  <div class="bars">${keys.map((k, i) => {
    const v = p.parts[k].weighted ?? 0, m = W[k];
    return `<div class="bar"><span class="bl">${esc(M(k).label)}</span><span class="bt"><i style="width:${m ? (v / m * 100).toFixed(1) : 0}%;background:${COLORS[i % COLORS.length]}"></i></span><span class="bv">${f1(v)}/${m}</span></div>`;
  }).join('')}</div>
  <div class="kv"><b>原始值</b>：${keys.map(k => `${esc(M(k).label)} <b>${rawOf(p, k)}</b>`).join(' ｜ ')}</div>
  <div class="why"><b>为什么</b>：${esc(p.reason)}</div><div class="risk"><b>硬伤</b>：${esc(p.risk)}</div></div>`;

// 分用途选人：抖音本地生活最贴切的两个投放目标
const byGmv = P.slice().sort((x, y) => (y.parts.avgSeedingGmv.raw ?? -Infinity) - (x.parts.avgSeedingGmv.raw ?? -Infinity)).slice(0, 3);
const byRedeem = P.slice().sort((x, y) => (y.parts.redeemRate30d.raw ?? -Infinity) - (x.parts.redeemRate30d.raw ?? -Infinity)).slice(0, 3);
const byRoi = P.filter(p => p.roi != null).sort((a, b) => b.roi - a.roi).slice(0, 3);
const dual = (arr, k, title, note) => `<div class="dual"><h4>${esc(title)}</h4><div class="dn">${esc(note)}</div>
  <ol>${arr.map(p => `<li>${a(p.homepage, p.nickname, 'lnk')} <b>${rawOf(p, k)}</b> <span class="sub">（综合榜 #${p.rank}）</span></li>`).join('')}</ol></div>`;

const weightHtml = table([
  { t: '指标', k: 'm' }, { t: '权重', k: 'w' }, { t: '类型', k: 'type' }, { t: '归一算法', k: 'how' }, { t: '本批分布（最小 / 中位 / 最大）', k: 'dist' },
], keys.map(k => {
  const s = S[k];
  const how = CFG.normalize[k] === 'level' ? `等级 Lv0–Lv${CFG.levelMax} 线性映射到 0–100`
    : CFG.normalize[k] === 'linear_minmax' ? '本批线性 min-max（比率本身有界）'
    : 'log1p 对数 + 本批 min-max（防止单个巨额值压扁其余达人）';
  return { m: M(k).label, w: `<b>${W[k]}</b>`, type: M(k).unit, how,
           dist: `${fmt(s.min)} / ${fmt(s.median)} / ${fmt(s.max)}（n=${s.n}）` };
}));

const findings = [
  ['权重顺序是优先级，不是倍数关系', `按「视频带货力 > 平均种草销售额 > 稿均播放量 > 稿均千次曝光GMV > 30日核销率」给 ${keys.map(k => W[k]).join(' / ')} 分递减权重，合计 ${O.totalW}。综合分同分时按同一顺序逐级比较原始值定名次。`],
  ['视频带货力是等级，不是金额', `官方为 Lv0–Lv${CFG.levelMax} 共 ${CFG.levelMax + 1} 级，按自然月评定。本表只做「等级 → 0–100」线性映射，不还原官方评级算法；Lv0 代表暂不符合 Lv1–Lv${CFG.levelMax} 要求或存在严重违规，已在风险列提示。`],
  ['金额项必须对数归一', `本批平均种草销售额 ${fmt(S.avgSeedingGmv.min)} ~ ${fmt(S.avgSeedingGmv.max)}、稿均播放量 ${fmt(S.avgPlays.min)} ~ ${fmt(S.avgPlays.max)}，量级跨度大。线性归一会让头部一人拿满、其余趋近 0；改用 log1p + min-max 后仍保留相对次序。`],
  ['缺失不补 0，权重重分配', `全批缺失 ${O.missingTotal} 项，有效权重覆盖率 ${f1(O.coverageMin)}%–${f1(O.coverageMax)}%。缺失指标不参与计分，剩余权重按比例重分配，综合分仍是 0–100 的加权平均；报告保留「数据完整度」列供横向判断。「<100」「达人未授权」等平台隐藏精确值的下界标记也按缺失处理，不当数值采信。`],
  ['身份不是靠昵称猜的，是靠抖音号锁的', `本批清单里的短链全部解析出了抖音号，采集按抖音号精确搜索（实测返回 1 条），${P.filter(p => p.matchBasis === 'sec_uid' || p.matchBasis === '抖音号').length}/${P.length} 位按 sec_uid 或抖音号精确命中。若按昵称模糊搜，实测「小师妹」有 1000 条结果、第一页全是同名大号，会直接认错人。`],
  ['粉丝数两个口径不一致，已并列保留', `你标注的粉丝数与抖音主页一致，但与达人广场展示值有出入（最大 ${P.filter(p => p.fansDelta != null).length ? Math.max(...P.filter(p => p.fansDelta != null).map(p => Math.abs(p.fansDelta))).toFixed(0) : '—'}%）。两列都保留、未择优；评分不含粉丝数，因此不影响排名，只影响你对达人量级的判断。`],
  ['低于披露下限的指标没有硬凑', `有 ${O.missingTotal} 项显示「<100」（平台只披露下界、不给精确值）。按缺失处理、不取 100，权重按比例重分配，明细里原样显示「<100（低于平台披露下限）」。`],
  ['昵称会重名，身份靠多重匹配', `匹配顺序：主页链接 sec_uid > 昵称精确 > 昵称包含。本批 ${P.filter(p => p.ambiguous).length} 位存在重名未消歧（明细里标 identityNeedsCheck，搜索返回的同名候选已全部保留在采集文件 allMatches）。实测同名仿号多为 Lv0 低量级账号，仅凭昵称选人会选错人 —— 请用抖音号/主页链接核对。`],
  ['接近 0 分不是采集失败', `min-max 是批内相对归一：某一项的全批最低者该维度得 0 分；若一位达人在多项上同时垫底，综合分会接近 0。这是数学结果，不是数据缺失，也不额外拉伸分数 —— 请对照「数据完整度 / 有效权重」列区分。`],
];

const limits = [
  `数据快照：北京时间 ${esc(dateBj)}；共 ${O.n} 位达人，指标取自抖音来客「达人带货—达人广场」的 talent_square/talent/search 接口（登录态下页面上下文直采），非页面 OCR、非估算。`,
  '达人主页链接（douyin.com / v.douyin.com）与广场记录是两套 ID 体系；身份匹配顺序为「主页链接 sec_uid > 昵称精确 > 昵称包含」，重名未消歧的达人在明细里标 identityNeedsCheck，全部同名候选保留在采集文件 allMatches 中供人工核对。',
  `视频带货力按官方 Lv0–Lv${CFG.levelMax} 等级映射，官方按自然月评定（每月 6 日评出、展示至次月 5 日）；不同达人若处于不同快照时点，等级可比性会下降。`,
  'log1p + min-max 是批内相对归一，分数只在本批达人之间有意义，不可跨批次、跨城市、跨品类直接比较。全批同值的维度统一按 50 分计并标注「无区分度」。',
  '0 值与缺失严格区分：「<100」「达人未授权」「未公开」等平台隐藏精确值的标记一律按缺失处理，不填 0、不估算、不编造；「1.2万」「¥3,456」「78.5%」已统一换算为数字。用户备注里的标注（粉丝数/等级）与接口实测不符时两列都保留。',
  '出现登录失效、安全验证、访问频繁、接口 401/403 等信号时立即停止，不做短时重试；风控优先于采集完整性。采集间隔 1.2–2.4 秒随机抖动。',
  '本表是达人筛选的数据论据，不构成投放效果承诺。合规：采集第三方平台数据前请确认符合平台协议与当地法规，本技能只提供技术实现，不构成合规保证。',
];

// ---------- 分页 2：总览 ----------
const ovTable = table([
  { t: '排名', k: 'rank' }, { t: '达人昵称', k: 'name', raw: 1 }, { t: '抖音号', k: 'uid2' },
  { t: '主页链接', k: 'go', raw: 1 }, { t: '匹配依据', k: 'basis' },
  { t: '综合分', k: 'total', raw: 1 }, { t: '等级', k: 'grade', raw: 1 },
  ...keys.map(k => ({ t: `${M(k).label}（${M(k).unit}）`, k: `raw_${k}` })),
  ...keys.map(k => ({ t: `${M(k).label} 归一`, k: `norm_${k}` })),
  { t: '标注粉丝', k: 'labeledFans' }, { t: '广场粉丝', k: 'fans' },
  { t: '单条报价', k: 'price' }, { t: '稿均种草额/报价', k: 'roi' }, { t: '城市', k: 'city' },
  { t: '有效权重', k: 'cov' }, { t: '数据完整度', k: 'covn' },
  { t: '备注（用户标注）', k: 'note' }, { t: '采集时点', k: 'at' },
], P.map(p => ({
  rank: p.rank, name: a(p.homepage, p.nickname, 'lnk'),
  uid2: esc(p.profile?.apiUniqueId || '—'), go: a(p.homepage, '打开主页 ↗', 'lnk small'),
  basis: p.matchBasis || '—',
  total: `<b class="score">${f1(p.total)}</b>`, grade: badge(p.grade, gcls(p.grade)),
  ...Object.fromEntries(keys.map(k => [`raw_${k}`, rawOf(p, k)])),
  ...Object.fromEntries(keys.map(k => [`norm_${k}`, f1(p.norms[k])])),
  labeledFans: p.labeledFans != null ? fmt(p.labeledFans) : '—',
  fans: p.profile?.fans != null ? fmt(p.profile.fans) : '—',
  price: p.price != null ? fmt(p.price) : '—',
  roi: p.roi != null ? `${p.roi.toFixed(2)}×` : '—',
  city: esc(p.profile?.city || '—'),
  cov: `${f1(p.weightCoverage)}%`, covn: `${p.covered}/${keys.length}`,
  note: p.note || '—', at: (p.collectedAt || '').slice(0, 19).replace('T', ' '),
})), 'ovTable');

// ---------- 分页 3：逐人明细 ----------
const detailCards = P.map(p => `<div class="pcard">
  <div class="pcard-h"><span class="rk">#${p.rank}</span>${a(p.homepage, p.nickname, 'lnk big')}
    <span class="tt">${f1(p.total)} <small>/100</small></span>${badge(p.grade, gcls(p.grade))}
    <span class="sub">有效权重 ${p.weightSum}/${O.totalW}</span>
    <span class="sub">匹配依据：${esc(p.matchBasis || '—')}${p.ambiguous ? badge('重名待核对', 'gC') : ''}</span></div>
  <div class="kv"><b>清单标注</b>：等级 Lv${p.labeledLevel ?? '—'} ｜ 粉丝 ${p.labeledFans != null ? fmt(p.labeledFans) : '—'} ｜ 报价 ${p.price != null ? fmt(p.price) + ' 元' : '—'}${p.roi != null ? ` ｜ 投产参考 <b>${p.roi.toFixed(2)}×</b>` : ''}</div>
  <div class="kv"><b>接口身份</b>：${esc(p.profile?.apiNickName || '—')}（抖音号 ${esc(p.profile?.apiUniqueId || '—')}，粉丝 ${p.profile?.fans != null ? fmt(p.profile.fans) : '—'}，${esc(p.profile?.city || '—')}）${p.profile?.apiAwemeUrl ? ` ｜ <a class="lnk small" href="${esc(p.profile.apiAwemeUrl)}" target="_blank" rel="noopener">接口主页 ↗</a>` : ''}</div>
  ${table([
    { t: '指标', k: 'm' }, { t: '原始值', k: 'raw' }, { t: '归一值 /100', k: 'norm' },
    { t: '权重', k: 'w' }, { t: '加权得分', k: 'got', raw: 1 },
    { t: '取值来源', k: 'src' }, { t: '接口字段', k: 'ctx' }, { t: '状态', k: 'st', raw: 1 },
  ], keys.map(k => {
    const m = p.metrics?.[k] || {}, pt = p.parts[k];
    const st = pt.norm == null ? badge('缺失·权重已重分配', 'gC')
      : m.missing ? badge('缺失', 'gC') : badge('有效', 'gA');
    return { m: M(k).label, raw: rawOf(p, k), norm: f1(pt.norm), w: W[k],
      got: `<b>${f1(pt.weighted)}</b>`,
      src: m.source === 'api' ? '接口 JSON' : '—',
      ctx: (m.apiPath || '—'), st };
  }))}
  <div class="pfoot"><b>数据论据</b>：${esc(p.reason)}<br><b>风险</b>：${esc(p.risk)}${p.identityNote ? `<br><b>身份提示</b>：${esc(p.identityNote)}` : ''}
    ${p.allMatches && p.allMatches.length > 1 ? `<details><summary>搜索返回的全部同名候选（${p.allMatches.length} 个，人工核对用）</summary><pre>${esc(p.allMatches.map(x => `${x.nickName}（${x.uniqueId || '?'}）Lv${x.itemLevel} 粉丝 ${x.fans || '?'}`).join('\n'))}</pre></details>` : ''}</div>
</div>`).join('');

const CSS = `
:root{--bg:#f6f8fb;--card:#fff;--bd:#e3e9f2;--tx:#1b2536;--mut:#6b7a90;--acc:#2563eb;--soft:#eef4ff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--tx);font:14px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
.wrap{max-width:1560px;margin:0 auto;padding:24px 28px 80px}
header h1{font-size:26px;margin:0 0 6px}header .meta{color:var(--mut);font-size:13px;margin-bottom:18px}
nav{display:flex;gap:6px;border-bottom:1px solid var(--bd);margin-bottom:22px;position:sticky;top:0;background:var(--bg);z-index:9;padding-top:6px}
nav button{border:0;background:transparent;padding:11px 18px;font-size:14px;color:var(--mut);cursor:pointer;border-bottom:3px solid transparent;font-weight:600}
nav button.on{color:var(--acc);border-bottom-color:var(--acc)}
.page{display:none}.page.on{display:block}
h2{font-size:19px;margin:26px 0 12px;border-left:4px solid var(--acc);padding-left:10px}
h3{font-size:16px;margin:22px 0 10px}h4{margin:0 0 6px;font-size:15px}
.hero{background:linear-gradient(100deg,#eef4ff,#f7fbff);border:1px solid #d5e3ff;border-radius:12px;padding:18px 22px;margin-bottom:20px}
.hero .big{font-size:18px;font-weight:700;line-height:1.6}.hero .cav{color:#475569;margin-top:8px;font-size:13px}
.warn{background:#fff8e6;border:1px solid #f5d78e;color:#7c4a03;border-radius:10px;padding:12px 16px;margin:0 0 16px;font-size:13px;line-height:1.7}
.tw{overflow:auto;border:1px solid var(--bd);border-radius:10px;background:var(--card);margin-bottom:16px}
table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:9px 11px;border-bottom:1px solid var(--bd);text-align:left;vertical-align:top}
th{background:#f2f6fc;color:#334155;font-weight:700;white-space:nowrap;position:sticky;top:0}
tbody tr:hover{background:#fafcff}tr.top3{background:#f5f9ff}td.na{color:#a3aec0}
small{font-weight:400;color:var(--mut)}.sub{color:var(--mut);font-size:11px}
.lnk{color:var(--acc);text-decoration:none}.lnk:hover{text-decoration:underline}.lnk.big{font-size:16px;font-weight:700}.lnk.small{font-size:12px}
.score{font-size:15px;color:#0f4fc0}
.bd{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:700;white-space:nowrap}
.gS{background:#fde8e8;color:#b91c1c}.gA{background:#fff0dc;color:#b45309}.gB{background:#e0f0ff;color:#1d4ed8}.gC{background:#eceff4;color:#64748b}
.rank{background:#e8effc;color:#1d4ed8}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(430px,1fr));gap:14px}
.card,.pcard{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:16px 18px;margin-bottom:14px}
.card-h,.pcard-h{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.rk{background:#1d4ed8;color:#fff;border-radius:6px;padding:2px 8px;font-weight:700;font-size:12px}
.tt{margin-left:auto;font-size:20px;font-weight:800;color:#0f4fc0}.tt small{font-size:12px}
.bars{display:flex;flex-direction:column;gap:6px;margin:10px 0}
.bar{display:flex;align-items:center;gap:8px;font-size:12px}.bl{width:112px;color:#475569;flex:none}
.bt{flex:1;height:9px;background:#edf1f7;border-radius:6px;overflow:hidden}.bt i{display:block;height:100%;border-radius:6px}
.bv{width:70px;text-align:right;font-variant-numeric:tabular-nums}
.kv,.why,.risk{font-size:12.5px;color:#475569;margin-top:7px}.why{color:#1e3a5f}.risk{color:#9a3412}
.dual{background:var(--card);border:1px solid var(--bd);border-radius:10px;padding:14px 18px;flex:1;min-width:300px}
.dual ol{margin:8px 0 0;padding-left:20px}.dual li{margin:4px 0}.dn{color:var(--mut);font-size:12px}
.flex2{display:flex;gap:14px;flex-wrap:wrap}
.findings li,.limits li{margin:7px 0;font-size:13px}.findings b,.limits b{color:#0f4fc0}
.pfoot{font-size:12.5px;color:#475569;line-height:1.8;margin-top:8px}
details{margin-top:8px}summary{cursor:pointer;color:var(--acc)}pre{white-space:pre-wrap;background:#f5f8fc;border:1px solid var(--bd);border-radius:8px;padding:10px;max-height:230px;overflow:auto;font-size:11.5px}
.tools{display:flex;gap:10px;align-items:center;margin-bottom:10px;flex-wrap:wrap}
.tools input{border:1px solid var(--bd);border-radius:8px;padding:8px 12px;font-size:13px;width:260px;background:#fff;color:var(--tx)}
.tools span{color:var(--mut);font-size:12px}
footer{color:var(--mut);font-size:12px;margin-top:34px;border-top:1px solid var(--bd);padding-top:14px}
`;
const JS = `
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('nav button').forEach(x=>x.classList.remove('on'));
  document.querySelectorAll('.page').forEach(x=>x.classList.remove('on'));
  b.classList.add('on');document.getElementById('p'+b.dataset.p).classList.add('on');
});
const q=document.getElementById('q');if(q)q.oninput=()=>{
  const k=q.value.trim().toLowerCase();
  document.querySelectorAll('#ovTable tbody tr').forEach(tr=>tr.style.display=!k||tr.innerText.toLowerCase().includes(k)?'':'none');
};
document.querySelectorAll('th').forEach((th,i)=>{th.style.cursor='pointer';th.onclick=()=>{
  const tb=th.closest('table').tBodies[0],rows=[...tb.rows];
  const dir=th.dataset.d==='1'?-1:1;th.dataset.d=dir===1?'1':'0';
  rows.sort((x,y)=>{const a=x.cells[i].innerText.replace(/[^\\d.-]/g,''),b=y.cells[i].innerText.replace(/[^\\d.-]/g,'');
    return (parseFloat(b)-parseFloat(a)||0)*dir;});rows.forEach(r=>tb.appendChild(r));
};});
`;

const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>抖音达人筛号 · 综合结论</title><style>${CSS}</style></head><body><div class="wrap">
<header><h1>抖音达人筛号 · 综合结论</h1><div class="meta">数据源：抖音来客「达人带货—达人广场」｜ ${O.n} 位达人 ｜ 快照 ${esc(dateBj)} ｜ 权重 ${keys.map(k => W[k]).join(' / ')}</div></header>
<nav><button class="on" data-p="1">🏆 整合结论</button><button data-p="2">📊 总览</button><button data-p="3">🔍 逐人指标明细</button></nav>

<section class="page on" id="p1">
  <div class="hero"><div class="big">${heroLead}</div><div class="cav">${esc(heroCaveat)}</div></div>
  ${EX.length ? `<div class="warn"><b>⚠ ${EX.length} 条清单数据有问题，已剔除不参与排名：</b>${EX.map(e => `#${e.idx}「${e.nickname}」—— ${esc(e.reason)}`).join('；')}。请补正确的链接后重跑。</div>` : ''}
  <h2>综合排名（逐人数据论据 + 风险）</h2>${rankTable}
  <h2>Top 3 评分卡</h2><div class="cards">${P.slice(0, 3).map(card).join('')}</div>
  <h2>分用途选人</h2><div class="flex2">
    ${dual(byGmv, 'avgSeedingGmv', '要 GMV 规模', '按「平均种草销售额」原始值排序。综合分高不一定单篇带货额最高，看榜单选人更稳。')}
    ${dual(byRedeem, 'redeemRate30d', '要到店核销确定性', '按「30日核销率」排序。支付 GMV 不等于核销后收入，低核销会抬高实际获客成本。')}
  </div>
  <h2>按报价看性价比（稿均种草额 ÷ 单条报价）</h2>
  <div class="flex2">
    <div class="dual"><h4>投产倍数最高</h4><div class="dn">稿均种草销售额 ÷ 你给的单条报价。仅两位都有值时才计算；这是单条稿的粗略参考，不含坑位费/佣金/核销折损。</div>
      <ol>${byRoi.map(p => `<li>${a(p.homepage, p.nickname, 'lnk')} <b>${p.roi.toFixed(2)}×</b> <span class="sub">（报价 ${fmt(p.price)}，稿均种草 ${fmt(p.parts.avgSeedingGmv.raw)}）</span></li>`).join('')}</ol></div>
    ${PS ? `<div class="dual"><h4>本批报价分布</h4><div class="dn">你给的报价：最低 ${fmt(PS.min)} / 中位 ${fmt(PS.median)} / 最高 ${fmt(PS.max)} 元（${PS.n} 位有报价）。综合分与报价无相关性的部分，需按投放目标自行权衡。</div></div>` : ''}
  </div>
  <h2>关键数据发现</h2><ul class="findings">${findings.map(([t, c]) => `<li><b>${esc(t)}</b> —— ${c}</li>`).join('')}</ul>
  <h2>指标权重与归一算法</h2>${weightHtml}
  <h2>口径与限制</h2><ul class="limits">${limits.map(x => `<li>${x}</li>`).join('')}</ul>
</section>

<section class="page" id="p2"><h2>全部达人原始指标</h2>
  <div class="tools"><input id="q" placeholder="搜索昵称 / 备注…"><span>点击任意表头可排序；点击「打开主页 ↗」核对达人身份</span></div>
  ${ovTable}
</section>

<section class="page" id="p3"><h2>逐人指标明细（原始值 → 归一 → 加权，可复核）</h2>
  <div class="meta" style="color:var(--mut);font-size:13px;margin-bottom:14px">「页面上下文 / 接口路径」列记录每个数字来自页面哪一段文字或接口哪个字段，便于追问三层来源。缺失项不补 0。</div>
  ${detailCards}
</section>
<footer>本报告由「抖音达人筛号专家」技能生成 · 结论为筛选数据论据，不构成投放效果承诺 · 采集前请确认符合平台协议与当地法规</footer>
</div><script>${JS}</script></body></html>`;
fs.writeFileSync('抖音达人筛号_综合结论.html', html, 'utf8');

// ---------- CSV（BOM，Excel 直接打开） ----------
const cell = v => {
  const s = String(v ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const head = ['排名', '达人昵称', '主页链接', '综合分', '等级', '有效权重(%)', '数据完整度',
  ...keys.map(k => `${M(k).label}(${M(k).unit})`), ...keys.map(k => `${M(k).label}归一`),
  '备注(用户标注)', '主要风险', '采集时点'];
const lines = [head.map(cell).join(',')];
for (const p of P) lines.push([
  p.rank, p.nickname, p.homepage || '', f1(p.total), p.grade, f1(p.weightCoverage), `${p.covered}/${keys.length}`,
  ...keys.map(k => p.parts[k].raw ?? ''), ...keys.map(k => p.norms[k] == null ? '' : Number(p.norms[k]).toFixed(2)),
  p.note || '', p.risk, (p.collectedAt || '').slice(0, 19).replace('T', ' '),
].map(cell).join(','));
fs.writeFileSync('抖音达人筛号_综合总览.csv', '\uFEFF' + lines.join('\r\n') + '\r\n', 'utf8');

console.log('已生成：抖音达人筛号_综合结论.html（3 分页）、抖音达人筛号_综合总览.csv');
console.log(`达人 ${O.n} 位｜缺失 ${O.missingTotal} 项｜口径冲突 ${O.discrepancyTotal} 处`);
