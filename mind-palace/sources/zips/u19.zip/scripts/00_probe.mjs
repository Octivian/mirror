// 第 0 步｜首次探查：确认登录态、抓下达人广场实际发出的接口响应、列出 5 个指标的字段候选。
// 目的不是「一次抓全」，而是把未经验证的接口暴露出来，供人工确认后填进 field_map.json。
// 之后 01_collect.mjs 才能稳定复用。任何字段都不猜测、不写死。
import fs from 'node:fs';
import path from 'node:path';
import { connectTab, startCapture, trySearch, pageSnapshot } from './lib/cdp.mjs';
import { log, sleep, labelCandidates, deepFind, parseTalents, parseMetric } from './lib/util.mjs';

const CFG = JSON.parse(fs.readFileSync('config.json', 'utf8'));
const FM = JSON.parse(fs.readFileSync('field_map.json', 'utf8'));
const OUT = path.resolve('probe');
fs.mkdirSync(OUT, { recursive: true });

const matchRe = new RegExp(process.env.CDP_URL_MATCH || CFG.urlMatch || 'life\\.douyin\\.com', 'i');
const s = await connectTab(u => matchRe.test(u));

const before = await pageSnapshot(s);
log('当前页面:', before.url);
if (before.loginHint) throw new Error('检测到登录提示 —— 请在调试 Chrome 里先登录抖音来客并进入达人广场，再重跑本脚本。');
if (before.captchaHint) throw new Error('检测到安全验证/风控页面 —— 立即停止，不做重试。请人工处理后再跑。');

// 有输入清单时，自动搜索第一位达人；没有则纯等待人工操作。
let nick = '';
if (fs.existsSync('talents.txt')) {
  const t = parseTalents(fs.readFileSync('talents.txt', 'utf8'));
  if (t.length) nick = t[0].nickname;
}
const cap = await startCapture(s);
if (nick) {
  const r = await trySearch(s, nick);
  log(r.ok ? `已尝试自动搜索「${nick}」（搜索框 placeholder: ${r.placeholder || '无'}）`
           : `未找到可用搜索框（${r.reason}），请在浏览器里手动搜索这位达人`);
} else {
  log('未找到 talents.txt，请在下面等待时间内于浏览器里手动搜索并打开任意一位达人。');
}

const wait = Number(process.env.PROBE_WAIT_MS || CFG.probeWaitMs || 15000);
log(`捕获中，等待 ${wait / 1000} 秒 —— 请在这段时间里在浏览器打开达人卡片/详情页，让接口把数据吐出来…`);
await sleep(wait);
const snap = await pageSnapshot(s);
await cap.stop();

if (snap.loginHint) log('⚠ 捕获期间出现登录提示，结果可能不完整');
if (snap.captchaHint) log('⚠ 捕获期间出现安全验证/风控提示，请人工处理后重跑');

fs.writeFileSync(path.join(OUT, 'page_text.txt'), `# URL: ${snap.url}\n# TITLE: ${snap.title}\n\n${snap.text}`, 'utf8');

const MAX = 400000;
const responses = cap.bodies.map((b, i) => ({
  i, url: b.url, status: b.status, mime: b.mime, type: b.type, at: b.at,
  size: JSON.stringify(b.data).length,
  data: JSON.stringify(b.data).length > MAX ? { _truncated: true, preview: JSON.stringify(b.data).slice(0, MAX) } : b.data,
}));
fs.writeFileSync(path.join(OUT, 'responses.json'), JSON.stringify(responses, null, 2), 'utf8');

// 生成字段候选清单
const L = [];
L.push('# 达人广场字段探查结果');
L.push(`# 时间: ${new Date().toISOString()}`);
L.push(`# 页面: ${snap.url}`);
L.push(`# JSON 响应数: ${responses.length}`);
L.push('');
L.push('## 一、捕获到的 JSON 接口（按出现顺序）');
responses.forEach(r => L.push(`  [${r.i}] ${r.status} ${r.url}`));
L.push('');
L.push('## 二、5 个指标的候选值');
L.push('# 确认无误后，把「API 候选」里的 path 填进 field_map.json 对应指标的 jsonPaths 数组。');
L.push('# 页面文本命中即代表 DOM 路径可用；DOM 优先于 API，两者不一致会在报告里并列标注。');
L.push('');
for (const [key, m] of Object.entries(FM.metrics)) {
  L.push(`### ${m.label}  [${key}]  type=${m.type} unit=${m.unit}`);
  const dom = labelCandidates(snap.text, m.aliases, Object.values(FM.metrics).flatMap(x => x.aliases));
  L.push(`  [页面文本命中 ${dom.length} 条]`);
  dom.slice(0, 8).forEach(c => {
    const v = parseMetric(c.raw, m.type);
    L.push(`    raw="${c.raw}"  ->  ${v == null ? '解析失败' : v}  | 上下文: ${c.context}`);
  });
  if (!dom.length) L.push('    （无 —— 该指标可能要在达人详情页才展示，或别名需按平台文案补进 aliases）');
  const api = [];
  for (const b of cap.bodies) {
    for (const h of deepFind(b.data, m.jsonKeys || [], 10)) {
      const v = parseMetric(h.value, m.type);
      api.push({ url: b.url, path: h.path, raw: h.value, parsed: v });
    }
  }
  L.push(`  [API 候选 ${api.length} 条]`);
  api.slice(0, 12).forEach(h => L.push(`    ${h.path} = ${JSON.stringify(h.raw)} -> ${h.parsed == null ? '解析失败' : h.parsed}  (${h.url})`));
  L.push('');
}
L.push('## 三、下一步');
L.push('  1) 打开 probe/page_text.txt 核对 5 个指标在页面上是否真的显示、单位是什么（元 / 万元 / %）。');
L.push('  2) 若 DOM 路径已能取到全部 5 项，field_map.json 的 jsonPaths 保持空数组即可，直接跑 01_collect.mjs。');
L.push('  3) 若某项只在接口里有，把上面确认的 path 填进 jsonPaths，并把匹配的接口 URL 记进 references/field-notes.md。');
L.push('  4) 平台文案与模板不符时，改 field_map.json 的 aliases / jsonKeys，不要改脚本。');
fs.writeFileSync(path.join(OUT, 'field_candidates.txt'), L.join('\n'), 'utf8');

log(`完成：捕获 ${responses.length} 个 JSON 响应`);
log(`  -> ${path.join(OUT, 'responses.json')}`);
log(`  -> ${path.join(OUT, 'field_candidates.txt')}`);
log(`  -> ${path.join(OUT, 'page_text.txt')}`);
for (const [key, m] of Object.entries(FM.metrics)) {
  const dom = labelCandidates(snap.text, m.aliases, Object.values(FM.metrics).flatMap(x => x.aliases)).filter(c => parseMetric(c.raw, m.type) != null);
  log(`  ${m.label}: 页面文本可解析 ${dom.length} 条${dom.length ? ` (例: ${dom[0].raw})` : ' —— 需补别名或填 jsonPaths'}`);
}
s.close();
