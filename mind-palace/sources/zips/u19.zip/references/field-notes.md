# 技术字段笔记 · 抖音来客达人广场

> 本文区分两类信息：**【已核实】**＝公开资料可查的官方口径；**【待现场确认】**＝必须在用户已登录的浏览器里跑 `00_probe.mjs` 才能确定的内容。后者不得当作事实写进脚本或报告。

## 一、指标口径

### 视频带货力（等级，非数值）【已核实】

- 抖音生活服务于 2025-04-30 更新带货力等级体系，按内容体裁拆为「视频带货力等级」与「直播带货力等级」。本技能只用**视频带货力**。
- 等级 Lv0–Lv8，共 9 级 3 阶段：
  - Lv0：暂不符合 Lv1–Lv8 要求，或存在严重违规行为
  - Lv1–Lv3 本地活跃探店达人：重点考核本地商户探店数、本地商户核销数
  - Lv4–Lv6 稳定出单的职业达人：考核有效支付金额、有效核销金额、Top10 视频稿均播放量
  - Lv7–Lv8 有粉丝号召力的宝藏达人：在上一区间基础上新增稿均粉丝支付金额、稿均粉丝播放量
- **按自然月统计，每月 6 日评出当月等级，展示至次月 5 日。** 因此每月 6 日前后重跑，等级可能整体切换；报告必须写快照时点。
- 本技能只做 `Lv / levelMax` 的线性映射，不还原官方评级算法，也不推断等级背后的具体考核值。

### 其余四项（数值）【部分已核实】

| 指标 | 含义 | 单位风险 |
|---|---|---|
| 平均种草销售额 | 达人通过带货视频带来的平均成交金额（生活服务口径，非星图电商的「场均销售额」） | 页面可能显示「元」或「万元」，必须现场确认 |
| 稿均播放量 | 带货视频的平均播放量 | 可能显示「1.2万」，需换算 |
| 稿均千次GMV | 每千次播放对应的成交金额，衡量流量变现效率 | 同上，注意与「平均种草销售额」的分母不同 |
| 30日核销率 | 近 30 天支付成功订单中实际到店核销的比例 | 百分比；**支付 GMV ≠ 核销后收入**，达人佣金通常按核销结算 |

- 核销率定义【已核实】：用户购买团购套餐/代金券后实际到店完成消费、核销订单的比例；服务分考核里看 30 天窗口（分子＝核销成功订单数，分母＝支付成功订单数），近 30 天核销间夜 < 100 时该项不得分（该细则来自酒旅服务分文档，**是否适用于达人广场的达人侧核销率待现场确认**）。
- 达人广场披露 14 / 30 / 90 日带货数据，并有「达人概览」模块展示短视频与直播各自的优势品类与 90 日战绩。【已核实】
- **本技能五项指标在页面上的确切文案、展示位置（列表页 or 详情页）、单位，均为【待现场确认】。** `field_map.json` 的 aliases 是候选文案，不是官方定名。

### 入口与权限【已核实】

- 入口：抖音来客 →「达人带货—达人广场」或「推广—找达人」；可切换短视频达人 / 直播达人，按所在地与带货品类筛选。
- 支持代运营商家、非代运营商家及服务商查看；直营商家查看后可直接发起合作计划，代运营商家当前仅可查看、由服务商发起。
- web 端路径含 `life.douyin.com/p/liteapp/alliance_merchant/merchant/talent/square`；**未登录时该 URL 会跳到抖音来客官网介绍页**，不返回任何达人数据。

公开资料参考：
- 抖音生活服务学习中心《【撮合工具】达人广场_一站式看数据约达人》 https://lifexue.com/rule/detail/138437
- 《团购达人带货力新等级划重点啦》（2025-04-30，中国青年网转载）
- 抖音生活服务学习中心《服务分考核指标解读-核销率》 https://lifexue.com/knowledge/detail/259671553538
- 巨量星图《达人电商带货能力分析》 https://star.toutiao.com/help-center/demander/114909 —— **注意这是电商星图口径，不要与本地生活达人广场混用**

## 二、采集路径（2026-11-11 实测定稿：API 直采）

**结论：不要走页面 UI 搜索，直接在页面上下文 POST search 接口。**

实测过程（全部失败于同一原因 —— React state 不同步，关键词进不了请求）：
1. 原生 setter + input/change 事件填搜索框 → 输入框 DOM value 正确，但点「查询」发出的 POST body 里没有关键词字段；
2. CDP `Input.insertText`（真实输入管线）+ 点「查询」→ 同样不带关键词；
3. 真实回车（`Input.dispatchKeyEvent`）→ 完全不触发 search 请求；
4. 输入后等联想下拉 → 达人广场的昵称搜索框不弹达人联想（之前抓到的 associate 接口是全局菜单联想，与达人无关）。

**定稿方案**：
- 接口：`POST https://life.douyin.com/life/alliance/v1/merchant/talent_square/talent/search/?root_life_account_id=<账号ID>&life_biz_view_id=22&life_account_biz_ids=`
- 关键词字段：**body 顶层的 `keyword`**（从前端 chunk `merchant_pc/resource/51d18eea.js` 的接口定义源码确认；完整参数表还有 filter_list / sort_param / tab_param / talent_uid_list 等）。
- 基础 body：`{"enable_filter_item_params":true,"filter_item_params":{"mediaType":["VideoAndLive"]},"request_source":2,"page":1,"page_size":10,"from_type":5}` + `keyword`。
- 在**页面上下文**里 `fetch`（同源 + credentials: 'include' 自动带登录 cookie），无独立签名，直接可用。
- `filter_item_params` 里的字段全部是 **LIST 类型**：传字符串会被服务端 400（`[JSON-TO-THRIFT] expect type LIST`）——这个报错可用来快速验证字段是否存在于 schema。
- 01_collect 启动时 reload 一次页面，从网络捕获里自动发现 searchUrl（root_life_account_id 随账号变，不要写死依赖）。

### 响应结构（已确认）

```
$.total_count / $.has_more / $.status_code / $.now
$.talent_list[] = {
  nick_name, unique_id(抖音号), uid, aweme_url(达人主页链接，含 sec_uid),
  item_level(视频带货力, 纯数字0-8), live_level, content_level, credit_score(万分制, 9800=98),
  fans_count('37.62 万'), local_fans_count,
  talent_display_info.fans_count_display.statistice_value.digit_value(精确粉丝数 376220),
  city_name / resident_city_name, self_intro,
  sale_detail.item_avg_indirect_gmv_30d   平均种草销售额 ('4305')
  sale_detail.item_play_cnt_avg_30d       稿均播放量 ('12.42 万')
  sale_detail.item_gpm_30d                稿均千次曝光GMV ('592')
  sale_detail.verify_rate_30d             30日核销率 ('13.46%')
  sale_detail.item_pay_amt_avg_30d        稿均销售额 ('7.56 万')
  sale_detail.item_finish_rate_30d        稿均完播率 ('3.1%')
  sale_detail.item_anchor_click_ratio_30d POI锚点点击率 ('7.34%')
  sale_detail.stat_tags[]                 城市排名标签（如「北京前 1%」·稿均播放量）
}
```

### 身份：抖音号搜索才是精确的（2026-11-11 实测）

| 搜索方式 | 实测结果 |
|---|---|
| `keyword: 昵称` | **模糊匹配**。「小师妹」返回 total_count=1000，第一页全是同名大号（38万/190万粉）；「西安美食侦探」4 条（3 个 Lv0 仿号） |
| `keyword: 抖音号`（如 `YY459459459`） | **精确返回 1 条**，就是要找的人 |

因此流程固定为：短链 → 解析 sec_uid → 浏览器渲染分享页读**抖音号** → 按抖音号搜索。

- sec_uid 解析：短链 HTTP 302 逐跳（≤6 跳），兼容 `sec_uid=` 与 `/user/MS4w…` 两种写法。实测 22/22 全部解析成功。
- 分享页 `https://www.iesdouyin.com/share/user/<sec_uid>` 由 JS 渲染，**服务端 fetch 拿不到昵称**，必须用浏览器打开；文本里「抖音号：xxx」前一行（跳过「关注」）就是昵称。
- 匹配优先级：sec_uid > 抖音号 > 链接昵称精确 > 清单昵称精确 > 昵称模糊（标待核对）。
- **有抖音号但广场查不到 = 该达人未入驻广场**，不拿同名账号顶替（会直接毁掉排名可信度）。

### 短链查重（真实踩到）

同一份名单里「美食分享」的短链解析出的 sec_uid 与「于大雪」完全相同 —— 用户贴错了链接。第 0.5 步做 sec_uid/抖音号查重，重复行剔除写 `excluded.json`，报告顶部提示补正。另发现清单名与链接真实昵称不一致（「甜儿呀」→「甜儿吖〰️」），属错字，按同一人处理但标注。

### 粉丝数：两个口径，别当成同一个数

| 字段 | 含义 | 示例 |
|---|---|---|
| `fans_count` / `talent_display_info.fans_count_display…digit_value` | 广场展示的粉丝数 | 张梦阿 7.67 万 / 76682 |
| `local_fans_count` | 本地（城市）粉丝数 | 张梦阿 6697 |
| 用户标注（来自抖音主页） | 主页实时总粉丝 | 张梦阿 10.2 万 |

实测三者互不相同：小师妹823 主页 1.3 万、广场 3521、本地 1479（差 73%）。**原因未确认**（可能是统计时点或口径差异），因此两列并列展示、不择优；评分不含粉丝数，不影响排名。

### 页面结构（供 UI 诊断参考）

- 搜索框「搜索达人昵称/抖音号」在页面顶部（y≈17，class `life-core-input`，无 placeholder）；筛选区「查询/重置」按钮在 y≈316（`byted-btn`），两者属**不同组件** —— 「查询」只应用筛选条件，与昵称搜索框无关。
- 列表表格 label 与值分行，页面文本按指标名抓值不可行（label 下一行是下一个 label）。

### 环境要点（GeminiBrowser 实测）

- GeminiBrowser（Chromium 128 套壳）平时不带调试端口；用 `--remote-debugging-port=9222 --profile-directory="Profile 3" --restore-last-session` 重启即可连上，数据目录 `C:\Users\admin\AppData\Local\GeminiBrowser\User Data`。
- 优雅关闭可能被「确认关闭」弹窗拦住且无法程序化确认（COM / SendKeys 均被沙盒拦截），必要时结束主进程再重启；登录态在磁盘上不丢。
- 达人广场 URL 若带旧 groupid → 「协作者关系不存在」。当前账号 groupid 以工作台首页（/p/home?groupid=…）为准，或点左侧菜单「达人广场」进入。
- 页面加载初期标签可能短暂处于 about:blank / 空标题状态，连接后先等渲染再操作。

## 三、字段映射方法

1. 正常情况直接复制 `assets/field_map.example.json`（2026-11-11 已实测确认）。
2. 平台改版后跑 `node scripts/00_probe.mjs`，输出 `probe/field_candidates.txt`。
3. 指标取不到时，优先怀疑：字段名改版（改 `jsonKeys`/`jsonPaths`）、响应结构变化（跑一次 reload 捕获看 `talent_list` 是否还在）、账号权限（代运营账号部分指标不可见）。
4. 要挖新字段名：从前端 chunk 源码找 —— 在页面上下文遍历 `performance.getEntriesByType('resource')` 里的 JS（字节 CDN 域名），搜 `talent_square/talent/search`，其接口定义函数会列出全部 body 参数名。用「传字符串得 400 expect type LIST」可快速验证字段是否在 schema 里。
5. 每次平台改版或换账号权限后，重跑第 0 步复核。

### 现场确认记录

| 日期 | 账号/权限 | 指标 | 接口字段 | 单位/格式 | 确认人 |
|---|---|---|---|---|---|
| 2026-11-11 | 某复合烘焙C（商家账号，超级管理员） | 视频带货力 | `item_level` | 纯数字 0-8 | Miro（实测） |
| 2026-11-11 | 同上 | 平均种草销售额 | `sale_detail.item_avg_indirect_gmv_30d` | 元，字符串如 '4305' | Miro（实测） |
| 2026-11-11 | 同上 | 稿均播放量 | `sale_detail.item_play_cnt_avg_30d` | 字符串如 '12.42 万' | Miro（实测） |
| 2026-11-11 | 同上 | 稿均千次曝光GMV | `sale_detail.item_gpm_30d` | 元/千次播放，如 '592' | Miro（实测） |
| 2026-11-11 | 同上 | 30日核销率 | `sale_detail.verify_rate_30d`（达人顶层另有 `verify_rate_30d`） | 字符串如 '13.46%' | Miro（实测） |
| 2026-11-11 | 同上 | 搜索关键词 | body 顶层 `keyword` | 字符串 | Miro（前端源码确认） |
| 2026-11-11 | 同上 | 精确粉丝数 | `talent_display_info.fans_count_display.statistice_value.digit_value` | 数字如 376220 | Miro（实测） |

## 四、风控信号（命中即停，不重试）

- 页面文本出现：扫码登录 / 请登录 / 登录后可查看 / 账号登录 / 验证手机
- 页面文本出现：安全验证 / 滑动验证 / 验证码 / 访问频繁 / 操作过于频繁
- 接口连续 403 / 429 / 登录态跳转
- 连续多位达人 5 项指标全空

处理：立即停止采集，保存已采结果（可按 `--only` 续跑），向用户报告具体信号。等待通常无效；若属 IP 级风控，需换网络出口。用户明确要求「本次放宽重试」时，仅对本次任务临时放宽，不改长期规则。

## 五、报价与投产（用户侧数据）

- 用户提供的单条报价只做参考分析，**不进评分**（评分口径是平台官方五项指标，掺入报价会让"能力"和"性价比"混在一起）。
- 派生指标：`投产参考 = 稿均种草销售额 ÷ 单条报价`，仅在该达人两项都有值时计算；不含坑位费、佣金、核销折损，报告里必须写清这是单条稿的粗略参考。
- 实测本批 21 位里有 3 位 `<100`，投产参考留空而不是补 0。

## 六、数值解析约定

- `parseNumber`：`¥3,456` → 3456；`1.2万` → 12000；`78.5%` → 78.5；`1.2亿` → 120000000；`'7.56 万'`（带空格）→ 75600。
- **`<100`、`<3`（平台隐藏精确值的下界标记）→ `null`（缺失）**：如「稿均销售额 <100」只说明不足 100，没有可比较的精确值，取边界值会高估（2026-11-11 实测仿号达人大量出现 `<100`）。
- `parseLevel`：接受纯数字 0-8（接口原样）、`Lv5`、`5级`；仅出现阶段名（如「稳定出单的职业达人」）返回 `null`，**不猜测具体级别**。
- `—` / `-` / `暂无` / `无数据` / `达人未授权` / `未公开` / 空串 → `null`（缺失），**与 0 严格区分**。
- `credit_score` 是万分制（9800 = 98 分），展示时除以 100。
- 「12.42 万」换算后要 `Math.round(n*100)/100`，否则会带出 `22200.000000000004` 这类浮点尾巴写进 CSV。
- `rawUnparsed` 字段保留平台原文（如 `<100`），报告显示「<100（低于平台披露下限）」而不是空白。
