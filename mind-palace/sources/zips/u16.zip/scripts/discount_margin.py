#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""折扣&毛利计算模型 — 确定性计算。

口径唯一真源：资料库《折扣率毛利四象限模型》
https://www.workbuddy.cn/space/d/aDvo98v2mtmDcQgv1H3XoE
公式、假设、四象限原文见 references/model-definition.md。

与页面 JS 的差异（刻意为之）：
  页面对输入做静默 clamp（R0>=0.5, R1>=0.1, k>=0.02）以免交互时除零；
  本脚本不静默改数据，非法输入直接报错并说明原因，避免「输入被悄悄改了」。
  数值展示沿用页面 JS 的 Math.round（floor(x+0.5)）语义，保证与页面逐位一致。
"""

import argparse
import json
import math
import sys

SOURCE = "https://www.workbuddy.cn/space/d/aDvo98v2mtmDcQgv1H3XoE"
DEMO = {"r0": 60.0, "k0": 65.5, "m0": 72.0,
        "r1": 52.7, "k1": 87.5, "m1": 75.0}

# 页面结论区原文，禁止改写
QUADRANTS = {
    "量增 · 利增": "折扣与流量同时正向。建议：把当前折扣率固化为常规水位，不要再靠加码折扣冲量；把增量预算投到复购和新品，而不是普惠券。",
    "量减 · 利增": "毛利额在涨，但靠的是低食材成本率的杠杆，不是量。建议：守住下方平衡点，别再为了冲量把折扣率往回压；优先修复购与到店客流，折扣从普惠改成定向（新客、沉睡、高毛利品）。",
    "量减 · 利减": "折扣没换来量，量又丢了。建议：先止跌再谈利润——核查被砍的优惠是不是集中在引流款和高频品，必要时分品类恢复定向优惠，同时看应收毛利率是否也被产品结构拖累。",
    "量增 · 利减": "量上来了，但增量毛利被折扣吃掉。建议：折扣换量的边际已不划算，把普惠折扣改成定向，或给优惠设置门槛与上限，优先保毛利额而不是单量。",
}

ASSUMPTIONS = [
    "优惠全部由商家承担",
    "食材成本随应收线性（成本卡理论值，未含损耗与报废）",
    "两期天数与口径一致",
]


def js_round1(v):
    """复刻页面 n1(): (Math.round(v*10)/10).toFixed(1)。"""
    if not math.isfinite(v):
        return None
    r = math.floor(v * 10 + 0.5) / 10
    return 0.0 if r == 0 else r


def fmt1(v):
    r = js_round1(v)
    return "—" if r is None else "{:.1f}".format(r)


def sgn(v):
    return "+" if v >= 0 else "−"


def abs1(v):
    return fmt1(abs(v))


def check(name, value, lo, hi, inclusive_lo=True):
    if not math.isfinite(value):
        raise ValueError("{} 不是有效数字：{}".format(name, value))
    bad = (value < lo if inclusive_lo else value <= lo) or value > hi
    if bad:
        raise ValueError("{} 应为 {} {} ~ {}（当前 {}）。页面会静默 clamp，本脚本不代改数据。".format(
            name, "≥" if inclusive_lo else ">", lo, hi, value))


def compute(r0, k0, m0, r1, k1, m1, unit="万元"):
    """完整移植页面 compute()。k/m 传百分数（0-100），R 单位自定但两期一致。

    返回 inputs 中的 k/m 为比例（0-1），与口径公式一致。
    """
    check("R0", r0, 0, float("inf"), inclusive_lo=False)
    check("R1", r1, 0, float("inf"), inclusive_lo=False)
    for nm, v in (("k0", k0), ("k1", k1)):
        check(nm + "(%)", v, 0, 100, inclusive_lo=False)
    for nm, v in (("m0", m0), ("m1", m1)):
        check(nm + "(%)", v, 0, 100, inclusive_lo=True)

    kr0, kr1 = k0 / 100.0, k1 / 100.0
    mr0, mr1 = m0 / 100.0, m1 / 100.0

    S0, S1 = r0 / kr0, r1 / kr1
    G0 = r0 - (1 - mr0) * S0
    G1 = r1 - (1 - mr1) * S1
    a = 1 - (1 - mr1) / kr1
    b = 1 - (1 - mr0) / kr0
    dS = (S1 / S0 - 1) * 100
    dG = G1 - G0
    pc = (kr1 / kr0 - 1) * 100
    e = dS / pc if abs(pc) > 0.05 else None
    if e is not None and abs(e) < 0.005:
        e = None

    if dG >= 0 and dS >= 0:
        q = "量增 · 利增"
    elif dG >= 0 and dS < 0:
        q = "量减 · 利增"
    elif dG < 0 and dS < 0:
        q = "量减 · 利减"
    else:
        q = "量增 · 利减"

    bal = None
    if a <= 0.001:
        bal_status = "a_nonpositive"
        bal_text = "现实收毛利率已≤0，卖一件亏一件，不存在可用的平衡点——先把折扣率或应收毛利率修回正区间。"
    elif b <= 0.001:
        bal_status = "b_nonpositive"
        bal_text = "基准期实收毛利率已≤0，两期不可比，先核对原口径再设目标。"
    else:
        bal_status = "ok"
        R1star = b / a * r0
        S1star = R1star / kr1
        lim = (R1star / r0 - 1) * 100
        slim = (S1star / S0 - 1) * 100
        pad = r1 - R1star
        bal = {"r1_star": R1star, "s1_star": S1star,
               "lim_pct": lim, "slim_pct": slim, "pad": pad}
        bal_text = (
            "利润平衡点目标：现实收 ≥ {} {}（即实收最多只能 {}{}%，再多掉就亏毛利）；"
            "对应销量底线：应收 ≥ {} {}（较原 {}{}%）；".format(
                fmt1(R1star), unit, sgn(lim), abs1(lim), fmt1(S1star), unit,
                sgn(slim), abs1(slim))
            + ("当前安全垫：现实收高出平衡点 {} {}，毛利额 +{} {}。".format(
                fmt1(pad), unit, abs1(dG), unit)
               if pad >= 0 else
               "当前已跌破平衡点 {} {}，毛利额 −{} {}，需要补量或再收折扣。".format(
                   abs1(pad), unit, abs1(dG), unit))
        )

    return {
        "inputs": {"r0": r0, "r1": r1, "k0": kr0, "k1": kr1, "m0": mr0, "m1": mr1},
        "metrics": {"s0": S0, "s1": S1, "g0": G0, "g1": G1,
                    "a": a, "b": b, "dR": r1 - r0, "dR_pct": (r1 - r0) / r0 * 100,
                    "dS_pct": dS, "dG": dG, "da_pp": (a - b) * 100,
                    "pc_pct": pc, "elasticity": e},
        "quadrant": q,
        "quadrant_advice": QUADRANTS[q],
        "balance": bal,
        "balance_status": bal_status,
        "balance_text": bal_text,
        "assumptions": ASSUMPTIONS,
        "source": SOURCE,
    }


def render(r, unit, label0, label1, demo):
    i, m = r["inputs"], r["metrics"]
    lines = []
    if demo:
        lines.append("⚠️ DEMO／自检模式：以下为页面默认演示参数，禁止用于任何客户交付结论。")
    lines.append("【折扣&毛利计算模型】口径真源：资料库《折扣率毛利四象限模型》 " + SOURCE)
    lines.append("")
    lines.append("输入（单位：{}）".format(unit))
    lines.append("  {}：实收 {}，折扣率 {:.1f}%，应收毛利率 {:.1f}%".format(
        label0, fmt1(i["r0"]), i["k0"] * 100, i["m0"] * 100))
    lines.append("  {}：实收 {}，折扣率 {:.1f}%，应收毛利率 {:.1f}%".format(
        label1, fmt1(i["r1"]), i["k1"] * 100, i["m1"] * 100))
    lines.append("")
    lines.append("核心指标")
    lines.append("  实收变化 ΔR：{}{} {}（{}{}%）".format(
        sgn(m["dR"]), abs1(m["dR"]), unit, sgn(m["dR_pct"]), abs1(m["dR_pct"])))
    lines.append("  实收毛利率 a：{:.1f}%（原 {:.1f}%，{}{}pp）".format(
        m["a"] * 100, m["b"] * 100, sgn(m["da_pp"]), abs1(m["da_pp"])))
    lines.append("  毛利额 G1：{} {}（原 {} {}，{}{} {}）".format(
        fmt1(m["g1"]), unit, fmt1(m["g0"]), unit, sgn(m["dG"]), abs1(m["dG"]), unit))
    lines.append("  销量变化 dS（应收）：{}{}%（{} {} → {} {}）".format(
        sgn(m["dS_pct"]), abs1(m["dS_pct"]), fmt1(m["s0"]), unit, fmt1(m["s1"]), unit))
    lines.append("")
    lines.append("当前落在：{}".format(r["quadrant"]))
    lines.append("  " + r["quadrant_advice"])
    lines.append("")
    lines.append("利润平衡点")
    lines.append("  " + r["balance_text"])
    lines.append("  实收单价变化：{}{}%　·　价格弹性：{}".format(
        sgn(m["pc_pct"]), abs1(m["pc_pct"]),
        "—" if m["elasticity"] is None else "{:.2f}".format(m["elasticity"])))
    lines.append("  （弹性绝对值＞1 说明量的损失比价的收益更快）")
    lines.append("")
    lines.append("模型假设：" + "、".join(r["assumptions"]) + "。")
    lines.append("提示：成本卡理论毛利额未含损耗与报废，会系统性高于财报实际毛利额。")
    return "\n".join(lines)


def self_check():
    """用页面显示值逐项核对，口径变更时第一时间发现偏差。"""
    r = compute(**DEMO)
    m, b = r["metrics"], r["balance"]
    expected = [
        ("S0", fmt1(m["s0"]), "91.6"), ("S1", fmt1(m["s1"]), "60.2"),
        ("G0", fmt1(m["g0"]), "34.4"), ("G1", fmt1(m["g1"]), "37.6"),
        ("dS%", sgn(m["dS_pct"]) + abs1(m["dS_pct"]), "−34.3"),
        ("dG", sgn(m["dG"]) + abs1(m["dG"]), "+3.3"),
        ("a%", fmt1(m["a"] * 100), "71.4"), ("b%", fmt1(m["b"] * 100), "57.3"),
        ("pc%", sgn(m["pc_pct"]) + abs1(m["pc_pct"]), "+33.6"),
        ("e", "—" if m["elasticity"] is None else "{:.2f}".format(m["elasticity"]), "-1.02"),
        ("R1*", fmt1(b["r1_star"]), "48.1"), ("S1*", fmt1(b["s1_star"]), "55.0"),
        ("pad", fmt1(b["pad"]), "4.6"), ("象限", r["quadrant"], "量减 · 利增"),
    ]
    failed = [(n, got, exp) for n, got, exp in expected if got != exp]
    for n, got, exp in expected:
        print("  {:<6} {}  {}".format(n, "PASS" if got == exp else "FAIL",
                                      got if got == exp else "{} != 期望 {}".format(got, exp)))
    print("\n自检结果：{}（{}/{} 项吻合资料库页面显示值）".format(
        "PASS" if not failed else "FAIL", len(expected) - len(failed), len(expected)))
    return 0 if not failed else 1


def main():
    p = argparse.ArgumentParser(description="折扣&毛利计算模型（口径真源见 references/model-definition.md）")
    p.add_argument("--r0", type=float, help="基准期实收")
    p.add_argument("--k0", type=float, help="基准期折扣率，百分数如 65.5")
    p.add_argument("--m0", type=float, help="基准期应收毛利率，百分数如 72")
    p.add_argument("--r1", type=float, help="当期实收")
    p.add_argument("--k1", type=float, help="当期折扣率，百分数如 87.5")
    p.add_argument("--m1", type=float, help="当期应收毛利率，百分数如 75")
    p.add_argument("--unit", default="万元", help="金额单位，默认 万元")
    p.add_argument("--label0", default="基准期", help="基准期标签")
    p.add_argument("--label1", default="当期", help="当期标签")
    p.add_argument("--json", action="store_true", help="输出 JSON")
    p.add_argument("--demo", action="store_true", help="用页面默认演示参数跑一次（强制标注 DEMO）")
    p.add_argument("--self-check", action="store_true", help="自检：与页面显示值逐项比对")
    a = p.parse_args()

    if a.self_check:
        return self_check()

    vals = {k: getattr(a, k) for k in ("r0", "k0", "m0", "r1", "k1", "m1")}
    missing = [k for k, v in vals.items() if v is None]
    provided = [k for k, v in vals.items() if v is not None]
    if a.demo:
        if provided:
            print("--demo 仅用于自检，不能与自定义参数同时使用", file=sys.stderr)
            return 2
        vals = dict(DEMO)
        if a.json:
            print("⚠️ DEMO：以下数值来自页面默认演示参数，禁止用于客户交付。", file=sys.stderr)
    elif missing:
        p.error("缺少参数 {}；缺参数先向用户要齐，不要用演示值补位。".format(", ".join("--" + k for k in missing)))

    try:
        r = compute(unit=a.unit, **vals)
    except ValueError as e:
        print("输入有误：{}".format(e), file=sys.stderr)
        return 2
    r["demo"] = a.demo
    r["unit"] = a.unit
    r["labels"] = {"base": a.label0, "current": a.label1}
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print(render(r, a.unit, a.label0, a.label1, a.demo))
    return 0


if __name__ == "__main__":
    sys.exit(main())
