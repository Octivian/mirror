# 技术字段笔记（小红书网页版，2026-11 实测）

供排查采集失败、字段变更、改版适配时查阅。所有结论来自 Chrome CDP + SSR 页面实测。

## 1. 短链解析

- `xhslink.cn/o/<code>` 用 `GET` + 浏览器 UA，`HEAD` 可能不返回正确 `location`。`fetch(url, {redirect:'manual'})` 读 `location` 头，最多跟 5 跳。
- **实测：一批 19 条 `xhslink.cn/o/...` 全部 302 到 `www.xiaohongshu.com/user/profile/<24位hex>?xsec_token=...`，是博主主页，不是笔记详情页。**
- 长链两种形态：`/user/profile/{userId}`（主页）、`/explore/{noteId}` 或 `/discovery/item/{noteId}`（笔记）。
- `xsec_token` 是分享链接参数，有时效；主页 token 与每篇笔记的 `xsecToken` 不是同一个。笔记链接必须带自己的 `xsecToken`，否则可能打不开。
- 解析后先做类型确认并告知用户，再决定走哪条流程。

## 2. 主页 SSR 结构

- 页面 `window.__INITIAL_STATE__` 直出，无需等 `Page.loadEventFired`。
- 笔记列表：`__INITIAL_STATE__.user.notes[0]`，是 Vue ref 数组，**每项需 unwrap `_value`**；unwrap 后取 `noteCard`。
- `noteCard` 关键字段：`noteId` / `displayTitle` / `time`(毫秒) / `interactInfo.likedCount` / `xsecToken` / `type` / `sticky`。
- 追加分页走 `user_posted` 接口；首屏 SSR 一般已含该博主全部笔记（实测 30–62 篇），合并去重后可用。
- 主页元信息（昵称 / 粉丝 / 获赞与收藏 / 小红书号 / IP 属地 / 笔记数）用 `document.body.innerText` 按「粉丝」等标签取前一行最稳；HTML 正则容易漏。
- Vue 响应式对象直接 `JSON.stringify` 会踩循环引用/序列化坑；用 `Runtime.evaluate` 里手工挑字段返回纯对象，或拦接口 JSON。

## 3. 时间字段

- `noteCard.time` 是毫秒时间戳；**`noteId` 前 8 位十六进制 = 发布时间（ObjectId 时间戳），与 `time` 完全一致**，实测可互相校验。
- 时间窗口一律按**北京时间自然日、含今天**计算，不要用 UTC 自然日：
  ```
  todayStart(北京) = Date.parse(bjYmd + 'T00:00:00Z') - 8h
  start7  = todayStart - 6天 ; start15 = todayStart - 14天 ; start30 = todayStart - 29天
  daysAgo = (todayStart - 当天0点) / 86400e3
  ```
- 置顶笔记（`sticky=true`）时间可能很旧，按时间窗口自然排除，不要特殊处理。

## 4. 详情页与互动字段

- 详情页 SSR：`__INITIAL_STATE__.note.noteDetailMap[noteId].note`，含 `interactInfo`：
  `likedCount` / `collectedCount` / `commentCount` / `shareCount`。
- **0 值陷阱（踩过）**：收藏/评论/分享为 0 时平台返回空字符串 `""`，不是缺字段。`""` 必须按 `0` 处理，否则「赞/藏/评比例」和「收藏合计」会大面积缺失。用一篇高赞 + 一篇低赞笔记对照验证过。
- `"1.2万"` / `"3.4k"` 类缩写要换算成数字；纯数字字符串去掉千分位逗号。
- 点赞口径：优先详情页 `likedCount`，未采详情的用主页列表 `likedCount` 兜底，并在明细表标注来源。
- 收藏/评论/分享**只有详情页有**，主页列表没有。因此比例类指标必然是「已采详情样本」的口径，必须给出覆盖率。

## 5. CDP 采集效率与稳定性

- 导航后立即轮询 `Runtime.evaluate` 读 SSR（约 1.2 秒后即可），**不要 `Page.loadEventFired`**：等 load 会白等约 12 秒，实测速度从 ~17 秒/篇降到 ~3 秒/篇。
- 每篇之间加随机间隔（`MIN_GAP_MS=1200`、`MAX_GAP_MS=2000` 是实测可连续跑完 171 篇且不触发拦截的档位）。
- 结果边跑边落盘（`details/details_all.json`），重跑用已完成的 `noteId` 集合跳过，支持断点续跑与 `LIMIT` 分批。
- 一次只用一个标签页顺序跑，别并发。

## 6. 风控信号与处置

| 现象 | 级别 | 处置 |
|---|---|---|
| URL 带 `error_code=300012` +「IP存在风险」 | IP 级 | 换网络/出口 IP 再试，**等待无效**；cookie 不用重建 |
| 跳「安全限制」页、接口 461 / 429 / 403 | 账号/行为级 | 立即停止，等数小时~1 天，不短时重试 |
| 连续多条详情页异常 | 疑似拦截 | 暂停并报告，不继续后续步骤 |
| 单篇详情页 404 | 正常 | 笔记已删除，跳过即可 |

- 同一网络出口下**其它浏览器化访问会累加风险分**（实测：仅用 headless 打开一次搜索页截图就命中 300012）。正式采集前先小流量试跑一条验证是否放行。
- 默认遵守「不触发风控」铁律；仅在用户明确要求时对该次任务临时放宽重试，长期规则不改。

## 7. 常见坑速查

| 症状 | 原因 |
|---|---|
| 全部笔记采集失败 | 把 `userId` 当成 `noteId` 喂给单篇采集器 |
| 粉丝数取不到 / 是别人的 | 从 HTML 正则取，应改用 `innerText` 标签前一行 |
| 收藏/评论大面积缺失 | 把 `""` 当缺失，没按 0 处理 |
| 收藏率/评论率异常高（如评/赞=1.00） | 分母只有个位数赞的小样本失真，需样本可信度折算 |
| 窗口篇数对不上 | 用了 UTC 自然日，或忘了「含今天」 |
| 分数几乎全 0 | 线性归一被一条爆文压缩，改 log1p 对数归一 |
| 爆文率全 0 | 阈值定太高（本批 347 篇仅 2 篇破百赞），按分位数下调 |
