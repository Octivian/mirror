import fs from 'node:fs';

const TZ = 8 * 3600e3;
const now = Date.now();
const bjDate = t => t ? new Date(t + TZ).toISOString().slice(0, 10) : null;
const todayStart = (() => {
  const ymd = new Date(now + TZ).toISOString().slice(0, 10);
  return Date.parse(ymd + 'T00:00:00Z') - TZ;
})();
const start7 = todayStart - 6 * 86400e3;
const start15 = todayStart - 14 * 86400e3;
const start30 = todayStart - 29 * 86400e3;
const kw = JSON.parse(fs.readFileSync('keywords.json', 'utf8'));
const num = v => { if (v == null || v === '') return null; const s = String(v).replace(/,/g, ''); return /^\d+$/.test(s) ? Number(s) : null; };

function classify(title) {
  if (!title) return { cat: '其他', hits: [], inScope: false };
  const t = kw.tea.filter(k => title.includes(k));
  const b = kw.bake.filter(k => title.includes(k));
  if (t.length && b.length) return { cat: '茶饮+烘焙', hits: [...t, ...b], inScope: true };
  if (t.length) return { cat: '茶饮', hits: t, inScope: true };
  if (b.length) return { cat: '烘焙', hits: b, inScope: true };
  return { cat: '其他', hits: [], inScope: false };
}

const profiles = JSON.parse(fs.readFileSync('profiles_all.json', 'utf8')).sort((a, b) => a.idx - b.idx);
const allRows = [];
for (const p of profiles) {
  for (const r of p.rows) {
    const time = r.time ?? null;
    const liked = num(r.likedCount);
    const date = bjDate(time);
    const cls = classify(r.title);
    allRows.push({
      profileIdx: p.idx, profileLabel: p.label, author: p.nickname, userId: p.userId,
      noteId: r.noteId, title: r.title, time, date,
      daysAgo: time ? Math.floor((todayStart - (Date.parse(date + 'T00:00:00Z') - TZ)) / 86400e3) : null,
      listLikedCount: liked,
      in7: time != null && time >= start7,
      in15: time != null && time >= start15,
      in30: time != null && time >= start30,
      category: cls.cat, hits: cls.hits, inScope: cls.inScope,
      xsecToken: r.xsecToken, type: r.type, sticky: r.sticky,
    });
  }
}

const prio = r => r.inScope ? 1 : (r.in7 ? 2 : (r.in15 ? 3 : 4));
const seen = new Set();
const targets = allRows.filter(r => r.in30)
  .map(r => ({
    noteId: r.noteId, xsecToken: r.xsecToken, profileIdx: r.profileIdx,
    profileLabel: r.profileLabel, author: r.author, listLikedCount: r.listLikedCount,
    listTime: r.time, category: r.category, title: r.title, priority: prio(r),
  }))
  .filter(r => { if (seen.has(r.noteId)) return false; seen.add(r.noteId); return true; })
  .sort((a, b) => a.priority - b.priority || (b.listTime || 0) - (a.listTime || 0));
fs.writeFileSync('detail_targets.json', JSON.stringify(targets, null, 2), 'utf8');
fs.writeFileSync('all_rows.json', JSON.stringify(allRows, null, 2), 'utf8');

const summary = profiles.map(p => {
  const rows = allRows.filter(r => r.profileIdx === p.idx);
  const w = flag => rows.filter(flag);
  const sum = arr => arr.reduce((a, r) => a + (r.listLikedCount || 0), 0);
  const r7 = w(r => r.in7), r15 = w(r => r.in15), r30 = w(r => r.in30);
  const markedFans = num((p.label.match(/(\d+(?:\.\d+)?)\s*万?粉/) || [])[1]) || null;
  return {
    idx: p.idx, label: p.label, nickname: p.nickname, redId: p.redId, ip: p.ipLocation,
    fansReal: p.fans, fansMarked: markedFans, totalLikedCollected: p.totalLikedCollected,
    noteTotal: p.noteCount,
    n7: r7.length, likes7: sum(r7), n15: r15.length, likes15: sum(r15),
    n30: r30.length, likes30: sum(r30),
    n30Scope: r30.filter(r => r.inScope).length,
    likes30Scope: sum(r30.filter(r => r.inScope)),
    earliest: bjDate(Math.min(...rows.map(r => r.time).filter(Boolean))),
    latest: bjDate(Math.max(...rows.map(r => r.time).filter(Boolean))),
  };
});
fs.writeFileSync('stage_a_summary.json', JSON.stringify(summary, null, 2), 'utf8');

console.log('=== 时间窗口（北京时间）===');
console.log('今天', bjDate(now), '| 近7天起', bjDate(start7), '| 近15天起', bjDate(start15), '| 近30天起', bjDate(start30));
console.log('\n=== 博主汇总 ===');
console.log('序号 | 标注 | 昵称 | 实测粉丝 | 笔记总数 | 7天内篇/赞 | 15天内篇/赞 | 30天内篇/赞 | 30天内茶饮烘焙篇 | 时间跨度');
for (const s of summary) {
  console.log(`${s.idx} | ${s.label} | ${s.nickname} | ${s.fansReal} | ${s.noteTotal} | ${s.n7}/${s.likes7} | ${s.n15}/${s.likes15} | ${s.n30}/${s.likes30} | ${s.n30Scope} | ${s.earliest}~${s.latest}`);
}
console.log('\n合计：7天内 ' + allRows.filter(r => r.in7).length + ' 篇 / 15天内 ' + allRows.filter(r => r.in15).length + ' 篇 / 30天内 ' + allRows.filter(r => r.in30).length + ' 篇');
console.log('30天内茶饮烘焙类 ' + allRows.filter(r => r.in30 && r.inScope).length + ' 篇');
console.log('\n=== 30天内标题清单（用于核对分类关键词）===');
for (const r of allRows.filter(r => r.in30)) {
  console.log(`${r.profileIdx}\t${r.date}\t${r.listLikedCount}\t${r.category}\t${(r.hits || []).join(',')}\t${(r.title || '').slice(0, 60)}`);
}
