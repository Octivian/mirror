// 第 4 步：按「小红书投放筛号」六条规则算综合分，输出 score_data.json
// 规则：①近7/15天点赞越多越好 ②赞/藏/评越接近 1:1:1 越好 ③30天目标品类占比越高越好
//       ④主页风格越垂直（美食）越好 ⑤爆文率越高越好 ⑥越近的笔记流量越重要
// 依赖当前目录：profiles_all.json / all_rows.json / details/details_all.json
// 可选：config.json（权重与阈值）、manual.json（人工风格分与点评，缺失时自动降级为机器估计+模板论据）
import fs from 'node:fs';

const read = (f, d) => fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : d;
const CFG = Object.assign({
  weights: { A_wal: 22, A_avg7: 13, B_scope: 15, B_style: 10, C_hot15: 10, C_hot30: 6, C_max: 4, D: 20 },
  windows: { near: 7, mid: 15, long: 30 },
  decay: { near: 1.0, mid: 0.5, long: 0.2 },
  hotThreshold: 30, hundredThreshold: 100, bigThreshold: 500,
  smallSampleBase: 10, reliabilityBase: 10,
  marketPattern: '市集|面包节|咖啡节|凉好青年',
  grades: { S: 55, A: 42, B: 28 },
}, read('config.json', {}));
CFG.weights = Object.assign({ A_wal: 22, A_avg7: 13, B_scope: 15, B_style: 10, C_hot15: 10, C_hot30: 6, C_max: 4, D: 20 }, CFG.weights || {});
const MAN = read('manual.json', { style: {}, reason: {}, risk: {} });
const W = CFG.weights, WIN = CFG.windows, DEC = CFG.decay;
const marketRe = new RegExp(CFG.marketPattern);

const rows = read('all_rows.json', []);
const profiles = read('profiles_all.json', []);
const details = read('details/details_all.json', []);
if (!profiles.length || !rows.length) throw new Error('缺少 profiles_all.json / all_rows.json，请先跑 01/02 步');
const dmap = new Map(details.filter(d => d.ok).map(d => [d.noteId, d]));

const L = x => x.listLikedCount || 0;   // 平台对 0 赞返回空字符串 → null，按 0 处理（已抽样验证）
const sum = (a, f) => a.reduce((s, x) => s + f(x), 0);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const r1 = v => +v.toFixed(1), r2 = v => +v.toFixed(2);
const pctS = v => (+v).toFixed(1) + '%';
const wOf = x => x.daysAgo == null ? 0 : x.daysAgo < WIN.near ? DEC.near : x.daysAgo < WIN.mid ? DEC.mid : x.daysAgo < WIN.long ? DEC.long : 0;
const inWin = (x, w) => x.daysAgo != null && x.daysAgo < w;
function logNormFactory(values) {
  const logs = values.map(v => Math.log1p(Math.max(0, v)));
  const lo = Math.min(...logs), hi = Math.max(...logs);
  return v => hi === lo ? 0 : 100 * (Math.log1p(Math.max(0, v)) - lo) / (hi - lo);
}
// 无人工风格分时的降级估计：标题里出现美食相关词的比例
const FOOD = ['吃', '餐', '店', '饭', '面', '粉', '烧烤', '火锅', '奶茶', '咖啡', '面包', '蛋糕', '甜品', '探店', '美食', '夜宵', '料理', '日料', '烤肉', '糖水', '菜品', '烘焙', '小吃', '味道', '好吃'];
function autoStyle(list) {
  if (!list.length) return { s: 0, tag: '无笔记·无法判断', why: '近30天无笔记' };
  const hit = list.filter(x => FOOD.some(k => (x.title || '').includes(k))).length;
  const s = Math.round(hit / list.length * 100);
  return { s, tag: '机器估计·建议人工复核', why: `近${list.length}篇标题中约${hit}篇含美食词，属关键词粗估，非人工看主页结论` };
}

const P = profiles.map(p => {
  const all = rows.filter(x => x.profileIdx === p.idx);
  const a30 = all.filter(x => inWin(x, WIN.long));
  const a15 = a30.filter(x => inWin(x, WIN.mid));
  const a7 = a30.filter(x => inWin(x, WIN.near));
  const dd = a30.filter(x => dmap.has(x.noteId)).map(x => dmap.get(x.noteId));
  const st = (MAN.style || {})[String(p.idx)] || autoStyle(a30);

  const likes7 = sum(a7, L), likes15 = sum(a15, L), likes30 = sum(a30, L);
  const wal = sum(a30, x => L(x) * wOf(x));
  const scope = a30.filter(x => x.inScope), mkt = scope.filter(x => marketRe.test(x.title || ''));
  const scopeRaw = a30.length ? scope.length / a30.length * 100 : 0;
  const scopeAdj = a30.length ? (scope.length - mkt.length) / a30.length * 100 : 0;
  const smallSample = Math.min(1, a30.length / CFG.smallSampleBase);
  const hot15 = a15.filter(x => L(x) >= CFG.hotThreshold).length;
  const hot30 = a30.filter(x => L(x) >= CFG.hotThreshold).length;
  const maxLike = a30.length ? Math.max(...a30.map(L)) : 0;

  const Lc = sum(dd, x => x.likedCount || 0), Cc = sum(dd, x => x.collectedCount || 0), Mc = sum(dd, x => x.commentCount || 0);
  const rc = Lc ? Cc / Lc : 0, rp = Lc ? Mc / Lc : 0;
  const closeRaw = clamp((1 - (Math.abs(1 - rc) + Math.abs(1 - rp)) / 2) * 100, 0, 100);
  const reliability = Math.min(1, dd.length / CFG.reliabilityBase);

  return {
    idx: p.idx, nickname: p.nickname, label: p.label, redId: p.redId, ip: p.ipLocation,
    fans: p.fans, noteTotal: p.noteCount, totalLikedCollected: p.totalLikedCollected, url: p.url,
    n7: a7.length, likes7, avg7: a7.length ? likes7 / a7.length : 0,
    n15: a15.length, likes15, n30: a30.length, likes30,
    avg30: a30.length ? likes30 / a30.length : 0, wal, maxLike,
    hot15, hot30, hotRate15: a15.length ? hot15 / a15.length * 100 : 0, hotRate30: a30.length ? hot30 / a30.length * 100 : 0,
    n100: a30.filter(x => L(x) >= CFG.hundredThreshold).length,
    n500: a30.filter(x => L(x) >= CFG.bigThreshold).length,
    nScope: scope.length, nMarket: mkt.length, scopeRaw, scopeAdj, smallSample,
    nDetail: dd.length, coverRate: a30.length ? dd.length / a30.length * 100 : 0,
    Lc, Cc, Mc, rc, rp, closeRaw, reliability,
    styleScore: st.s, styleTag: st.tag, styleWhy: st.why,
  };
});

const normWAL = logNormFactory(P.map(x => x.wal));
const normAvg7 = logNormFactory(P.map(x => x.avg7));
const normMax = logNormFactory(P.map(x => x.maxLike));
const normL30 = logNormFactory(P.map(x => x.likes30));
P.forEach(p => {
  p.A1 = r1(normWAL(p.wal)); p.A2 = r1(normAvg7(p.avg7));
  p.A = r1(p.A1 * W.A_wal / 100 + p.A2 * W.A_avg7 / 100);
  p.B1 = r1(p.scopeRaw * p.smallSample); p.B2 = p.styleScore;
  p.B = r1(p.B1 * W.B_scope / 100 + p.B2 * W.B_style / 100);
  p.C1 = r1(p.hotRate15); p.C2 = r1(p.hotRate30); p.C3 = r1(normMax(p.maxLike));
  p.C = r1(p.C1 * W.C_hot15 / 100 + p.C2 * W.C_hot30 / 100 + p.C3 * W.C_max / 100);
  p.D0 = r1(p.closeRaw); p.D = r1(p.closeRaw * p.reliability * W.D / 100);
  p.total = r1(p.A + p.B + p.C + p.D);
});
P.sort((a, b) => b.total - a.total);
P.forEach((p, i) => {
  p.rank = i + 1;
  p.grade = p.total >= CFG.grades.S ? 'S 优先' : p.total >= CFG.grades.A ? 'A 次选' : p.total >= CFG.grades.B ? 'B 观察' : 'C 不建议';
});

// 论据/风险：优先用 manual.json 的人工点评，缺失时按数字自动生成，绝不编造
function autoReason(p) {
  return `近30天 ${p.n30} 篇 / ${p.likes30} 赞（篇均 ${r1(p.avg30)}），近7天 ${p.n7} 篇 / ${p.likes7} 赞，近15天 ${p.n15} 篇 / ${p.likes15} 赞；时间加权赞 ${r1(p.wal)}，最高单篇 ${p.maxLike} 赞；目标品类 ${p.nScope} 篇占 ${pctS(p.scopeRaw)}（剔活动稿 ${pctS(p.scopeAdj)}）；藏/赞 ${r2(p.rc)}、评/赞 ${r2(p.rp)}；主页垂直度 ${p.styleScore} 分`;
}
function autoRisk(p) {
  const r = [];
  if (p.n7 === 0) r.push(`近${WIN.near}天 0 篇，近期断流`);
  else if (p.avg7 < 5) r.push(`近${WIN.near}天篇均仅 ${r1(p.avg7)} 赞`);
  if (p.nMarket && p.nScope && p.nMarket / p.nScope >= 0.5) r.push(`${p.nScope} 篇品类里 ${p.nMarket} 篇是同一活动稿，剔后常态占比 ${pctS(p.scopeAdj)}`);
  if (p.coverRate < 40) r.push(`详情仅覆盖 ${pctS(p.coverRate)}，互动比样本薄`);
  if (p.rc < 0.1 && p.nDetail >= 3) r.push(`藏/赞 ${r2(p.rc)} 异常偏低，建议复核（${p.nDetail} 篇样本）`);
  if (p.n30 < CFG.smallSampleBase) r.push(`近${WIN.long}天仅 ${p.n30} 篇，占比已做小样本折扣`);
  if (p.styleTag.includes('机器估计')) r.push('主页垂直度为关键词粗估，未人工看主页');
  if (!p.nScope) r.push(`近${WIN.long}天无目标品类笔记`);
  return r.length ? r.join('；') : '未发现明显硬伤，按数据正常评估';
}
P.forEach(p => {
  p.reason = (MAN.reason || {})[String(p.idx)] || autoReason(p);
  p.risk = (MAN.risk || {})[String(p.idx)] || autoRisk(p);
});

// 明细行：点赞明细（近 long 天全部）+ 品类明细
const byProfile = new Map(profiles.map(p => [p.idx, p]));
const WEAK = ['甜品', '甜点', '饮料', '饮品', '🍰', '🧋', '☕', '🥐', '🍞', '🧁', '🍮', '🥤'];
const detailRows = rows.filter(x => inWin(x, WIN.long)).map(x => {
  const d = dmap.get(x.noteId), p = byProfile.get(x.profileIdx);
  const like = L(x);
  const window = inWin(x, WIN.near) ? `近${WIN.near}天` : inWin(x, WIN.mid) ? `${WIN.near + 1}-${WIN.mid}天` : `${WIN.mid + 1}-${WIN.long}天`;
  return {
    idx: x.profileIdx, author: p.nickname, date: x.date, daysAgo: x.daysAgo, window,
    title: x.title, noteId: x.noteId,
    url: `https://www.xiaohongshu.com/explore/${x.noteId}?xsec_token=${encodeURIComponent(x.xsecToken || '')}&xsec_source=app_share`,
    like, tag100: like >= CFG.hundredThreshold ? (like >= CFG.bigThreshold ? '大爆款' : '百赞') : (like >= CFG.hotThreshold ? '准爆' : ''),
    collect: d ? (d.collectedCount ?? null) : null, comment: d ? (d.commentCount ?? null) : null,
    share: d ? (d.shareCount ?? null) : null,
    weight: wOf(x), wal: r1(like * wOf(x)),
    category: x.category, hits: x.hits || [], inScope: x.inScope,
    market: marketRe.test(x.title || ''), weak: (x.hits || []).every(h => WEAK.includes(h)),
    hasDetail: !!d,
  };
}).sort((a, b) => a.idx - b.idx || (b.date || '').localeCompare(a.date || '') || b.like - a.like);
const scopeRows = detailRows.filter(x => x.inScope);

// 纯流量维度对比：无衰减 vs 时间加权，说明「越近越重要」的影响
const rankNo = new Map(P.map(p => ({ idx: p.idx, v: normL30(p.likes30) })).sort((a, b) => b.v - a.v).map((x, i) => [x.idx, i + 1]));
const rankWAL = new Map(P.map(p => ({ idx: p.idx, v: p.A1 })).sort((a, b) => b.v - a.v).map((x, i) => [x.idx, i + 1]));
const flowCompare = P.map(p => ({ idx: p.idx, nickname: p.nickname, likes30: p.likes30, wal: r1(p.wal), rankNo: rankNo.get(p.idx), rankWAL: rankWAL.get(p.idx), delta: rankNo.get(p.idx) - rankWAL.get(p.idx) })).sort((a, b) => a.rankWAL - b.rankWAL);
const verticalRank = P.slice().sort((a, b) => b.B - a.B).map((p, i) => ({ rank: i + 1, idx: p.idx, nickname: p.nickname, B: p.B, scopeRaw: r1(p.scopeRaw), scopeAdj: r1(p.scopeAdj), styleScore: p.styleScore, url: p.url }));

// 相关系数：log(粉丝) vs log(近 long 天点赞)
const numFans = f => typeof f === 'number' ? f : (String(f).includes('万') ? parseFloat(String(f)) * 10000 : parseFloat(String(f)) || 0);
const xs = P.map(p => Math.log10(numFans(p.fans) + 1)), ys = P.map(p => Math.log10(p.likes30 + 1));
const mx = xs.reduce((a, b) => a + b, 0) / xs.length, my = ys.reduce((a, b) => a + b, 0) / ys.length;
let num = 0, dx = 0, dy = 0; xs.forEach((x, i) => { num += (x - mx) * (ys[i] - my); dx += (x - mx) ** 2; dy += (ys[i] - my) ** 2; });
const corr = dx && dy ? +(num / Math.sqrt(dx * dy)).toFixed(3) : 0;

const sorted30 = rows.filter(x => inWin(x, WIN.long)).map(L).sort((a, b) => a - b);
const stats = {
  nProfile: profiles.length, nAll: rows.length,
  n7: rows.filter(x => inWin(x, WIN.near)).length,
  n15: rows.filter(x => inWin(x, WIN.mid)).length, n30: rows.filter(x => inWin(x, WIN.long)).length,
  likes30: sum(rows.filter(x => inWin(x, WIN.long)), L),
  nScope: scopeRows.length, nMarket: scopeRows.filter(x => x.market).length,
  marketLikes: sum(scopeRows.filter(x => x.market), x => x.like),
  nDetail: details.filter(d => d.ok).length,
  n100: rows.filter(x => inWin(x, WIN.long) && L(x) >= CFG.hundredThreshold).length,
  p50: sorted30[Math.floor(sorted30.length * .5)] || 0,
  p90: sorted30[Math.floor(sorted30.length * .9)] || 0,
  corrFansLikes: corr,
  hotMax: P.slice().sort((a, b) => b.D - a.D)[0]?.D || 0,
  closeMax: Math.max(0, ...P.map(p => p.closeRaw)),
  dateBj: new Date(Date.now() + 8 * 3600e3).toISOString().slice(0, 10),
};
fs.writeFileSync('score_data.json', JSON.stringify({
  generatedAt: new Date().toISOString(), config: CFG, profiles: P, flowCompare, verticalRank,
  detailRows, scopeRows, stats,
}, null, 1), 'utf8');

console.log('=== 综合排名 ===');
console.log('排名 | 博主 | 总分 | 等级 | A | B | C | D');
P.forEach(p => console.log(`${p.rank} | ${p.nickname} | ${p.total} | ${p.grade} | ${p.A} | ${p.B} | ${p.C} | ${p.D}`));
console.log(`\n明细 ${detailRows.length} 行 / 品类 ${scopeRows.length} 行 / 详情 ${stats.nDetail} 篇 / 近30天破百赞 ${stats.n100} 篇 / p50=${stats.p50} p90=${stats.p90}`);
console.log('⚠ 若 p90 远低于 hundredThreshold，务必在报告里说明「相对爆文阈值」为何下调，否则排名逻辑无法解释。');
