// 第 5 步：生成「整合结论页」HTML（4 分页）+ 3 个 CSV
// 所有文案由 score_data.json 驱动；换一批博主、换一套权重都能直接跑，不写死任何人名/数字
import fs from 'node:fs';
const D = JSON.parse(fs.readFileSync('score_data.json', 'utf8'));
const { profiles: P, detailRows, scopeRows, stats: S, config: CFG, flowCompare, verticalRank } = D;
const W = CFG.weights, WIN = CFG.windows, DEC = CFG.decay;
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const f1 = v => v == null ? '—' : (+v).toFixed(1);
const f2 = v => v == null ? '—' : (+v).toFixed(2);
const pct = v => v == null ? '—' : (+v).toFixed(1) + '%';
const a = (url, text, cls = '') => `<a href="${esc(url)}" target="_blank" rel="noopener" class="${cls}">${esc(text)}</a>`;
const badge = (t, cls = '') => `<span class="bd ${cls}">${esc(t)}</span>`;
const gcls = g => g[0] === 'S' ? 'gS' : g[0] === 'A' ? 'gA' : g[0] === 'B' ? 'gB' : 'gC';

function table(cols, rows, tid) {
  const th = cols.map(c => `<th${c.w ? ` style="min-width:${c.w}px"` : ''}>${esc(c.t)}</th>`).join('');
  const tb = rows.map(r => `<tr${r._cls ? ` class="${r._cls}"` : ''}>${cols.map(c => {
    const v = r[c.k]; return `<td${v == null || v === '—' ? ' class="na"' : ''}>${v == null ? '—' : (c.raw ? v : esc(v))}</td>`;
  }).join('')}</tr>`).join('');
  return `<div class="tw"><table${tid ? ` id="${tid}"` : ''}><thead><tr>${th}</tr></thead><tbody>${tb}</tbody></table></div>`;
}

// ---------- 结论页文案（全部数据驱动） ----------
const [t1, t2, t3] = P;
const medianB = P.map(p => p.B).sort((a, b) => a - b)[Math.floor(P.length / 2)];
const topFlow = P.slice().sort((a, b) => b.A - a.A).slice(0, 3);
const vertClean = verticalRank.filter(v => v.scopeAdj > 0).slice(0, 3);
const vertRisky = verticalRank.filter(v => v.scopeRaw > 0 && v.scopeAdj === 0).slice(0, 2);
const mostNotes = P.slice().sort((a, b) => b.n30 - a.n30)[0];
const bestAvg = P.slice().sort((a, b) => b.avg30 - a.avg30)[0];
const mktShare = S.nScope ? (S.nMarket / S.nScope * 100).toFixed(1) : '0';
const mktAvg = S.nMarket ? (S.marketLikes / S.nMarket).toFixed(1) : '0';
const coverMin = Math.min(...P.map(p => p.coverRate)), coverMax = Math.max(...P.map(p => p.coverRate));
const dMax = Math.max(...P.map(p => p.D));
const upMoves = flowCompare.filter(f => f.delta > 0).sort((a, b) => b.delta - a.delta).slice(0, 2);
const downMoves = flowCompare.filter(f => f.delta < 0).sort((a, b) => a.delta - b.delta).slice(0, 2);

const heroLead = `${esc(t1.nickname)}（${f1(t1.total)} 分，S 级）是综合分第一`;
const heroCaveat = (t2.B < medianB || t3.B < medianB)
  ? `但第 2、3 名 ${esc(t2.nickname)}（${f1(t2.total)}）与 ${esc(t3.nickname)}（${f1(t3.total)}）的垂直度分低于全池中位数，高分主要由流量项贡献 —— 若投放目标是「目标品类种草」，请看下方分用途选人。`
  : `前三名在流量与垂直度上相对均衡；仍建议对照下方分用途选人与风险列。`;

const rankTable = table([
  { t: '排名', k: 'rank', raw: 1, w: 52 }, { t: '博主（点开主页）', k: 'name', raw: 1, w: 130 },
  { t: '总分', k: 'total', raw: 1, w: 62 }, { t: '等级', k: 'grade', raw: 1, w: 70 },
  { t: 'A 流量', k: 'A', raw: 1, w: 70 }, { t: 'B 垂直', k: 'B', raw: 1, w: 70 },
  { t: 'C 爆文', k: 'C', raw: 1, w: 70 }, { t: 'D 互动', k: 'D', raw: 1, w: 70 },
  { t: '数据论据 / 为什么是这个分', k: 'reason', w: 430 }, { t: '主要风险', k: 'risk', w: 340 },
], P.map(p => ({
  _cls: p.rank <= 3 ? 'top3' : '', rank: badge('#' + p.rank, 'rank'), name: a(p.url, p.nickname, 'lnk'),
  total: `<b class="score">${f1(p.total)}</b>`, grade: badge(p.grade, gcls(p.grade)),
  A: `${f1(p.A)}<span class="sub">/${(W.A_wal + W.A_avg7)}</span>`, B: `${f1(p.B)}<span class="sub">/${(W.B_scope + W.B_style)}</span>`,
  C: `${f1(p.C)}<span class="sub">/${(W.C_hot15 + W.C_hot30 + W.C_max)}</span>`, D: `${f1(p.D)}<span class="sub">/${W.D}</span>`,
  reason: p.reason, risk: p.risk,
})));

const card = p => `<div class="card">
  <div class="card-h"><span class="rk">#${p.rank}</span>${a(p.url, p.nickname, 'lnk big')}<span class="tt">${f1(p.total)} <small>/100</small></span>${badge(p.grade, gcls(p.grade))}</div>
  <div class="bars">${[['A 近期流量', p.A, W.A_wal + W.A_avg7, '#2563eb'], ['B 内容垂直', p.B, W.B_scope + W.B_style, '#0891b2'], ['C 爆文能力', p.C, W.C_hot15 + W.C_hot30 + W.C_max, '#ea580c'], ['D 互动健康', p.D, W.D, '#7c3aed']].map(([t, v, m, c]) => `<div class="bar"><span class="bl">${t}</span><span class="bt"><i style="width:${(v / m * 100).toFixed(1)}%;background:${c}"></i></span><span class="bv">${f1(v)}/${m}</span></div>`).join('')}</div>
  <div class="kv"><b>硬数据</b>：近7天 ${p.n7} 篇 / ${p.likes7} 赞（篇均 ${f1(p.avg7)}）｜近15天 ${p.n15} 篇 / ${p.likes15} 赞｜近${WIN.long}天 ${p.n30} 篇 / ${p.likes30} 赞｜时间加权赞 ${f1(p.wal)}｜最高单篇 ${p.maxLike} 赞｜品类 ${p.nScope}/${p.n30} 篇（${pct(p.scopeRaw)}，剔活动稿 ${pct(p.scopeAdj)}）｜藏/赞 ${f2(p.rc)}、评/赞 ${f2(p.rp)}｜主页垂直度 ${p.styleScore} 分</div>
  <div class="why"><b>为什么</b>：${esc(p.reason)}</div><div class="risk"><b>硬伤</b>：${esc(p.risk)}</div></div>`;

const weightHtml = `<div class="tw"><table><thead><tr><th>维度</th><th>权重</th><th>构成</th><th>算法细则</th></tr></thead><tbody>${[
  ['A 近期流量势能', W.A_wal + W.A_avg7, `时间加权点赞 WAL ${W.A_wal} 分 + 近${WIN.near}天篇均赞 ${W.A_avg7} 分`, `阶梯衰减：近${WIN.near}天×${DEC.near} / ${WIN.near + 1}–${WIN.mid}天×${DEC.mid} / ${WIN.mid + 1}–${WIN.long}天×${DEC.long}；对数 min-max 归一`],
  ['B 内容垂直度', W.B_scope + W.B_style, `${WIN.long}天目标品类占比 ${W.B_scope} 分 + 主页风格 ${W.B_style} 分`, `占比按 min(1, ${WIN.long}天篇数/${CFG.smallSampleBase}) 做小样本折扣；风格分可人工评分，缺失时按标题美食词占比粗估并标注`],
  ['C 爆文能力', W.C_hot15 + W.C_hot30 + W.C_max, `近${WIN.mid}天相对爆文率 ${W.C_hot15} 分 + 近${WIN.long}天 ${W.C_hot30} 分 + 最高单篇赞 ${W.C_max} 分`, `相对爆文=≥${CFG.hotThreshold} 赞；${CFG.hundredThreshold} 赞另作明细绝对爆文标签`],
  ['D 互动健康度', W.D, `赞:藏:评逼近 1:1:1 的程度 × 样本可信度`, `接近度=1-(|1-藏/赞|+|1-评/赞|)/2；详情不足 ${CFG.reliabilityBase} 篇按 已采篇数/${CFG.reliabilityBase} 折算`],
].map(w => `<tr><td><b>${esc(w[0])}</b></td><td><b>${w[1]} 分</b></td><td>${esc(w[2])}</td><td>${esc(w[3])}</td></tr>`).join('')}</tbody></table></div>`;

const flowHtml = `<div class="tw"><table><thead><tr><th>博主</th><th>近${WIN.long}天点赞合计</th><th>时间加权赞 WAL</th><th>无衰减排名</th><th>加权后排名</th><th>变化</th></tr></thead><tbody>${flowCompare.map(f => `<tr><td>${esc(f.nickname)}</td><td class="num">${f.likes30}</td><td class="num">${f.wal}</td><td class="num">${f.rankNo}</td><td class="num">${f.rankWAL}</td><td>${f.delta > 0 ? `<span class="up">↑ ${f.delta}</span>` : f.delta < 0 ? `<span class="down">↓ ${-f.delta}</span>` : '—'}</td></tr>`).join('')}</tbody></table></div>`;
const vertHtml = `<div class="tw"><table><thead><tr><th>垂直榜</th><th>博主（点开主页）</th><th>B 垂直分</th><th>${WIN.long}天品类占比</th><th>剔除活动稿后</th><th>主页风格分</th></tr></thead><tbody>${verticalRank.slice(0, 8).map(v => `<tr${v.rank <= 3 ? ' class="top3"' : ''}><td>#${v.rank}</td><td>${a(v.url, v.nickname, 'lnk')}</td><td class="num">${f1(v.B)}</td><td class="num">${pct(v.scopeRaw)}</td><td class="num">${pct(v.scopeAdj)}</td><td class="num">${v.styleScore}</td></tr>`).join('')}</tbody></table></div>`;

const findings = [
  ['先看清全池的「爆文」基准线', `近${WIN.long}天 ${S.n30} 篇笔记里，≥${CFG.hundredThreshold} 赞只有 <b>${S.n100} 篇（${S.n30 ? (S.n100 / S.n30 * 100).toFixed(1) : 0}%）</b>，中位数 ${S.p50} 赞、p90 仅 ${S.p90} 赞。若直接用 ${CFG.hundredThreshold} 赞算爆文率，绝大多数博主会得 0 分、无法排序。所以评分改用 <b>≥${CFG.hotThreshold} 赞作「相对爆文」</b>，${CFG.hundredThreshold} 赞保留为明细表的绝对标签。阈值应随每批数据的分位数复核，不是固定值。`],
  ['品类笔记里的「集中活动稿」要单列', `${WIN.long}天目标品类 ${S.nScope} 篇中，<b>${S.nMarket} 篇（${mktShare}%）</b>命中活动稿特征（${esc(CFG.marketPattern)}），合计只有 ${S.marketLikes} 赞、篇均 ${mktAvg} 赞。看占比时务必同时看「剔除活动稿后」列${vertRisky.length ? `：${vertRisky.map(v => esc(v.nickname) + ' ' + pct(v.scopeRaw) + ' → ' + pct(v.scopeAdj)).join('、')}` : ''}。`],
  ['铺量不等于流量，篇均是分水岭', `${esc(mostNotes.nickname)} 近${WIN.long}天 <b>${mostNotes.n30} 篇 / ${mostNotes.likes30} 赞（篇均 ${f1(mostNotes.avg30)}）</b>；${esc(bestAvg.nickname)} <b>${bestAvg.n30} 篇 / ${bestAvg.likes30} 赞（篇均 ${f1(bestAvg.avg30)}）</b>。所以 A 项同时放「时间加权点赞合计」和「近${WIN.near}天篇均赞」，避免靠发文数刷分。`],
  ['粉丝量有用，但不是决定项', `log(粉丝) 与 log(近${WIN.long}天点赞) 的相关系数约 <b>${S.corrFansLikes}</b>（${S.nProfile} 人中）。相关不等于因果，低粉高互动的号仍可能排在高粉号前面。`],
  ['越近越重要：主要改写中段排名', `阶梯权重（近${WIN.near}天×${DEC.near} / ${WIN.near + 1}–${WIN.mid}天×${DEC.mid} / ${WIN.mid + 1}–${WIN.long}天×${DEC.long}）对头部影响有限，主要改写中段：${upMoves.map(f => esc(f.nickname) + ' 流量排名 ' + f.rankNo + '→' + f.rankWAL).concat(downMoves.map(f => esc(f.nickname) + ' ' + f.rankNo + '→' + f.rankWAL)).join('；') || '本批无明显位次变化'}。近期停更会被降权，近期集中产出的会被抬升。`],
  ['没有人的互动结构真正接近 1:1:1', `真实平台上收藏、评论普遍远小于点赞：全池 1:1:1 接近度最高仅 <b>${f1(S.closeMax)}/100</b>，D 项实得最高 ${f1(dMax)}/${W.D}。收藏/评论只有详情页有，本轮覆盖 <b>${S.nDetail}/${S.n30} 篇（${S.n30 ? (S.nDetail / S.n30 * 100).toFixed(1) : 0}%）</b>，各博主 ${f1(coverMin)}%–${f1(coverMax)}%，已按「已采篇数/${CFG.reliabilityBase}」折算样本可信度，没把小样本偶然比例当实力。`],
];

const limits = [
  `数据快照：北京时间 ${S.dateBj}，窗口为自然日含今天 —— 近${WIN.near}天 ${S.n7} 篇、近${WIN.mid}天 ${S.n15} 篇、近${WIN.long}天 ${S.n30} 篇，全量主页笔记 ${S.nAll} 篇。`,
  '短链解析后需先确认是博主主页（user/profile）还是笔记详情（explore）：本流程按「主页列表 → 笔记详情」两阶段采集。若用户以为给的是笔记链接而实际是主页（或相反），必须先告知再继续。',
  '点赞优先取详情页 interactInfo.likedCount，未采详情的用主页列表 liked_count 兜底；平台对 0 赞 / 0 藏 / 0 分享返回空字符串，已按 0 处理（需抽样验证），未当成缺失。「1.2万」这类缩写要换算成数字。',
  '目标品类按笔记标题关键词判定，命中词逐条列在品类明细；仅靠 emoji 或泛词命中的标「弱·建议复核」，不擅自剔除。活动稿正则可在 config.json 的 marketPattern 改。',
  '主页风格垂直度若未在 manual.json 提供人工评分，则为标题关键词粗估并明确标注「机器估计·建议人工复核」，不得当作已人工看页的结论。',
  '标注粉丝数与实测可能有差异（时点差、平台只显示「1万」、「758赞收」这类是获赞收藏数不是粉丝数）。差异全部保留，不抹平、不改写。',
  '本表为达人筛选的数据论据，不构成投放效果承诺；集中活动稿、单条爆文、小样本互动比均已在风险列标注。',
  '合规：采集第三方平台数据前确认符合平台协议与当地法规；本技能只提供技术实现，不构成合规保证。',
];

// ---------- 总览 / 明细表 ----------
const ovRows = P.map(p => ({
  rank: p.rank, name: a(p.url, p.nickname, 'lnk'), go: a(p.url, '打开主页 ↗', 'lnk small'),
  total: `<b class="score">${f1(p.total)}</b>`, grade: badge(p.grade, gcls(p.grade)),
  fans: p.fans, redId: p.redId, ip: p.ip, noteTotal: p.noteTotal,
  n7: p.n7, likes7: p.likes7, avg7: f1(p.avg7), n15: p.n15, likes15: p.likes15,
  n30: p.n30, likes30: p.likes30, avg30: f1(p.avg30), wal: f1(p.wal), maxLike: p.maxLike,
  hotRate15: pct(p.hotRate15), hotRate30: pct(p.hotRate30),
  nScope: p.nScope, scopeRaw: pct(p.scopeRaw), scopeAdj: pct(p.scopeAdj), nMarket: p.nMarket,
  rc: f2(p.rc), rp: f2(p.rp), cover: pct(p.coverRate), nDetail: p.nDetail,
  style: p.styleScore, styleTag: `<span title="${esc(p.styleWhy)}">${esc(p.styleTag)}</span>`, styleWhy: p.styleWhy,
}));
const ovTable = table([
  { t: '排名', k: 'rank' }, { t: '博主昵称', k: 'name', raw: 1 }, { t: '主页链接', k: 'go', raw: 1 },
  { t: '总分', k: 'total', raw: 1 }, { t: '等级', k: 'grade', raw: 1 },
  { t: '实测粉丝', k: 'fans' }, { t: '小红书号', k: 'redId' }, { t: 'IP', k: 'ip' }, { t: '主页笔记总数', k: 'noteTotal' },
  { t: `${WIN.near}天篇`, k: 'n7' }, { t: `${WIN.near}天赞`, k: 'likes7' }, { t: `${WIN.near}天篇均`, k: 'avg7' },
  { t: `${WIN.mid}天篇`, k: 'n15' }, { t: `${WIN.mid}天赞`, k: 'likes15' },
  { t: `${WIN.long}天篇`, k: 'n30' }, { t: `${WIN.long}天赞`, k: 'likes30' }, { t: `${WIN.long}天篇均`, k: 'avg30' },
  { t: '时间加权赞', k: 'wal' }, { t: '最高单篇赞', k: 'maxLike' },
  { t: `近${WIN.mid}天爆文率`, k: 'hotRate15' }, { t: `近${WIN.long}天爆文率`, k: 'hotRate30' },
  { t: '品类篇数', k: 'nScope' }, { t: '品类占比', k: 'scopeRaw' }, { t: '剔活动后占比', k: 'scopeAdj' }, { t: '活动稿数', k: 'nMarket' },
  { t: '藏/赞', k: 'rc' }, { t: '评/赞', k: 'rp' }, { t: '详情覆盖率', k: 'cover' }, { t: '已采详情篇', k: 'nDetail' },
  { t: '主页垂直分', k: 'style' }, { t: '风格判词（悬停看依据）', k: 'styleTag', raw: 1, w: 190 }, { t: '风格依据', k: 'styleWhy', w: 380 },
], ovRows, 'ovTable');

const likeRows = detailRows.map(r => ({
  idx: r.idx, author: esc(r.author), date: r.date, daysAgo: r.daysAgo,
  window: badge(r.window, r.window === `近${WIN.near}天` ? 'w7' : r.window === `${WIN.near + 1}-${WIN.mid}天` ? 'w15' : 'w30'),
  title: a(r.url, r.title || '(无标题)', 'lnk'), like: r.like,
  tag: r.tag100 ? badge(r.tag100, r.tag100 === '大爆款' ? 'tBig' : r.tag100 === '百赞' ? 't100' : 'tHot') : '',
  weight: '×' + r.weight.toFixed(1), wal: f1(r.wal),
  collect: r.collect, comment: r.comment, share: r.share,
  category: r.category === '其他' ? '—' : r.category,
  market: r.market ? badge('活动稿', 'tm') : '', detail: r.hasDetail ? '已采' : '仅列表',
}));
const likeTable = table([
  { t: '#', k: 'idx' }, { t: '博主', k: 'author', raw: 1 }, { t: '发布日期', k: 'date' }, { t: '距今天数', k: 'daysAgo' },
  { t: '时间窗口', k: 'window', raw: 1 }, { t: '笔记标题（点开原文）', k: 'title', raw: 1, w: 330 },
  { t: '点赞', k: 'like' }, { t: '爆文标签', k: 'tag', raw: 1 },
  { t: '时间权重', k: 'weight' }, { t: '加权赞', k: 'wal' },
  { t: '收藏', k: 'collect' }, { t: '评论', k: 'comment' }, { t: '分享', k: 'share' },
  { t: '品类', k: 'category' }, { t: '活动', k: 'market', raw: 1 }, { t: '数据来源', k: 'detail' },
], likeRows, 'likeTable');

const scRows = scopeRows.map(r => ({
  idx: r.idx, author: esc(r.author), date: r.date, title: a(r.url, r.title || '(无标题)', 'lnk'),
  category: badge(r.category, r.category === '茶饮+烘焙' ? 'cBoth' : r.category === '茶饮' ? 'cTea' : 'cBake'),
  hits: (r.hits || []).join('、') || '—',
  strength: r.weak ? badge('弱·建议复核', 'tweak') : '正常',
  market: r.market ? badge('活动稿', 'tm') : '—', like: r.like,
  tag: r.tag100 ? badge(r.tag100, r.tag100 === '大爆款' ? 'tBig' : r.tag100 === '百赞' ? 't100' : 'tHot') : '',
  collect: r.collect, comment: r.comment, share: r.share, detail: r.hasDetail ? '已采详情' : '仅列表',
}));
const scTable = table([
  { t: '#', k: 'idx' }, { t: '博主', k: 'author', raw: 1 }, { t: '发布日期', k: 'date' },
  { t: '笔记标题（点开原文）', k: 'title', raw: 1, w: 360 },
  { t: '细分类', k: 'category', raw: 1 }, { t: '命中关键词', k: 'hits', w: 180 },
  { t: '命中强度', k: 'strength', raw: 1 }, { t: '活动标记', k: 'market', raw: 1 },
  { t: '点赞', k: 'like' }, { t: '爆文标签', k: 'tag', raw: 1 },
  { t: '收藏', k: 'collect' }, { t: '评论', k: 'comment' }, { t: '分享', k: 'share' }, { t: '数据来源', k: 'detail' },
], scRows, 'scTable');

// ---------- HTML ----------
const css = `:root{--bg:#f7f8fa;--card:#fff;--line:#e5e7eb;--text:#1f2329;--muted:#6b7280;--accent:#2563eb;--head:#f1f5f9}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:14px/1.65 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
header{padding:20px 28px 12px;background:var(--card);border-bottom:1px solid var(--line)}
h1{margin:0 0 6px;font-size:21px;font-weight:680}h1 small{font-weight:400;color:var(--muted);font-size:13px;margin-left:10px}
.meta{color:var(--muted);font-size:12.5px}
.tabs{display:flex;flex-wrap:wrap;gap:6px;padding:14px 28px 0;background:var(--card);border-bottom:1px solid var(--line)}
.tab{border:1px solid var(--line);border-bottom:none;background:#fafafa;color:var(--muted);padding:9px 16px;border-radius:7px 7px 0 0;cursor:pointer;font-size:13.5px;white-space:nowrap;font-family:inherit}
.tab:hover{color:var(--text);background:var(--head)}.tab.active{background:var(--accent);color:#fff;border-color:var(--accent);font-weight:600}
main{padding:20px 28px 60px;max-width:1900px}.pane{display:none}.pane.active{display:block}
h2{font-size:16.5px;margin:24px 0 6px;font-weight:680}h2:first-child{margin-top:4px}
h3{font-size:14px;margin:0 0 8px;font-weight:650}.note{color:var(--muted);font-size:12.5px;margin:0 0 12px}
.tw{overflow:auto;max-height:76vh;border:1px solid var(--line);border-radius:8px;background:var(--card)}
table{border-collapse:separate;border-spacing:0;width:100%;font-size:12.5px;white-space:nowrap}
th{position:sticky;top:0;background:var(--head);color:#374151;font-weight:650;text-align:left;padding:9px 11px;border-bottom:1px solid var(--line);z-index:1}
td{padding:8px 11px;border-bottom:1px solid #f0f1f3;color:var(--text)}tbody tr:nth-child(even) td{background:#fafbfc}tbody tr:hover td{background:#eef4ff}
tbody tr.top3 td{background:#fffaf2}tbody tr.top3:hover td{background:#fff3e0}
td.num{text-align:right;font-variant-numeric:tabular-nums}td.na{color:#b0b5bd}
#concl td:nth-child(9),#concl td:nth-child(10),#ov td:last-child{white-space:normal;min-width:300px;line-height:1.5}
a.lnk{color:var(--accent);text-decoration:none}a.lnk:hover{text-decoration:underline}a.lnk.big{font-size:15px;font-weight:650}a.lnk.small{font-size:12px}
.score{font-size:14px;color:#c2410c}.sub{color:#9ca3af;font-size:11px;margin-left:2px}
.bd{display:inline-block;padding:1px 7px;border-radius:5px;font-size:11px;font-weight:600;line-height:1.7;white-space:nowrap}
.bd.rank{background:#eef2ff;color:#4338ca}.gS{background:#fee2e2;color:#b91c1c}.gA{background:#dbeafe;color:#1d4ed8}.gB{background:#f3f4f6;color:#4b5563}.gC{background:#f3f4f6;color:#9ca3af}
.w7{background:#dcfce7;color:#15803d}.w15{background:#fef9c3;color:#a16207}.w30{background:#f3f4f6;color:#6b7280}
.t100{background:#fee2e2;color:#b91c1c}.tBig{background:#b91c1c;color:#fff}.tHot{background:#ffedd5;color:#c2410c}
.tm{background:#f3e8ff;color:#7e22ce}.tweak{background:#fef3c7;color:#92400e}
.cTea{background:#d1fae5;color:#047857}.cBake{background:#ffedd5;color:#c2410c}.cBoth{background:#e0e7ff;color:#4338ca}
.hero{background:linear-gradient(135deg,#eff6ff,#fff);border:1px solid #bfdbfe;border-radius:10px;padding:18px 20px;margin-bottom:20px}
.hero .lead{font-size:15.5px;font-weight:650;line-height:1.7;margin:0 0 10px}.hero .lead em{font-style:normal;color:#c2410c;border-bottom:2px solid #fed7aa}
.hero p{margin:6px 0;font-size:13.5px;color:#374151}.hero .pick{display:inline-block;background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:3px 9px;margin:3px 5px 3px 0;font-size:12.5px}.hero .pick b{color:#b91c1c}
.two{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin:12px 0 4px}
.box{background:var(--card);border:1px solid var(--line);border-radius:9px;padding:14px 16px}.box ul{margin:0;padding-left:18px;font-size:13px;line-height:1.9}.box .hl{color:#b91c1c;font-weight:600}
.card{background:var(--card);border:1px solid var(--line);border-radius:9px;padding:14px 16px;margin:10px 0}
.card-h{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:10px}.card-h .rk{background:#1f2937;color:#fff;border-radius:5px;padding:2px 8px;font-size:12px;font-weight:700}
.card-h .tt{margin-left:auto;font-size:19px;font-weight:700;color:#c2410c}.card-h .tt small{font-size:12px;color:var(--muted);font-weight:400}
.bars{display:grid;grid-template-columns:repeat(2,1fr);gap:5px 20px;margin-bottom:10px}.bar{display:flex;align-items:center;gap:8px;font-size:12px}.bar .bl{width:78px;color:var(--muted);flex:none}
.bt{flex:1;height:7px;background:#f1f5f9;border-radius:4px;overflow:hidden}.bt i{display:block;height:100%;border-radius:4px}.bar .bv{width:52px;text-align:right;font-variant-numeric:tabular-nums;color:#374151;flex:none}
.kv,.why,.risk{font-size:12.8px;line-height:1.75;margin:4px 0}.kv b,.why b,.risk b{color:#111827}.risk{color:#9a3412}.why{color:#374151}
ol.find{margin:0;padding-left:20px}ol.find li{margin:9px 0;font-size:13.2px;line-height:1.8}ol.find b{color:#c2410c}
ul.lim{margin:0;padding-left:20px;font-size:12.8px;color:#4b5563;line-height:1.9}
.filters{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 10px;font-size:12.5px}
.filters input[type=text]{padding:6px 10px;border:1px solid var(--line);border-radius:6px;font-size:12.5px;width:230px;font-family:inherit}
.filters label{color:#374151;cursor:pointer;user-select:none}.filters .cnt{color:var(--muted)}
.up{color:#15803d;font-weight:600}.down{color:#b91c1c;font-weight:600}.foot{color:var(--muted);font-size:12px;margin-top:26px;border-top:1px solid var(--line);padding-top:12px}
@media(max-width:900px){.two,.bars{grid-template-columns:1fr}main,header,.tabs{padding-left:14px;padding-right:14px}}`;

const html = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>小红书投放筛号 · 综合结论 · ${S.dateBj}</title><style>${css}</style></head><body>
<header><h1>小红书投放筛号 · 综合结论 <small>数据截至 ${S.dateBj}（北京时间）</small></h1>
<div class="meta">${S.nProfile} 位博主 · 全量 ${S.nAll} 篇笔记 · 近${WIN.long}天 ${S.n30} 篇 / 近${WIN.mid}天 ${S.n15} 篇 / 近${WIN.near}天 ${S.n7} 篇 · 目标品类 ${S.nScope} 篇 · 已采详情 ${S.nDetail} 篇 · 4 个分页</div></header>
<nav class="tabs"><button class="tab active" data-t="concl">🏆 整合结论</button><button class="tab" data-t="ov">📊 总览（带博主链接）</button><button class="tab" data-t="like">👍 点赞明细（带笔记链接·百赞标签）</button><button class="tab" data-t="scope">🍞 品类明细（带笔记链接）</button></nav>
<main>
<section class="pane active" id="concl">
  <div class="hero"><p class="lead">按本次评分规则加权后，<em>${heroLead}</em>。${heroCaveat}</p>
  <p><b>如果这一轮是给目标品类做投放</b>，请同时看「分用途选人」和垂直度分榜 —— 综合分高不等于品类契合。</p>
  <p><span class="pick">Top3 <b>${esc(t1.nickname)} ${f1(t1.total)}</b> · <b>${esc(t2.nickname)} ${f1(t2.total)}</b> · <b>${esc(t3.nickname)} ${f1(t3.total)}</b></span><span class="pick">S 优先 ${P.filter(p => p.grade[0] === 'S').length} 位 · A 次选 ${P.filter(p => p.grade[0] === 'A').length} 位 · C 不建议 ${P.filter(p => p.grade[0] === 'C').length} 位</span></p></div>
  <h2>① 综合排名（${S.nProfile} 位，点博主名可打开主页）</h2>
  <p class="note">总分 = A 近期流量 ${W.A_wal + W.A_avg7} + B 内容垂直 ${W.B_scope + W.B_style} + C 爆文能力 ${W.C_hot15 + W.C_hot30 + W.C_max} + D 互动健康 ${W.D}；算法见下方权重表，全部可复核。</p>
  ${rankTable}
  <h2>② 分用途选人：同一个榜单，两种结论</h2>
  <div class="two"><div class="box"><h3>🎯 要曝光 / 要流量（按 A 项）</h3><ul>${topFlow.map(p => `<li><span class="hl">${esc(p.nickname)}</span>：近${WIN.long}天 ${p.n30} 篇 ${p.likes30} 赞（篇均 ${f1(p.avg30)}），近${WIN.near}天 ${p.n7} 篇 ${p.likes7} 赞；A 项 ${f1(p.A)} 分。${p.B < medianB ? '<b>但垂直度低于全池中位数</b>。' : ''}</li>`).join('')}</ul></div>
  <div class="box"><h3>🍞 要品类种草（按 B 项，已剔除活动稿水分）</h3><ul>${vertClean.map(v => `<li><span class="hl">${esc(v.nickname)}</span>：品类占比 ${pct(v.scopeRaw)}（剔活动稿后 ${pct(v.scopeAdj)}），主页风格 ${v.styleScore} 分，B 项 ${f1(v.B)} 分。</li>`).join('')}${vertRisky.length ? `<li>⚠️ ${vertRisky.map(v => esc(v.nickname) + ' 品类占比 ' + pct(v.scopeRaw) + ' 但全部是活动稿，剔除后为 0').join('；')}，不能按常态品类产能采信。</li>` : ''}</ul></div></div>
  <h2>③ Top 3 深度论据</h2>${P.slice(0, 3).map(card).join('')}
  <h2>④ 垂直度分榜（B 项）</h2><p class="note">「剔除活动稿后」是稳健性校验列：把命中活动稿特征的集中投放稿扣掉后的常态品类占比。</p>${vertHtml}
  <h2>⑤ 六个关键数据发现（也是权重这么定的原因）</h2><ol class="find">${findings.map(f => `<li><b>${f[0]}</b> —— ${f[1]}</li>`).join('')}</ol>
  <h2>⑥ 时间衰减对照</h2><p class="note">同一批「近${WIN.long}天点赞」数据，只比较纯流量维度：不加衰减 vs 阶梯加权。</p>${flowHtml}
  <h2>⑦ 评分权重与算法（可复核）</h2>${weightHtml}<p class="note" style="margin-top:8px">归一化统一用 <b>log1p 对数 min-max</b>：极端爆文会把线性归一的其余人压成 0。等级：S ≥${CFG.grades.S} / A ${CFG.grades.A}–${CFG.grades.S} / B ${CFG.grades.B}–${CFG.grades.A} / C &lt;${CFG.grades.B}。</p>
  <h2>⑧ 口径与限制</h2><ul class="lim">${limits.map(x => `<li>${x}</li>`).join('')}</ul>
</section>
<section class="pane" id="ov"><h2>📊 总览 · ${S.nProfile} 位博主全部原始指标</h2><p class="note">「博主昵称」和「主页链接」均可点击打开小红书主页；风格判词列悬停可看依据。表头固定、可横向滚动。</p>${ovTable}</section>
<section class="pane" id="like"><h2>👍 点赞明细 · 近${WIN.long}天 ${detailRows.length} 篇</h2>
<p class="note">标题可点击打开笔记原文。<b>百赞标签</b>：≥${CFG.hundredThreshold} 赞标「百赞」、≥${CFG.bigThreshold} 赞标「大爆款」、${CFG.hotThreshold}–${CFG.hundredThreshold - 1} 赞标「准爆」。全池近${WIN.long}天仅 ${S.n100} 篇破百赞。收藏/评论/分享只有已采详情的 ${S.nDetail} 篇有，其余显示「—」，未编造。</p>
<div class="filters"><input type="text" id="qLike" placeholder="搜博主 / 标题关键词"><label><input type="checkbox" id="f100"> 只看 ≥${CFG.hundredThreshold} 赞</label><label><input type="checkbox" id="f7"> 只看近${WIN.near}天</label><label><input type="checkbox" id="fDetail"> 只看已采详情</label><span class="cnt" id="cLike"></span></div>${likeTable}</section>
<section class="pane" id="scope"><h2>🍞 品类明细 · ${WIN.long}天内目标品类 ${scopeRows.length} 篇</h2>
<p class="note">标题可点击打开笔记原文。其中活动稿 ${scopeRows.filter(x => x.market).length} 篇已单独标记，仅靠 emoji/泛词命中的标「弱·建议复核」，未擅自剔除。</p>
<div class="filters"><input type="text" id="qScope" placeholder="搜博主 / 标题 / 关键词"><label><input type="checkbox" id="fMarket"> 只看活动稿</label><label><input type="checkbox" id="fWeak"> 只看弱命中</label><span class="cnt" id="cScope"></span></div>${scTable}</section>
<div class="foot">数据来源：小红书网页版博主主页笔记列表 + 笔记详情页（${S.dateBj} 采集）｜本页为筛选数据论据，不构成投放效果承诺。</div>
</main>
<script>
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.pane').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById(b.dataset.t).classList.add('active');});
function filter(tid,qid,opts,cid){const t=document.getElementById(tid);if(!t)return;const rows=[...t.tBodies[0].rows];const apply=()=>{const q=(document.getElementById(qid).value||'').trim().toLowerCase();let c=0;rows.forEach(r=>{const txt=r.textContent.toLowerCase();let ok=!q||txt.includes(q);opts.forEach(o=>{if(document.getElementById(o.id).checked&&!(o.test?o.test(r):r.textContent.includes(o.match)))ok=false;});r.style.display=ok?'':'none';if(ok)c++;});document.getElementById(cid).textContent='显示 '+c+' / '+rows.length+' 行';};document.getElementById(qid).addEventListener('input',apply);opts.forEach(o=>document.getElementById(o.id).addEventListener('change',apply));apply();}
filter('likeTable','qLike',[{id:'f100',test:r=>!!r.querySelector('.t100,.tBig')},{id:'f7',test:r=>!!r.querySelector('.w7')},{id:'fDetail',test:r=>r.cells[15]&&r.cells[15].textContent.trim()==='已采'}],'cLike');
filter('scTable','qScope',[{id:'fMarket',test:r=>!!r.querySelector('.tm')},{id:'fWeak',test:r=>!!r.querySelector('.tweak')}],'cScope');
</script></body></html>`;
fs.writeFileSync('小红书投放筛号_综合结论.html', html, 'utf8');

// ---------- CSV ----------
const cell = v => { const s = String(v ?? ''); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
const csv = (file, cols, rows) => fs.writeFileSync(file, '\uFEFF' + [cols.map(c => cell(c[0])).join(','), ...rows.map(r => cols.map(c => cell(r[c[1]])).join(','))].join('\r\n'), 'utf8');
fs.mkdirSync('final_csv', { recursive: true });
csv('final_csv/1_综合总览.csv', [
  ['排名', 'rank'], ['等级', 'grade'], ['博主昵称', 'nickname'], ['主页链接', 'url'], ['总分', 'total'],
  ['A流量', 'A'], ['B垂直', 'B'], ['C爆文', 'C'], ['D互动', 'D'], ['实测粉丝', 'fans'], ['小红书号', 'redId'], ['IP属地', 'ip'], ['主页笔记总数', 'noteTotal'],
  [`近${WIN.near}天篇`, 'n7'], [`近${WIN.near}天赞`, 'likes7'], [`近${WIN.near}天篇均赞`, 'avg7'], [`近${WIN.mid}天篇`, 'n15'], [`近${WIN.mid}天赞`, 'likes15'],
  [`近${WIN.long}天篇`, 'n30'], [`近${WIN.long}天赞`, 'likes30'], [`近${WIN.long}天篇均赞`, 'avg30'], ['时间加权赞WAL', 'wal'], ['最高单篇赞', 'maxLike'],
  ['近15天相对爆文率%', 'hotRate15'], ['近30天相对爆文率%', 'hotRate30'], ['品类篇数', 'nScope'], ['品类占比%', 'scopeRaw'], ['剔除活动稿后占比%', 'scopeAdj'], ['活动稿数', 'nMarket'],
  ['藏/赞', 'rc'], ['评/赞', 'rp'], ['1:1:1接近度', 'closeRaw'], ['详情覆盖率%', 'coverRate'], ['已采详情篇数', 'nDetail'],
  ['主页垂直分', 'styleScore'], ['风格判词', 'styleTag'], ['风格依据', 'styleWhy'], ['数据论据', 'reason'], ['主要风险', 'risk'],
], P);
csv('final_csv/2_点赞明细.csv', [
  ['序号', 'idx'], ['博主', 'author'], ['发布日期', 'date'], ['距今天数', 'daysAgo'], ['时间窗口', 'window'], ['笔记标题', 'title'], ['笔记链接', 'url'],
  ['点赞', 'like'], ['爆文标签', 'tag100'], ['时间权重', 'weight'], ['加权赞', 'wal'], ['收藏', 'collect'], ['评论', 'comment'], ['分享', 'share'],
  ['品类', 'category'], ['活动稿', 'market'], ['已采详情', 'hasDetail'],
], detailRows.map((r, i) => ({ ...r, idx: i + 1, weight: '×' + r.weight.toFixed(1), market: r.market ? '是' : '', hasDetail: r.hasDetail ? '是' : '否' })));
csv('final_csv/3_品类明细.csv', [
  ['序号', 'idx'], ['博主', 'author'], ['发布日期', 'date'], ['笔记标题', 'title'], ['笔记链接', 'url'], ['细分类', 'category'], ['命中关键词', 'hits'],
  ['弱命中建议复核', 'weak'], ['活动稿', 'market'], ['点赞', 'like'], ['爆文标签', 'tag100'], ['收藏', 'collect'], ['评论', 'comment'], ['分享', 'share'], ['已采详情', 'hasDetail'],
], scopeRows.map((r, i) => ({ ...r, idx: i + 1, hits: (r.hits || []).join('、'), weak: r.weak ? '是' : '', market: r.market ? '是' : '', hasDetail: r.hasDetail ? '是' : '否' })));
console.log(`完成：小红书投放筛号_综合结论.html（${html.length} 字符）+ final_csv/ 3 个 CSV`);
console.log(`博主 ${P.length} / 点赞明细 ${detailRows.length} / 品类明细 ${scopeRows.length} / 链接 ${(html.match(/href="https:\/\/www\.xiaohongshu\.com/g) || []).length}`);
