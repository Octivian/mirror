// 第 0 步：把用户给的小红书短链批量解析成「主页 or 笔记」清单，输出 links.json
// 用法：node 00_resolve_links.mjs [links_raw.txt]   （默认读当前目录 links_raw.txt）
// 输入每行：<短链或长链> [空格/制表符 备注文字，可含粉丝数]
// 输出：links.json  [{idx,label,userId,token,url,type}]，type=profile 才能进第 1 步
import fs from 'node:fs';

const file = process.argv[2] || 'links_raw.txt';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function resolveOnce(url) {
  const res = await fetch(url, { redirect: 'manual', headers: { 'User-Agent': UA } });
  const loc = res.headers.get('location');
  return { status: res.status, loc };
}

async function finalUrl(url) {
  let cur = url;
  for (let i = 0; i < 5; i++) {
    const { status, loc } = await resolveOnce(cur);
    if (!loc) return { url: cur, status };
    cur = new URL(loc, cur).toString();
    // 到达小红书主域即停止（后续是页面内部跳转）
    if (/xiaohongshu\.com\/(user\/profile|explore|discovery\/item)/.test(cur)) return { url: cur, status };
  }
  return { url: cur, status: 302 };
}

const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/)
  .map(s => s.trim()).filter(s => s && !s.startsWith('#'));
const out = [];
const notes = [];
for (let i = 0; i < lines.length; i++) {
  const parts = lines[i].split(/\s+/);
  const raw = parts.shift();
  const label = parts.join(' ') || `博主${i + 1}`;
  let url, status;
  try { ({ url, status } = await finalUrl(raw)); }
  catch (e) { console.log(`[${i + 1}] 解析失败 ${raw} -> ${e.message}`); continue; }
  const u = new URL(url);
  const pm = u.pathname.match(/\/user\/profile\/([0-9a-f]{24})/);
  const nm = u.pathname.match(/\/(?:explore|discovery\/item)\/([0-9a-f]{24})/);
  if (pm) {
    const token = u.searchParams.get('xsec_token') || '';
    const rec = {
      idx: out.length + 1, label, userId: pm[1], token,
      url: `https://www.xiaohongshu.com/user/profile/${pm[1]}?xsec_token=${token}&xsec_source=app_share`,
      type: 'profile',
    };
    out.push(rec);
    console.log(`[${i + 1}] 主页 OK  ${label} -> ${pm[1]}`);
  } else if (nm) {
    notes.push({ label, noteId: nm[1], url });
    console.log(`[${i + 1}] ⚠ 笔记链接（不是主页）：${label} -> ${nm[1]}；筛号流程需要主页，请补该博主主页链接`);
  } else {
    console.log(`[${i + 1}] ⚠ 未识别 ${label} -> ${url.slice(0, 120)}`);
  }
  await sleep(500);
}
fs.writeFileSync('links.json', JSON.stringify(out, null, 2), 'utf8');
if (notes.length) fs.writeFileSync('notes_only.json', JSON.stringify(notes, null, 2), 'utf8');
console.log(`\n完成：主页 ${out.length} 条 -> links.json；笔记链接 ${notes.length} 条已单列（不计入）`);
console.log('⚠ 若用户以为自己给的是「笔记链接」而实际是主页（或反过来），务必先告知用户再继续。');
