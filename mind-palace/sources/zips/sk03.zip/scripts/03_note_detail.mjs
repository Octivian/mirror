import fs from 'node:fs';
import path from 'node:path';

const HOST = process.env.CDP_HOST || '127.0.0.1', PORT = process.env.CDP_PORT || 9222;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = (...a) => console.log(`[${new Date().toISOString().slice(11, 19)}]`, ...a);
const MIN_GAP = Number(process.env.MIN_GAP_MS || 2200);
const MAX_GAP = Number(process.env.MAX_GAP_MS || 3800);
const OUT = path.resolve('details');
fs.mkdirSync(OUT, { recursive: true });

class CDP {
  constructor(url) {
    this.ws = new WebSocket(url); this.id = 0; this.pending = new Map(); this.listeners = new Map();
    this.ready = new Promise((res, rej) => {
      this.ws.addEventListener('open', () => res());
      this.ws.addEventListener('error', e => rej(new Error('ws: ' + e.message)));
    });
    this.ws.addEventListener('message', ev => {
      const m = JSON.parse(ev.data);
      if (m.id && this.pending.has(m.id)) {
        const p = this.pending.get(m.id); this.pending.delete(m.id);
        m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result);
      } else if (m.method) { const ls = this.listeners.get(m.method); if (ls) ls.forEach(f => f(m.params)); }
    });
  }
  send(method, params = {}) { return new Promise((resolve, reject) => { const id = ++this.id; this.pending.set(id, { resolve, reject }); this.ws.send(JSON.stringify({ id, method, params })); }); }
  on(m, f) { if (!this.listeners.has(m)) this.listeners.set(m, []); this.listeners.get(m).push(f); }
  off(m, f) { const a = this.listeners.get(m); if (a) { const i = a.indexOf(f); if (i >= 0) a.splice(i, 1); } }
  once(m) { return new Promise(res => { const f = p => { this.off(m, f); res(p); }; this.on(m, f); }); }
  close() { this.ws.close(); }
}

const EXPR = id => `(() => {
  const e = window.__INITIAL_STATE__?.note?.noteDetailMap?.['${id}'];
  const n = e?.note;
  if (!n) return JSON.stringify({ok:false, reason:'no noteDetailMap entry', href:location.href, title:document.title});
  const ii = n.interactInfo || {};
  // 平台对 0 值返回空字符串 ""（已抽样验证），字段缺失才记 null；「1.2万」等缩写换算成数字
  const toNum = v => { if (v === undefined || v === null) return null; if (v === '') return 0;
    const s = String(v).replace(/,/g,'').trim();
    if (/^\\d+$/.test(s)) return Number(s);
    const m = s.match(/^([\\d.]+)\\s*([万kK千])$/);
    if (m) return Math.round(Number(m[1]) * (m[2] === '万' ? 1e4 : 1e3));
    return null; };
  return JSON.stringify({
    ok:true,
    noteId: n.noteId ?? '${id}',
    title: n.title ?? null,
    desc: (n.desc ?? '').slice(0, 600),
    type: n.type ?? null,
    time: n.time ?? null,
    lastUpdateTime: n.lastUpdateTime ?? null,
    ipLocation: n.ipLocation ?? null,
    likedCount: toNum(ii.likedCount),
    collectedCount: toNum(ii.collectedCount),
    commentCount: toNum(ii.commentCount),
    shareCount: toNum(ii.shareCount),
    tagList: (n.tagList || []).map(t => typeof t === 'string' ? t : (t?.name ?? null)).filter(Boolean),
    userNickname: n.user?.nickname ?? null,
    userId: n.user?.userId ?? null,
  });
})()`;

const list = await (await fetch(`http://${HOST}:${PORT}/json/list`)).json();
const tab = list.find(t => t.type === 'page' && t.url.includes('xiaohongshu.com'));
if (!tab) throw new Error('没有小红书标签页');
const s = new CDP(tab.webSocketDebuggerUrl); await s.ready;
await s.send('Page.enable'); await s.send('Runtime.enable');

const targets = JSON.parse(fs.readFileSync('detail_targets.json', 'utf8'));
log(`待采详情笔记 ${targets.length} 篇`);
const outFile = path.join(OUT, 'details_all.json');
let results = [];
if (fs.existsSync(outFile)) results = JSON.parse(fs.readFileSync(outFile, 'utf8'));
const done = new Set(results.filter(r => r.ok && (r.collectedCount != null || r.collectNullConfirmed)).map(r => r.noteId));
let todo = targets.filter(t => !done.has(t.noteId));
const LIMIT = Number(process.env.LIMIT || 0);
if (LIMIT > 0) todo = todo.slice(0, LIMIT);
log(`已完成 ${done.size} 篇，本轮待采 ${todo.length} 篇${LIMIT ? '（LIMIT=' + LIMIT + '）' : ''}`);
const failed = [];

async function scrape(t) {
  const url = `https://www.xiaohongshu.com/explore/${t.noteId}?xsec_token=${t.xsecToken}&xsec_source=app_share`;
  await s.send('Page.navigate', { url });
  // __INITIAL_STATE__ 是 SSR 直出，不必等 load 事件；轮询到 noteDetailMap 出现即读
  await sleep(1200);
  let d = null;
  for (let k = 0; k < 4; k++) {
    const r = await s.send('Runtime.evaluate', { expression: EXPR(t.noteId), returnByValue: true, awaitPromise: true });
    if (!r.exceptionDetails) {
      d = JSON.parse(r.result.value);
      if (d.ok) break;
    }
    await sleep(800);
  }
  return d || { ok: false, reason: 'SSR 未就绪' };
}

for (let i = 0; i < todo.length; i++) {
  const t = todo[i];
  let d = null, err = '';
  for (let a = 0; a < 3 && !d?.ok; a++) {
    try { d = await scrape(t); if (!d.ok) err = d.reason; }
    catch (e) { err = e.message; }
    if (!d?.ok && a < 2) await sleep(1800 + a * 1800);
  }
  if (d?.ok) {
    const rec = { ...d, profileIdx: t.profileIdx, profileLabel: t.profileLabel, author: t.author, listLikedCount: t.listLikedCount, listTime: t.listTime, category: t.category };
    if (d.collectedCount == null) rec.collectNullConfirmed = true;
    const at = results.findIndex(x => x.noteId === d.noteId);
    if (at >= 0) results[at] = rec; else results.push(rec);
    if (i % 10 === 0 || i === todo.length - 1) {
      log(`[${i + 1}/${todo.length}] ${t.noteId} 赞${d.likedCount} 藏${d.collectedCount} 评${d.commentCount}`);
      fs.writeFileSync(outFile, JSON.stringify(results, null, 2), 'utf8');
    }
  } else {
    failed.push({ noteId: t.noteId, err }); log(`[${i + 1}/${todo.length}] 失败 ${t.noteId}: ${err}`);
  }
  if (i < todo.length - 1) await sleep(MIN_GAP + Math.random() * (MAX_GAP - MIN_GAP));
}
fs.writeFileSync(outFile, JSON.stringify(results, null, 2), 'utf8');
fs.writeFileSync(path.join(OUT, 'failed.json'), JSON.stringify(failed, null, 2), 'utf8');
log(`完成：成功 ${results.length} / 失败 ${failed.length}`);
s.close();
