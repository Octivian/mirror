import fs from 'node:fs';
import path from 'node:path';

const HOST = process.env.CDP_HOST || '127.0.0.1', PORT = process.env.CDP_PORT || 9222;
const OUT = path.resolve('profiles');
fs.mkdirSync(OUT, { recursive: true });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const log = (...a) => console.log(`[${new Date().toISOString().slice(11, 19)}]`, ...a);
const MIN_GAP = Number(process.env.MIN_GAP_MS || 2500);
const MAX_GAP = Number(process.env.MAX_GAP_MS || 4500);

class CDP {
  constructor(url) {
    this.ws = new WebSocket(url); this.id = 0; this.pending = new Map(); this.listeners = new Map();
    this.ready = new Promise((res, rej) => {
      this.ws.addEventListener('open', () => res());
      this.ws.addEventListener('error', e => rej(new Error('ws: ' + e.message)));
    });
    this.ws.addEventListener('message', ev => {
      const m = JSON.parse(ev.data);
      if (m.id && this.pending.has(m.id)) {
        const p = this.pending.get(m.id); this.pending.delete(m.id);
        m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result);
      } else if (m.method) {
        const ls = this.listeners.get(m.method); if (ls) ls.forEach(f => f(m.params));
      }
    });
  }
  send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = ++this.id; this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  on(m, f) { if (!this.listeners.has(m)) this.listeners.set(m, []); this.listeners.get(m).push(f); }
  off(m, f) { const a = this.listeners.get(m); if (a) { const i = a.indexOf(f); if (i >= 0) a.splice(i, 1); } }
  once(m) { return new Promise(res => { const f = p => { this.off(m, f); res(p); }; this.on(m, f); }); }
  close() { this.ws.close(); }
}

const EXTRACT = `(() => {
  const u = window.__INITIAL_STATE__?.user || {};
  const unwrap = x => (x && typeof x === 'object' && ('_value' in x || '_rawValue' in x)) ? (x._value ?? x._rawValue) : x;
  const n = unwrap(u.notes);
  const t0 = Array.isArray(n) ? (Array.isArray(n[0]) ? n[0] : n) : [];
  const rows = t0.map(item => {
    const c = item?.noteCard || {};
    return {
      noteId: c.noteId ?? item?.id ?? null,
      title: c.displayTitle ?? null,
      time: c.time ?? null,
      likedCount: c.interactInfo?.likedCount ?? null,
      type: c.type ?? null,
      sticky: c.interactInfo?.sticky ?? false,
      xsecToken: c.xsecToken ?? item?.xsecToken ?? null,
    };
  }).filter(r => r.noteId);
  const lines = document.body.innerText.split('\\n').map(s => s.trim()).filter(Boolean);
  const pick = kw => { const i = lines.findIndex(l => l === kw); return i > 0 ? lines[i - 1] : null; };
  const html = document.documentElement.outerHTML;
  const grab = re => { const m = html.match(re); return m ? m[1] : null; };
  const num = v => { if (v == null) return null; const s = String(v).replace(/,/g, ''); return /^\\d+$/.test(s) ? Number(s) : v; };
  return JSON.stringify({
    url: location.href,
    title: document.title,
    nickname: document.title.replace(/ - 小红书$/, '').trim() || null,
    redId: grab(/"redId":"([^"]+)"/) || (lines.find(l => l.startsWith('小红书号：')) || '').replace('小红书号：', '') || null,
    ipLocation: grab(/"ipLocation":"([^"]+)"/) || (lines.find(l => l.startsWith('IP属地：')) || '').replace('IP属地：', '') || null,
    follows: num(pick('关注') || grab(/"type":"follows"[^}]*?"count":"([^"]+)"/)),
    fans: num(pick('粉丝') || grab(/"type":"fans"[^}]*?"count":"([^"]+)"/)),
    totalLikedCollected: num(pick('获赞与收藏') || grab(/"type":"interaction"[^}]*?"count":"([^"]+)"/)),
    desc: grab(/"desc":"([^"]{0,300})"/),
    noteCount: rows.length,
    loginVisible: /登录|登 录/.test(document.body.innerText.slice(0, 300)),
    rows
  });
})()`;

const list = await (await fetch(`http://${HOST}:${PORT}/json/list`)).json();
const tab = list.find(t => t.type === 'page' && t.url.includes('xiaohongshu.com'));
if (!tab) throw new Error('没有小红书标签页');
const s = new CDP(tab.webSocketDebuggerUrl); await s.ready;
await s.send('Page.enable'); await s.send('Runtime.enable');

const inputs = JSON.parse(fs.readFileSync('links.json', 'utf8'));
const only = process.argv[2] ? process.argv[2].split(',').map(Number) : null;
const targets = only ? inputs.filter(p => only.includes(p.idx)) : inputs;
const results = [], failed = [];

async function scrape(url) {
  const loaded = s.once('Page.loadEventFired');
  await s.send('Page.navigate', { url });
  await Promise.race([loaded, sleep(15000)]);
  await sleep(2600);
  const r = await s.send('Runtime.evaluate', { expression: EXTRACT, returnByValue: true, awaitPromise: true });
  if (r.exceptionDetails) throw new Error('页面脚本异常: ' + JSON.stringify(r.exceptionDetails).slice(0, 300));
  const d = JSON.parse(r.result.value);
  if (!d.rows || d.rows.length === 0) throw new Error('笔记列表为空（可能被拦或登录失效）');
  return d;
}

for (let i = 0; i < targets.length; i++) {
  const p = targets[i];
  const url = `https://www.xiaohongshu.com/user/profile/${p.userId}?xsec_token=${p.token}&xsec_source=app_share`;
  log(`[${i + 1}/${targets.length}] #${p.idx} ${p.label} -> ${p.userId}`);
  let d = null, lastErr = '';
  for (let a = 0; a < 3 && !d; a++) {
    try { d = await scrape(url); }
    catch (e) { lastErr = e.message; log(`  第 ${a + 1} 次失败: ${lastErr}`); if (a < 2) await sleep(2500 + a * 2500); }
  }
  if (d) {
    const rec = { idx: p.idx, label: p.label, userId: p.userId, ...d };
    fs.writeFileSync(path.join(OUT, `${String(p.idx).padStart(2, '0')}.json`), JSON.stringify(rec, null, 2), 'utf8');
    results.push(rec);
    const times = d.rows.map(r => r.time).filter(Boolean).sort((a, b) => a - b);
    const fmt = t => t ? new Date(t + 8 * 3600e3).toISOString().slice(0, 10) : '?';
    log(`  OK ${d.nickname} | 粉${d.fans} | 笔记 ${d.noteCount} 篇 | ${fmt(times[0])} ~ ${fmt(times[times.length - 1])}`);
  } else {
    failed.push({ ...p, err: lastErr }); log('  最终失败，记入 failed');
  }
  fs.writeFileSync('profiles_all.json', JSON.stringify(results, null, 2), 'utf8');
  if (i < targets.length - 1) await sleep(MIN_GAP + Math.random() * (MAX_GAP - MIN_GAP));
}
fs.writeFileSync(path.join(OUT, 'failed.json'), JSON.stringify(failed, null, 2), 'utf8');
log(`完成：成功 ${results.length} / 失败 ${failed.length}`);
if (failed.length) log('失败清单:', JSON.stringify(failed.map(f => `${f.idx}:${f.err}`)));
s.close();
