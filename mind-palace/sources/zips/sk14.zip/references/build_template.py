import os
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml.ns import qn
import copy

# ---------- 设计令牌（复盘版主轴） ----------
C_MAIN   = 'EA4809'   # 结构主色
C_AUX    = 'EC7C30'   # 辅橙
C_TEXT   = '000000'
C_RED    = 'FF0000'   # 数据强调
C_GRAY   = '595959'   # 次级灰
C_TH1    = 'FAE4D5'   # 表头
C_TH2    = 'FBE3D5'   # 表头浅阶
C_ROW    = 'F4B083'   # 同比/环比行
C_THSUM  = 'F4B382'   # 汇总表头
C_BG     = 'FFFFFF'
C_LGRAY  = 'F1F1F1'
C_LINE   = 'D9D9D9'
C_NUM    = 'D8D8D8'   # 章节数字
FONT     = '微软雅黑'

LOGO = '/tmp/logo/emotion_brain_logo.png'

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]


def S():
    return prs.slides.add_slide(BLANK)


def rect(sl, x, y, w, h, fill=None, line=None, lw=0.75, rounded=False, radius=0.08):
    shp = sl.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE,
        Inches(x), Inches(y), Inches(w), Inches(h))
    if rounded:
        try:
            shp.adjustments[0] = radius
        except Exception:
            pass
    if fill:
        shp.fill.solid(); shp.fill.fore_color.rgb = RGBColor.from_string(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = RGBColor.from_string(line); shp.line.width = Pt(lw)
    else:
        shp.line.fill.background()
    shp.shadow.inherit = False
    shp.text_frame.text = ''
    return shp


def tb(sl, x, y, w, h, runs, size=14, color=C_TEXT, align=PP_ALIGN.LEFT,
       bold=False, anchor=MSO_ANCHOR.TOP, line_spacing=None, space_after=0, font=FONT):
    """runs: str 或 [(text, color, bold), ...] 或 [段落list]"""
    box = sl.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anchor
    if isinstance(runs, str):
        paras = [[(runs, color, bold)]]
    elif isinstance(runs, list) and runs and isinstance(runs[0], list):
        paras = []
        for _p in runs:
            if isinstance(_p, str):
                paras.append([(_p, color, bold)])
            elif isinstance(_p, tuple):
                paras.append([_p])
            else:
                paras.append([(it if isinstance(it, tuple) else (it, color, bold)) for it in _p])
    elif isinstance(runs, list):
        paras = [[(it if isinstance(it, tuple) else (it, color, bold)) for it in runs]]
    else:
        paras = [[(str(runs), color, bold)]]
    for i, p in enumerate(paras):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        para.alignment = align
        if line_spacing:
            para.line_spacing = line_spacing
        if space_after:
            para.space_after = Pt(space_after)
        items = p if isinstance(p, list) else [(p, color, bold)]
        for t, c, b in items:
            r = para.add_run(); r.text = t
            r.font.size = Pt(size); r.font.name = font
            r.font.bold = bool(b)
            r.font.color.rgb = RGBColor.from_string(c)
    return box


def logo(sl):
    sl.shapes.add_picture(LOGO, Inches(11.22), Inches(0.24), Inches(1.69), Inches(0.51))


def header(sl, title, tsize=24, tcolor=C_TEXT, with_logo=True):
    rect(sl, 0.09, 0.27, 0.44, 0.44, fill=C_MAIN)
    tb(sl, 0.75, 0.25, 9.6, 0.42, title, size=tsize, color=tcolor,
       anchor=MSO_ANCHOR.MIDDLE)
    if with_logo:
        logo(sl)
    rect(sl, 0.01, 0.86, 13.32, 0.06, fill=C_MAIN)


def lead(sl, runs, y=1.33):
    tb(sl, 0.75, y, 11.8, 0.32, runs, size=18, align=PP_ALIGN.CENTER)


def note(sl, text, y=6.55):
    tb(sl, 2.67, y, 10.30, 0.40, text, size=8, color=C_GRAY, align=PP_ALIGN.RIGHT)


def ph(sl, x, y, w, h, label='【图】'):
    rect(sl, x, y, w, h, fill=C_LGRAY, line=C_LINE)
    tb(sl, x, y + h / 2 - 0.16, w, 0.32, label, size=12, color=C_GRAY, align=PP_ALIGN.CENTER)


# ============================================================
# 01-P0 封面（白底简版）
# ============================================================
s = S()
s.shapes.add_picture(LOGO, Inches(0.75), Inches(0.96), Inches(2.58), Inches(0.78))
tb(s, 1.20, 2.90, 10.90, 0.78, [[('【客户名】', C_TEXT, False), ('  ', C_TEXT, False),
                                ('【交付物类型】', C_TEXT, False)]],
   size=40, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
tb(s, 8.96, 5.79, 2.33, 0.49, '情绪大脑出品', size=28, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
rect(s, 7.38, 6.05, 1.35, 0.04, fill=C_MAIN)

# ============================================================
# 02-P1 目录
# ============================================================
s = S()
tb(s, 1.92, 3.53, 1.30, 0.80, '目录', size=40, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
for i, t in enumerate(['01.【段名】', '02.【段名】', '03.【段名】', '04.【段名】']):
    tb(s, 4.53, 1.82 + i * 1.15, 5.00, 0.55, t, size=28, color=C_MAIN,
       anchor=MSO_ANCHOR.MIDDLE)

# ============================================================
# 03-P2 章节分隔
# ============================================================
s = S()
logo(s)
rect(s, 0.01, 0.86, 13.32, 0.06, fill=C_MAIN)
tb(s, 0.29, 3.45, 3.90, 3.96, '01', size=225, color=C_NUM, align=PP_ALIGN.CENTER,
   anchor=MSO_ANCHOR.TOP)
tb(s, 6.52, 4.89, 4.50, 0.95, '【章节名】', size=54, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
rect(s, 4.74, 6.13, 7.67, 0.04, fill=C_MAIN)

# ============================================================
# 04-P3 引语 / 观点
# ============================================================
s = S()
tb(s, 1.05, 2.20, 11.23, 1.00, '【一句判断，不超过 30 字】', size=40, color=C_TEXT,
   align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
tb(s, 1.47, 3.86, 10.81, 1.77,
   ['【展开句第一行，不超过 45 字。】', '【展开句第二行。一页只放一个判断。】'],
   size=20, color=C_TEXT, line_spacing=1.5)

# ============================================================
# 05-P4a 标准内容页（文字块）
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
lead(s, [[('【导语句：本页结论，', C_TEXT, False), ('要强调的数字', C_RED, True), ('改红色】', C_TEXT, False)]])
for i in range(4):
    tb(s, 0.90, 2.00 + i * 1.05, 11.70, 0.90,
       [[('•  ', C_TEXT, False), ('【正文块 ' + str(i + 1) + '：不超过 60 字】', C_TEXT, False)]],
       size=14, color=C_TEXT, line_spacing=1.35)
note(s, '注：统计范围为【××】；按照【成交/实收/核销】口径计算；已/未剔除【××】。')

# ============================================================
# 06-P4b 标准内容页（数据表格）
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
lead(s, [[('【导语句：本页结论，', C_TEXT, False), ('要强调的数字', C_RED, True), ('改红色】', C_TEXT, False)]])

rows, cols = 6, 5
gf = s.shapes.add_table(rows, cols, Inches(0.74), Inches(2.00), Inches(11.80), Inches(3.30))
tbl = gf.table
tbl.first_row = False
tbl.horz_banding = False
widths = [1.40, 2.60, 2.60, 2.60, 2.60]
for i, w in enumerate(widths):
    tbl.columns[i].width = Inches(w)

data = [
    ['时间', '商城', '美团外卖', '抖音核销', '汇总'],
    ['本期实收', '【】', '【】', '【】', '【】'],
    ['去年同期', '【】', '【】', '【】', '【】'],
    ['年同比', '【】', '【】', '【】', '【】'],
    ['上月', '【】', '【】', '【】', '【】'],
    ['月环比', '【】', '【】', '【】', '【】'],
]
head_fill = [C_TH1, C_TH1, C_TH1, C_TH1, C_THSUM]
for r in range(rows):
    for c in range(cols):
        cell = tbl.cell(r, c)
        cell.margin_left = cell.margin_right = Inches(0.08)
        cell.margin_top = cell.margin_bottom = Inches(0.02)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        if r == 0:
            bg = head_fill[c]
        elif r in (3, 5):
            bg = C_ROW
        else:
            bg = C_BG
        cell.fill.solid(); cell.fill.fore_color.rgb = RGBColor.from_string(bg)
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER if c > 0 else PP_ALIGN.LEFT
        run = p.add_run(); run.text = data[r][c]
        run.font.size = Pt(14 if (r == 0 and c == 0) else (12 if r == 0 else 11))
        run.font.name = FONT
        run.font.color.rgb = RGBColor.from_string(C_TEXT)
        # 去边框
        tcPr = cell._tc.get_or_add_tcPr()
        for tag in ('a:lnL', 'a:lnR', 'a:lnT', 'a:lnB'):
            for old in tcPr.findall(qn(tag)):
                tcPr.remove(old)
        for tag in ('a:lnL', 'a:lnR', 'a:lnT', 'a:lnB'):
            ln = tcPr.makeelement(qn(tag), {'w': '0', 'cap': 'flat'})
            nofill = ln.makeelement(qn('a:noFill'), {})
            ln.append(nofill)
            tcPr.insert(0, ln)

note(s, '注：统计范围为【××】；按照【成交/实收/核销】口径计算；已/未剔除【××】。')

# ============================================================
# 07-P5 三卡阵列
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
num_colors = [C_MAIN, C_AUX, C_GRAY]
xs = [1.00, 4.82, 8.64]
for i, x in enumerate(xs):
    rect(s, x, 2.26, 3.00, 2.72, fill=C_LGRAY, line=C_LINE, rounded=True, radius=0.06)
    tb(s, x + 0.25, 2.58, 0.55, 0.22, '0' + str(i + 1), size=13, color=num_colors[i])
    rect(s, x + 0.90, 2.73, 1.60, 0.01, fill=num_colors[i])
    tb(s, x + 0.32, 3.12, 2.36, 0.29, '【卡标题】', size=16, color=C_TEXT,
       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    tb(s, x + 0.36, 3.76, 2.28, 0.42, '【从什么走向什么】', size=10.8, color=C_TEXT,
       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
    tb(s, x + 0.35, 4.55, 2.30, 0.26, '【对应前面：××、××】', size=8.5, color=C_GRAY,
       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
tb(s, 1.25, 5.90, 10.10, 0.32, '【收束语：一句话，不超过 40 字】', size=15.5, color=C_TEXT,
   align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)

# ============================================================
# 08-P6 数据条对比
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
lead(s, [[('【导语句】', C_TEXT, False), ('强调处', C_RED, True)]])
rowspec = [(0.92, C_ROW, '【期次1】'), (0.62, C_AUX, '【期次2】'), (0.38, C_AUX, '【期次3】')]
for i, (ratio, barcolor, label) in enumerate(rowspec):
    y = 2.68 + i * 1.18
    tb(s, 0.95, y, 1.00, 0.22, label, size=12.5, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
    rect(s, 2.05, y + 0.02, 3.30, 0.28, fill=C_BG, line=C_LINE)
    rect(s, 2.05, y + 0.02, max(0.06, ratio * 3.04), 0.28, fill=barcolor)
    tb(s, 5.50, y, 0.70, 0.20, '【】%', size=10, color=barcolor, anchor=MSO_ANCHOR.MIDDLE)
    tb(s, 2.05, y + 0.44, 3.30, 0.20, '【指标说明】', size=9.5, color=C_GRAY)
    rect(s, 6.15, y + 0.02, 3.30, 0.28, fill=C_BG, line=C_LINE)
    rect(s, 6.15, y + 0.02, max(0.06, ratio * 3.04), 0.28, fill=barcolor)
    tb(s, 9.60, y, 0.70, 0.20, '【】%', size=10, color=barcolor, anchor=MSO_ANCHOR.MIDDLE)
    tb(s, 6.15, y + 0.44, 3.30, 0.20, '【指标说明】', size=9.5, color=C_GRAY)
    tb(s, 10.15, y + 0.03, 1.80, 0.24, '【代表品名】', size=9.5, color=C_TEXT)
note(s, '数据来源：【有赞 / 抖音 / 美团】；本期与同期同口径。', y=6.56)

# ============================================================
# 09-P7 双栏对比卡
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
for j, (x, bg, line) in enumerate([(0.84, 'ECDCD3', C_MAIN), (6.56, 'FFFFFF', C_GRAY)]):
    rect(s, x, 1.52, 5.05, 4.92, fill=bg, line=C_LINE)
    tb(s, x + 0.20, 1.78, 1.70, 0.26, '【对象名】', size=14.5, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
    rect(s, x + 2.08, 1.93, 2.35, 0.01, fill=line)
    ph(s, x + 0.20, 2.25, 2.02, 3.58, '【正面】')
    ph(s, x + 2.44, 2.25, 1.42, 1.72, '【侧拍】')
    ph(s, x + 2.44, 4.11, 1.42, 1.72, '【细节】')
    for k, lab in enumerate(['正面观察', '侧拍', '细节补充']):
        yy = [5.55, 3.69, 5.55][k]
        xx = [x + 0.20, x + 2.44, x + 2.44][k]
        ww = [2.02, 1.42, 1.42][k]
        rect(s, xx, yy, ww, 0.28, fill='000000')
        tb(s, xx, yy, ww, 0.28, lab, size=8, color='FFFFFF', align=PP_ALIGN.CENTER,
           anchor=MSO_ANCHOR.MIDDLE)
note(s, '资料来源：【5.14-5.15 徐州走访调研 · 产品测试照片】。')

# ============================================================
# 10-P8 图片网格
# ============================================================
s = S()
rect(s, 0.10, 0.31, 0.44, 0.44, fill=C_MAIN)
tb(s, 0.05, 0.14, 0.70, 0.60, '口', size=32, color=C_MAIN, align=PP_ALIGN.LEFT,
   anchor=MSO_ANCHOR.MIDDLE)
tb(s, 0.78, 0.25, 9.6, 0.42, '【页标题】', size=24, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
logo(s)
rect(s, 0.01, 0.86, 13.32, 0.06, fill=C_MAIN)
rect(s, 0.76, 1.36, 12.02, 0.77, fill=C_LGRAY)
tb(s, 0.76, 1.36, 12.02, 0.77, '【这一组的共性，如：切块甜品（薄巧、桃子、蜜瓜、葡萄）】',
   size=17, color=C_RED, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
for i, x in enumerate([0.76, 4.85, 8.94]):
    ph(s, x, 2.51, 3.84, 4.35, '【图 ' + str(i + 1) + '】')

# ============================================================
# 11-P9 整页图
# ============================================================
s = S()
header(s, '【页标题：写结论，不写栏目名】')
ph(s, 0.45, 1.04, 12.54, 6.39, '【整页图：活动计划表 / 甘特图 / 主视觉】')

# ============================================================
# 12-P10 小结页
# ============================================================
s = S()
header(s, '【页标题，如：开业小结】')
rect(s, 0.88, 1.31, 11.78, 5.72, fill=None, line=C_AUX, lw=2.0, rounded=True, radius=0.10)
tb(s, 1.69, 2.03, 10.60, 0.66,
   [[('•  ', C_TEXT, False), ('【导语段：一段话把事情说清，不超过 60 字】', C_TEXT, False)]],
   size=18, line_spacing=1.3)
for k, (t, y, items) in enumerate([
        ('亮点', 2.93, ['【亮点1，关键数字用红色】', '【亮点2】', '【亮点3】']),
        ('暗点', 5.23, ['【暗点1】', '【暗点2】', '【暗点3】'])]):
    tb(s, 2.06, y, 10.00, 0.32, '•  ' + t, size=18, color=C_TEXT, anchor=MSO_ANCHOR.MIDDLE)
    for i, it in enumerate(items):
        tb(s, 2.19, y + 0.44 + i * 0.43, 10.00, 0.30,
           [('✓  ', C_TEXT, False), (it, C_TEXT, False)], size=16)

# ============================================================
# 13-P11 结尾页
# ============================================================
s = S()
rect(s, 0.01, 0.86, 13.32, 0.06, fill=C_MAIN)
logo(s)
for i, ch in enumerate('感谢观看'):
    tb(s, 3.60 + i * 1.02, 3.54, 0.55, 0.70, ch, size=40, color=C_TEXT,
       align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
rect(s, 3.50, 4.63, 7.98, 0.05, fill=C_MAIN)

# ============================================================
# 14-P12 二级小节页
# ============================================================
s = S()
header(s, '【段名 + 序号. 主题，如：数据回顾 1. 营业额数据】', tsize=21,
       tcolor='231D19', with_logo=False)

# ============================================================
# 15-P13 建议页
# ============================================================
s = S()
header(s, '【问题N：××】', tsize=20)
tb(s, 1.00, 2.20, 11.33, 0.40, '建议——', size=20, color=C_RED, align=PP_ALIGN.CENTER)
tb(s, 1.00, 2.90, 11.33, 0.50, '【结论句：一句可执行的主张】', size=24, color=C_TEXT,
   align=PP_ALIGN.CENTER)
tb(s, 1.00, 3.60, 11.33, 0.40, '【说明行 1：内部视角，不超过 45 字】', size=16,
   color=C_TEXT, align=PP_ALIGN.CENTER)
tb(s, 1.00, 4.05, 11.33, 0.40, '【说明行 2：用户视角，不超过 45 字】', size=16,
   color=C_TEXT, align=PP_ALIGN.CENTER)

OUT = '/Users/a15608/WorkBuddy/工作/某蛋糕品牌A/05-版式/情绪大脑_客户交付PPT_空白模板_20260917_v1.pptx'
os.makedirs(os.path.dirname(OUT), exist_ok=True)
prs.save(OUT)
print('saved:', OUT)
print('slides:', len(prs.slides.__iter__.__self__._sldIdLst))
