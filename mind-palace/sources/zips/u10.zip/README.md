# 活动连带消费诊断专家（Campaign Linked-Spend Diagnosis）

判断权益卡／会员卡／低价拉新活动卖出去之后，有没有带来真实连带消费、增量与 ROI。沉淀自 2026-11 某蛋糕品牌A权益卡效果复盘。

## 类型

Agent 型（单个 AI 专家），附带 Skill `campaign-linked-spend-diagnosis`。

## 功能

- 卡池识别：以发卡记录为准，不从订单金额倒推
- 时间口径：每人自己的领卡日 T0，前后等长 90 天
- 特殊处理：剔卡本单、0 元单算兑换、剔团购大单、申报手机号缺失
- 分层与四效果：拉新／激活／提频／提产，配对照组读增量
- **ROI 闸门：逐卡确认权益附赠内容与单份成本之前，净额与 ROI 一律不出数**
- 输出：结论先行、百分比带分母、复盘页默认以总结收束、数据边界显式申报

## 使用示例

- 我有一份权益卡发卡记录和用户消费明细，帮我判断买卡后有没有产生连带消费
- 按卡项分开对比拉新、激活、提频、提产的效果，并算 ROI
- 这种低价或免费权益卡该不该继续做？给我数据依据

## 包内结构

```
.codebuddy-plugin/plugin.json          专家展示与注册信息
agents/campaign-linked-spend-diagnosis.md   角色定义
skills/campaign-linked-spend-diagnosis/
  SKILL.md                            完整诊断 SOP（含 ROI 闸门）
  references/案例-某蛋糕品牌A权益卡复盘.md      真实案例与踩坑记录
  references/头像prompt.md                 可选：AI 头像替换 prompt
  templates/权益内容确认清单.md          开工前必须发给用户的确认表
  templates/诊断报告骨架.md              输出结构
avatars/expert.png                   头像
README.md
```

## 头像

`avatars/expert.png` 为本地绘制的 512×512 扁平插画（未调用 AI 生图，不消耗额度）。如需换成漫画人像，可用 ImageGen 生成后替换（PNG/JPG，512×512，≤500KB；单张约消耗 5–10 额度）。推荐 prompt 见 `skills/campaign-linked-spend-diagnosis/references/头像prompt.md`。

## 安装

专家包目录须位于：

```
~/.workbuddy/plugins/marketplaces/my-experts/plugins/campaign-linked-spend-diagnosis/
```

注册后才能在 WorkBuddy 专家中心看到：

```bash
python3 scripts/register_expert.py <expert-dir>
```

## 打包分享

```bash
python3 scripts/package_expert.py <expert-dir>
```

产出 zip 可直接发给同事，放入各自专家目录后重新注册即可复用。
