# 头像替换用 prompt（可选）

当前 `avatars/expert.png` 是本地绘制的 512×512 扁平插画，未调用 AI 生图。
如需漫画人像，用 ImageGen（单张约 5–10 额度），`size` 设 `"1024x1024"`，生成后缩放到 512×512 并替换。

分类 `05-MarketingGrowth` → 背景色调 red-orange。

```
Professional cartoon-style illustration avatar, a female campaign and membership ROI analyst,
wearing smart casual attire and slim glasses, holding a small report showing cohort bar charts and a membership card,
calm, skeptical and precise expression,
subtle rising bar charts, coupon icons and customer cohort dots in the background.
Bust shot, facing forward. Clean simple red-orange toned background. High quality, professional, natural.
```
