#!/usr/bin/env python3
"""
批量高德地理编码脚本
读取Excel中的订单地址，调用高德地图API获取经纬度和行政区信息。

用法:
  python3 geocode_batch.py --excel <path> --city <城市名或adcode> --api-key <高德key> [选项]

必需参数:
  --excel      Excel文件路径
  --city       城市名称(如"宁波市")或高德adcode(如"330200")
  --api-key    高德Web API Key

可选参数:
  --sheet      工作表名称(默认自动检测第一个含数据的sheet)
  --address-col 地址列名或列号(0-based，默认自动检测含"地址"的列)
  --start-row  数据起始行(0-based，默认自动跳过表头)
  --output     输出JSON路径(默认/tmp/geocode_results.json)
  --rate       API调用间隔秒数(默认0.2，约5QPS)

输出: JSON数组，每条记录包含 address, lng, lat, district, city, province, formatted_address
"""

import argparse
import json
import os
import sys
import time

try:
    import openpyxl
except ImportError:
    print("需要 openpyxl: pip install openpyxl")
    sys.exit(1)

try:
    import requests
except ImportError:
    print("需要 requests: pip install requests")
    sys.exit(1)


AMAP_API_URL = "https://restapi.amap.com/v3/geocode/geo"


def detect_sheet(wb):
    """自动检测含数据的工作表"""
    for name in wb.sheetnames:
        ws = wb[name]
        if ws.max_row > 1 and ws.max_column > 1:
            return name
    return wb.sheetnames[0]


def find_address_column(ws, start_row=0):
    """
    自动检测地址列：
    1. 先在表头行找含"地址"的列
    2. 找不到则在数据行中找含最多中文地址特征的列
    """
    # 尝试表头匹配
    for row_idx, row in enumerate(ws.iter_rows(min_row=start_row + 1, max_row=start_row + 10, values_only=True)):
        for col_idx, cell in enumerate(row):
            if cell and isinstance(cell, str) and "地址" in cell:
                return col_idx, row_idx + 1  # 返回列索引和数据起始行

    # 数据行特征匹配：找含中文+数字+路/街/号等关键词最多的列
    best_col = None
    best_score = 0
    sample_rows = list(ws.iter_rows(min_row=start_row + 1, max_row=start_row + 50, values_only=True))
    if not sample_rows:
        return None, start_row + 1

    num_cols = max(len(r) for r in sample_rows) if sample_rows else 0
    keywords = ["路", "街", "号", "道", "巷", "弄", "室", "楼", "栋", "单元", "幢"]

    for col_idx in range(num_cols):
        score = 0
        non_empty = 0
        for row in sample_rows:
            if col_idx < len(row) and row[col_idx] and isinstance(row[col_idx], str):
                non_empty += 1
                text = str(row[col_idx])
                if any(kw in text for kw in keywords):
                    score += 1
                if len(text) > 5:
                    score += 1
        if non_empty > 0 and score > best_score:
            best_score = score
            best_col = col_idx

    data_start = start_row + 1
    if best_col is not None and best_score > 0:
        return best_col, data_start

    # 最后兜底：取最后一列（很多订单表地址在最后）
    return num_cols - 1 if num_cols > 0 else None, data_start


def geocode_address(api_key, address, city, timeout=10):
    """调用高德地理编码API"""
    resp = requests.get(AMAP_API_URL, params={
        "key": api_key,
        "address": address,
        "city": city,
    }, timeout=timeout)
    data = resp.json()

    if data.get("status") == "1" and data.get("geocodes") and len(data["geocodes"]) > 0:
        geo = data["geocodes"][0]
        loc = geo.get("location", "").split(",")
        lng = float(loc[0]) if len(loc) == 2 else None
        lat = float(loc[1]) if len(loc) == 2 else None
        return {
            "lng": lng,
            "lat": lat,
            "district": geo.get("district", ""),
            "city": geo.get("city", ""),
            "province": geo.get("province", ""),
            "formatted_address": geo.get("formatted_address", ""),
            "level": geo.get("level", ""),
        }
    else:
        return {
            "lng": None, "lat": None,
            "district": "API未返回",
            "error": str(data),
        }


def main():
    parser = argparse.ArgumentParser(description="批量高德地理编码")
    parser.add_argument("--excel", required=True, help="Excel文件路径")
    parser.add_argument("--city", required=True, help="城市名称或adcode")
    parser.add_argument("--api-key", required=True, help="高德Web API Key")
    parser.add_argument("--sheet", default=None, help="工作表名称(默认自动检测)")
    parser.add_argument("--address-col", default=None, help="地址列名或列号(0-based)")
    parser.add_argument("--start-row", type=int, default=None, help="数据起始行(0-based)")
    parser.add_argument("--output", default="/tmp/geocode_results.json", help="输出JSON路径")
    parser.add_argument("--rate", type=float, default=0.2, help="API调用间隔秒数")
    args = parser.parse_args()

    # 1. 读取Excel
    print(f"读取Excel: {args.excel}")
    wb = openpyxl.load_workbook(args.excel, read_only=True, data_only=True)

    sheet_name = args.sheet or detect_sheet(wb)
    ws = wb[sheet_name]
    print(f"工作表: {sheet_name}")

    # 2. 检测地址列
    if args.address_col is not None:
        if args.address_col.isdigit():
            addr_col_idx = int(args.address_col)
        else:
            # 按列名查找
            addr_col_idx = None
            for row in ws.iter_rows(min_row=1, max_row=10, values_only=True):
                for ci, cell in enumerate(row):
                    if cell and isinstance(cell, str) and args.address_col in cell:
                        addr_col_idx = ci
                        break
                if addr_col_idx is not None:
                    break
            if addr_col_idx is None:
                print(f"错误: 未找到列名 '{args.address_col}'")
                sys.exit(1)
    else:
        addr_col_idx, _ = find_address_column(ws, 0)
        if addr_col_idx is None:
            print("错误: 无法自动检测地址列，请用 --address-col 指定")
            sys.exit(1)

    # 3. 确定数据起始行
    if args.start_row is not None:
        data_start = args.start_row
    else:
        # 自动跳过表头：找第一个地址列有数据的行
        data_start = 1
        for row_idx, row in enumerate(ws.iter_rows(min_row=1, max_row=20, values_only=True)):
            if addr_col_idx < len(row) and row[addr_col_idx] and str(row[addr_col_idx]).strip():
                # 检查是否是表头（含"地址"字样）
                val = str(row[addr_col_idx])
                if "地址" in val or "Address" in val.lower():
                    data_start = row_idx + 2  # 表头下一行
                else:
                    data_start = row_idx + 1
                break

    print(f"地址列: 第{addr_col_idx}列(0-based), 数据起始行: {data_start}")

    # 4. 提取地址
    addresses = []
    for row in ws.iter_rows(min_row=data_start, values_only=True):
        if addr_col_idx < len(row) and row[addr_col_idx] and str(row[addr_col_idx]).strip():
            addresses.append(str(row[addr_col_idx]).strip())
    wb.close()
    print(f"提取到 {len(addresses)} 条地址")

    if not addresses:
        print("错误: 未提取到任何地址")
        sys.exit(1)

    # 5. 断点续传
    progress_file = args.output + ".progress"
    results = []
    start_idx = 0
    try:
        with open(progress_file, "r") as f:
            progress = json.load(f)
            results = progress.get("results", [])
            start_idx = progress.get("last_idx", 0)
            print(f"从断点恢复: 已完成 {start_idx} 条")
    except (FileNotFoundError, json.JSONDecodeError):
        print("全新开始")

    # 6. 逐条调用API
    success = 0
    fail = 0
    total = len(addresses)

    for i in range(start_idx, total):
        addr = addresses[i]
        try:
            result = geocode_address(args.api_key, addr, args.city)
            result["address"] = addr
            results.append(result)
            if result["lng"] is not None:
                success += 1
            else:
                fail += 1
        except Exception as e:
            results.append({"address": addr, "lng": None, "lat": None, "district": "请求异常", "error": str(e)})
            fail += 1

        # 进度输出
        if (i + 1) % 100 == 0 or i == total - 1:
            pct = (i + 1) / total * 100
            print(f"  [{i + 1}/{total}] {pct:.1f}%  成功:{success}  失败:{fail}")

        # 断点保存
        if (i + 1) % 200 == 0:
            with open(progress_file, "w") as f:
                json.dump({"last_idx": i + 1, "results": results}, f, ensure_ascii=False)

        time.sleep(args.rate)

    # 7. 保存最终结果
    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    # 清理断点文件
    if os.path.exists(progress_file):
        os.remove(progress_file)

    print(f"\n=== 完成 ===")
    print(f"总计: {len(results)} 条")
    print(f"成功: {success} 条")
    print(f"失败: {fail} 条")
    print(f"结果已保存至: {args.output}")


if __name__ == "__main__":
    main()
