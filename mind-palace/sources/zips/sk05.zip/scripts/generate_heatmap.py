#!/usr/bin/env python3
"""
订单热力图生成脚本
读取地理编码结果JSON，生成自包含的HTML热力图+散点分布图。

用法:
  python3 generate_heatmap.py --input <geocode_results.json> --output <heatmap.html> [选项]

必需参数:
  --input    地理编码结果JSON路径
  --output   输出HTML路径

可选参数:
  --city          城市名称(用于标题，默认"订单")
  --center-lat    地图中心纬度(默认自动计算所有点质心)
  --center-lng    地图中心经度(默认自动计算所有点质心)
  --zoom          地图缩放级别(默认12)
  --store-lat     门店/中心点纬度(用于计算距离，可选)
  --store-lng     门店/中心点经度
  --store-name    门店名称(用于标注)
  --mode          显示模式: heatmap(热力图) / scatter(散点图) / both(默认both)

输出: 自包含HTML文件，使用Leaflet + leaflet.heat插件
"""

import argparse
import json
import math
import os
import sys
from collections import Counter, defaultdict


def haversine(lat1, lng1, lat2, lng2):
    """计算两点间直线距离(km)"""
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlng = math.radians(lng2 - lng1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng / 2) ** 2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


DISTRICT_PALETTE = [
    "#e74c3c", "#e67e22", "#f39c12", "#2ecc71", "#3498db",
    "#9b59b6", "#1abc9c", "#e91e63", "#00bcd4", "#8bc34a",
]


def generate_html(data, city, center_lat, center_lng, zoom, store_lat, store_lng, store_name, mode):
    """生成自包含HTML"""

    # 过滤有效点
    valid = [d for d in data if d.get("lng") is not None and d.get("lat") is not None]
    failed = len(data) - len(valid)

    if not valid:
        return "<html><body><h2>没有有效的地理编码数据</h2></body></html>"

    # 计算质心
    if center_lat is None or center_lng is None:
        center_lat = sum(d["lat"] for d in valid) / len(valid)
        center_lng = sum(d["lng"] for d in valid) / len(valid)

    # 按区分组
    by_district = defaultdict(list)
    for d in valid:
        dist = d.get("district", "未知") or "未知"
        by_district[dist].append(d)

    district_stats = {}
    for dist, pts in sorted(by_district.items(), key=lambda x: -len(x[1])):
        district_stats[dist] = len(pts)

    total = len(valid)

    # 分配颜色
    district_colors = {}
    for i, dist in enumerate(district_stats.keys()):
        district_colors[dist] = DISTRICT_PALETTE[i % len(DISTRICT_PALETTE)]

    # 距离统计
    distance_stats = ""
    if store_lat is not None and store_lng is not None:
        distances = []
        for d in valid:
            dist = haversine(store_lat, store_lng, d["lat"], d["lng"])
            distances.append(dist)
        distances.sort()
        avg_dist = sum(distances) / len(distances)
        max_dist = distances[-1]
        median_dist = distances[len(distances) // 2]
        within_5km = sum(1 for d in distances if d <= 5)
        within_10km = sum(1 for d in distances if d <= 10)
        pct_5 = within_5km / total * 100
        pct_10 = within_10km / total * 100

        distance_stats = f"""
        <div class="section-title">距离分析</div>
        <div class="dist-row"><span>平均距离</span><b>{avg_dist:.1f} km</b></div>
        <div class="dist-row"><span>中位距离</span><b>{median_dist:.1f} km</b></div>
        <div class="dist-row"><span>最远订单</span><b>{max_dist:.1f} km</b></div>
        <div class="dist-row"><span>5km内</span><b>{within_5km} 单 ({pct_5:.0f}%)</b></div>
        <div class="dist-row"><span>10km内</span><b>{within_10km} 单 ({pct_10:.0f}%)</b></div>
        """

    # 准备热力图数据点
    heat_points = []
    for d in valid:
        heat_points.append([d["lat"], d["lng"], 0.8])

    # 准备散点数据（按区分组）
    scatter_by_district = {}
    for dist, pts in by_district.items():
        scatter_by_district[dist] = [{"lat": p["lat"], "lng": p["lng"], "address": p.get("address", "")} for p in pts]

    # 门店标记
    store_marker = ""
    if store_lat is not None and store_lng is not None:
        store_marker = f"var storeMarker = L.marker([{store_lat}, {store_lng}]).addTo(map).bindPopup('{store_name or '门店'}');"

    # 侧边栏区域统计HTML
    max_count = max(district_stats.values()) if district_stats else 1
    legend_html = ""
    for dist, count in district_stats.items():
        pct = count / total * 100
        bar_width = count / max_count * 100
        color = district_colors[dist]
        legend_html += f"""<div class="legend-item">
            <span class="dot" style="background:{color}"></span>
            <span class="legend-name">{dist}</span>
            <div class="bar-container"><div class="bar-fill" style="width:{bar_width:.1f}%;background:{color}"></div></div>
            <span class="legend-count">{count} 单</span>
            <span class="legend-pct">{pct:.1f}%</span>
        </div>"""

    # 散点图层JS
    scatter_js = ""
    if mode in ("scatter", "both"):
        scatter_js = "\n    // 散点图层\n"
        for dist, pts in scatter_by_district.items():
            color = district_colors[dist]
            pts_js = json.dumps([[p["lat"], p["lng"]] for p in pts])
            scatter_js += f'    var pts_{abs(hash(dist))} = {pts_js};\n'
            scatter_js += f'    for (var i = 0; i < pts_{abs(hash(dist))}.length; i++) {{\n'
            scatter_js += f'        L.circleMarker(pts_{abs(hash(dist))}[i], {{radius:4, fillColor:"{color}", color:"#fff", weight:0.5, opacity:0.8, fillOpacity:0.6}}).addTo(scatterGroup);\n'
            scatter_js += f'    }}\n'

    # 热力图层JS
    heat_js = ""
    if mode in ("heatmap", "both"):
        heat_js = f'    var heatLayer = L.heatLayer({json.dumps(heat_points)}, {{radius:25, blur:15, maxZoom:17}});\n'

    # 图层控制
    layers_js = ""
    if mode == "both":
        layers_js = """
    L.control.layers(null, {
        '热力图': heatLayer,
        '散点图': scatterGroup
    }).addTo(map);
    heatLayer.addTo(map);
"""
    elif mode == "heatmap":
        layers_js = "    heatLayer.addTo(map);"
    elif mode == "scatter":
        layers_js = "    scatterGroup.addTo(map);"

    title = f"{city}订单分布图" if city else "订单分布图"

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet.heat@0.2.0/leaflet-heat.js"></script>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{ font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif; background:#f5f5f5; }}
#container {{ display:flex; height:100vh; }}
#map-container {{ flex:1; position:relative; }}
#map {{ width:100%; height:100%; }}
#sidebar {{
    width:360px; background:#fff; overflow-y:auto;
    box-shadow:-2px 0 20px rgba(0,0,0,0.08); padding:24px;
    display:flex; flex-direction:column; gap:14px;
}}
#sidebar h2 {{ font-size:20px; color:#1a1a2e; }}
#sidebar .subtitle {{ font-size:13px; color:#888; }}
#sidebar .total-line {{ font-size:13px; color:#555; padding:10px 0; border-bottom:1px solid #eee; }}
#sidebar .total-line b {{ color:#e74c3c; font-size:15px; }}
.section-title {{ font-size:14px; font-weight:600; color:#333; margin-top:4px; }}
.legend-item {{ display:flex; align-items:center; gap:8px; padding:5px 0; font-size:13px; }}
.legend-item .dot {{ width:12px; height:12px; border-radius:50%; flex-shrink:0; }}
.legend-item .legend-name {{ min-width:60px; color:#333; font-weight:500; }}
.legend-item .legend-count {{ color:#e74c3c; font-weight:600; min-width:56px; text-align:right; }}
.legend-item .legend-pct {{ color:#999; font-size:12px; min-width:44px; text-align:right; }}
.bar-container {{ flex:1; height:6px; background:#f0f0f0; border-radius:3px; overflow:hidden; }}
.bar-fill {{ height:100%; border-radius:3px; }}
.dist-row {{ display:flex; justify-content:space-between; padding:4px 0; font-size:13px; color:#555; }}
.dist-row b {{ color:#333; }}
.note {{ font-size:11px; color:#888; line-height:1.6; margin-top:4px; padding:8px; background:#f9f9f9; border-radius:6px; }}
.leaflet-container {{ background:#e8e8e8; }}
</style>
</head>
<body>
<div id="container">
<div id="sidebar">
    <h2>{title}</h2>
    <div class="subtitle">高德API地理编码 · {len(data)}条地址</div>
    <div class="total-line">总地址：<b>{len(data)}</b> 条 · 成功编码：<b>{total}</b> 条{f' · 失败：<b>{failed}</b>' if failed else ''}</div>
    <div class="section-title">各区域订单分布</div>
    {legend_html}
    {distance_stats}
    <div class="note">数据源：高德地图API地理编码<br>生成时间：自动</div>
</div>
<div id="map-container">
    <div id="map"></div>
</div>
</div>
<script>
var scatterData = {json.dumps(scatter_by_district, ensure_ascii=False)};
var districtColors = {json.dumps(district_colors, ensure_ascii=False)};

var map = L.map('map', {{ zoomControl:true }}).setView([{center_lat}, {center_lng}], {zoom});
L.tileLayer('https://{{s}}.basemaps.cartocdn.com/light_all/{{z}}/{{x}}/{{y}}{{r}}.png', {{
    attribution: '&copy; OpenStreetMap &copy; CARTO',
    maxZoom: 19
}}).addTo(map);

{store_marker}

var scatterGroup = L.layerGroup();
{scatter_js}

{heat_js}
{layers_js}
</script>
</body>
</html>"""
    return html


def main():
    parser = argparse.ArgumentParser(description="生成订单热力图HTML")
    parser.add_argument("--input", required=True, help="地理编码结果JSON路径")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    parser.add_argument("--city", default="订单", help="城市名称(用于标题)")
    parser.add_argument("--center-lat", type=float, default=None, help="地图中心纬度")
    parser.add_argument("--center-lng", type=float, default=None, help="地图中心经度")
    parser.add_argument("--zoom", type=int, default=12, help="地图缩放级别")
    parser.add_argument("--store-lat", type=float, default=None, help="门店纬度")
    parser.add_argument("--store-lng", type=float, default=None, help="门店经度")
    parser.add_argument("--store-name", default=None, help="门店名称")
    parser.add_argument("--mode", choices=["heatmap", "scatter", "both"], default="both", help="显示模式")
    args = parser.parse_args()

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    html = generate_html(
        data, args.city, args.center_lat, args.center_lng, args.zoom,
        args.store_lat, args.store_lng, args.store_name, args.mode
    )

    os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"热力图已生成: {args.output}")
    print(f"总地址: {len(data)} 条")
    valid = sum(1 for d in data if d.get("lng") is not None)
    print(f"有效编码: {valid} 条 ({valid / len(data) * 100:.1f}%)")


if __name__ == "__main__":
    main()
