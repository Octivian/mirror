#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
商品销量诊断 · 第二步：把诊断数据注入模板，产出单文件 HTML 报告。

用法：
    python build_report.py --json ./out/诊断数据.json [--out ./out] [--single]

--single  把 ECharts 内联进 HTML（默认开启），产出可直接双击打开、可发给别人的单文件。
        加 --no-single 则输出引用外部 echarts.min.js 的轻量版（需与 echarts.min.js 同目录）。
"""
import argparse
import json
import os
import shutil
import sys

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TPL = os.path.join(SKILL_DIR, 'assets', 'template.html')
ECH = os.path.join(SKILL_DIR, 'assets', 'echarts.min.js')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--json', required=True, help='diagnose.py 产出的 JSON')
    ap.add_argument('--out', help='输出目录（默认与 JSON 同目录）')
    ap.add_argument('--name', help='输出文件名（不含扩展名）')
    ap.add_argument('--no-single', action='store_true', help='不内联 ECharts')
    args = ap.parse_args()

    data = json.load(open(args.json, encoding='utf-8'))
    out = args.out or os.path.dirname(os.path.abspath(args.json))
    os.makedirs(out, exist_ok=True)

    html = open(TPL, encoding='utf-8').read()

    client = data['元信息'].get('客户') or ''
    rng = data['元信息']['数据区间']
    title = f"{client + ' · ' if client else ''}商品销量诊断 {rng[0]} – {rng[1]}"

    payload = json.dumps(data, ensure_ascii=False, default=str).replace('</', '<\\/')

    single = not args.no_single
    if single:
        if not os.path.exists(ECH):
            sys.exit(f'找不到 {ECH}\n请先下载 ECharts 放入 assets/，或加 --no-single 用外链模式。')
        ech = open(ECH, encoding='utf-8').read()
        if '</script' in ech:
            sys.exit('echarts.min.js 内含 </script，无法安全内联。请加 --no-single。')
        html = html.replace('<script src="./echarts.min.js"></script>',
                            '<script>/* ECharts 5.4.3 (inlined) */\n' + ech + '\n</script>')

    html = html.replace('__TITLE__', title).replace('__DATA__', payload)

    base = args.name or (f"{client + '_' if client else ''}商品销量诊断_{rng[1]}")
    path = os.path.join(out, base + '.html')
    open(path, 'w', encoding='utf-8').write(html)

    if not single:
        dst = os.path.join(out, 'echarts.min.js')
        if not os.path.exists(dst):
            shutil.copy(ECH, dst)

    size = os.path.getsize(path) / 1024 / (1024 if single else 1)
    print(f"✅ 报告：{path}  ({size:.2f} {'MB' if single else 'KB'}{'，单文件可直发' if single else '，需带 echarts.min.js'})")
    return path


if __name__ == '__main__':
    main()
