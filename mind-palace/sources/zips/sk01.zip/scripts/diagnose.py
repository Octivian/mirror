#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
商品销量诊断 · 第一步：数据计算
输入商品明细表（可选再给订单表取付款时间/支付方式），输出标准 JSON。

用法示例
--------
# 最简：只给商品明细（表内自带日期列）
python diagnose.py --goods 商品明细.xlsx --out ./out --client 某某品牌

# 有赞导出：商品明细 + 订单表（商品表本身没有日期，需要从订单表取付款时间）
python diagnose.py --goods Goods.csv --order Order.csv --out ./out --client 某蛋糕品牌A

# 指定分析窗口、门槛、剔除的支付方式
python diagnose.py --goods goods.csv --order order.csv --days 60 --min-base-qty 5 \
    --exclude-pay "抖音券,美团券,外部支付" --out ./out

字段自动识别，也可用 --col-* 覆盖：
  --col-name 商品名称 --col-qty 商品数量 --col-amt 商品实际成交金额
  --col-date 买家付款时间 --col-order 订单号 --col-cat 商品一级分类
  --col-price 商品单价 --col-status 订单商品状态 --col-pay 付款方式
"""
import argparse
import json
import os
import re
import sys

import numpy as np
import pandas as pd

# ----------------------------------------------------------------------------
# 列名候选（按优先级）
# ----------------------------------------------------------------------------
CAND = {
    'name':   ['商品名称', '商品名', '产品名称', '品名', '货品名称', 'item_name', 'product_name', 'product'],
    'qty':    ['商品数量', '数量', '件数', '销量', '销售数量', 'qty', 'quantity', 'num'],
    'amt':    ['商品实际成交金额', '实际成交金额', '成交金额', '实收金额', '销售额', '金额',
               'amount', 'sales_amount', 'revenue'],
    'price':  ['商品单价', '单价', '售价', 'price', 'unit_price'],
    'cat':    ['商品一级分类', '一级分类', '分类', '品类', '类目', 'category', 'cat'],
    'date':   ['买家付款时间', '付款时间', '支付时间', '订单创建时间', '下单时间', '交易时间',
               '日期', 'date', 'pay_time', 'order_time'],
    'order':  ['订单号', '订单编号', '主订单号', 'order_id', 'order_no'],
    'status': ['订单商品状态', '商品状态', '订单状态', 'status'],
    'pay':    ['付款方式', '支付方式', 'pay_method', 'payment'],
}

# 非售卖 / 非商品行（运费、补差、赠品包装等）
NON_SALE_PAT = r'来图定制|临时商品|运费|补差价|差价|蜡烛|刀叉|餐具|收藏福利|包装费|配送费'

# 节令关键词 —— 【仅指具体节日】与节令食品，命中即视为节日短期产品，默认不纳入下架判定
# 注意：秋冬限定 / 季节限定 / 时令 / 夏日 这类「季节描述」不算节令，正常参与下架判定
FESTIVAL_PAT = (
    r'中秋|月饼|情人节|万圣节|万圣|圣诞|元旦|跨年|春节|年货|元宵|端午|粽子|七夕|'
    r'母亲节|父亲节|教师节|国庆|重阳|腊八|感恩节|愚人节|儿童节|复活节|'
    r'圣诞节|平安夜|除夕|小年|清明|妇女节|劳动节|建党节|建军节'
)

WEEKDAY_CN = ['一', '二', '三', '四', '五', '六', '日']


# ----------------------------------------------------------------------------
# 工具函数
# ----------------------------------------------------------------------------
def read_tables(paths, sheet=None):
    """读一个或多个 CSV / Excel 并纵向拼接。"""
    frames = []
    for p in paths:
        ext = os.path.splitext(p)[1].lower()
        if ext in ('.xlsx', '.xls', '.xlsm'):
            df = pd.read_excel(p, sheet_name=sheet if sheet else 0)
        else:
            df = None
            for enc in ('utf-8-sig', 'utf-8', 'gbk', 'gb18030', 'latin-1'):
                try:
                    df = pd.read_csv(p, encoding=enc, low_memory=False)
                    break
                except UnicodeDecodeError:
                    continue
            if df is None:
                raise RuntimeError(f'无法识别编码：{p}')
        df['__src'] = os.path.basename(p)
        frames.append(df)
        print(f'   · 读入 {os.path.basename(p)}：{len(df)} 行')
    if len(frames) == 1:
        return frames[0]
    # 多文件拼接：列取交集，避免某月缺列报错
    cols = set(frames[0].columns)
    for f in frames[1:]:
        cols &= set(f.columns)
    cols = [c for c in frames[0].columns if c in cols]
    return pd.concat([f[cols] for f in frames], ignore_index=True)


def find_col(df, key, override=None):
    """按候选名找列；override 优先。找不到返回 None。"""
    if override:
        if override in df.columns:
            return override
        raise KeyError(f'指定的列不存在：{override}｜实际列：{list(df.columns)[:25]}')
    for c in CAND[key]:
        if c in df.columns:
            return c
    for c in CAND[key]:
        for real in df.columns:
            if c.lower() == str(real).lower():
                return real
    return None


def norm_name(s):
    """商品名归一：全角空格→半角、连续空白压一个、去首尾。"""
    if pd.isna(s):
        return ''
    s = str(s).replace('\u3000', ' ').replace('\xa0', ' ')
    return re.sub(r'\s+', ' ', s).strip()


def season_type(*texts):
    """只识别「节令」——即具体节日与节令食品。季节描述（秋冬限定/季节限定/时令）不算节令。"""
    blob = ' '.join(str(t) for t in texts if t)
    return '节令' if re.search(FESTIVAL_PAT, blob) else ''


def festival_word(*texts):
    """返回命中的第一个节日关键词，用于报告里说明归档原因。"""
    blob = ' '.join(str(t) for t in texts if t)
    m = re.search(FESTIVAL_PAT, blob)
    return m.group(0) if m else ''


def rnd(x, n=2):
    if x is None or (isinstance(x, float) and (np.isnan(x) or np.isinf(x))):
        return None
    return round(float(x), n)


def safe_div(a, b):
    return (a / b) if b else None


# ----------------------------------------------------------------------------
# 主流程
# ----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description='商品销量诊断 · 数据计算')
    ap.add_argument('--goods', required=True, nargs='+',
                    help='商品明细表，可给多个文件（如 9月.csv 10月.csv）')
    ap.add_argument('--order', nargs='+',
                    help='订单表（csv/xlsx），可给多个；用于取付款时间与支付方式')
    ap.add_argument('--sheet', help='Excel 工作表名')
    ap.add_argument('--out', default='./out', help='输出目录')
    ap.add_argument('--client', default='', help='品牌/客户名（显示在报告标题）')
    ap.add_argument('--days', type=int, default=60, help='分析窗口天数，默认 60（至少应有 56 天）')
    ap.add_argument('--min-base-qty', type=float, default=8,
                    help='基准期最少销量（件），低于此值判「数据不足」，默认 8')
    ap.add_argument('--offline-weeks', type=float, default=2,
                    help='连续多少个自然周无销量即判「已下架」（不再进入下架/观察判定），默认 2')
    ap.add_argument('--star-share', type=float, default=5,
                    help='销量明星：近一周销售额贡献占比高于此值（%%），默认 5')
    ap.add_argument('--drop-cut', type=float, default=30,
                    help='可下架/准备下架的最低跌幅（%%），默认 30')
    ap.add_argument('--drop-risk', type=float, default=20,
                    help='主力品下滑预警的最低跌幅（%%），默认 20')
    ap.add_argument('--tiny-share', type=float, default=1.0,
                    help='「金额贡献不足」的界限（%%），默认 1。准备下架的第二条路径：'
                         '近 2 周每周的「该商品当周销售额 ÷ 当周全店销售额」都低于此值，'
                         '且近 2 周销售额排名都在下四分位 —— 不看跌幅，量太小本身就该清')
    ap.add_argument('--lq', type=float, default=0.25,
                    help='下四分位界限（0—1），默认 0.25。每周在「当周有成交」的商品中按销售额排名，'
                         '分位 <= 此值即视为落在下四分位')
    ap.add_argument('--top-pct', type=float, default=0.30,
                    help='前段界限（0—1），默认 0.30。分位 >= 1-此值视为进入前 30%%')
    ap.add_argument('--evergreen-share', type=float, default=1.0,
                    help='长青款：窗口内每周都有成交，且总销售额占全店高于此值（%%），默认 1。'
                         '默认只做标签，不改变判定（排名规则已天然保护长销品）')
    ap.add_argument('--evergreen-downgrade', action='store_true',
                    help='开启后，长青款命中下架阈值时强制降级为「观察」（旧版行为）')
    ap.add_argument('--evergreen-cap', action='store_true',
                    help='关闭长青款标签')
    ap.add_argument('--new-days', type=int, default=30,
                    help='新品：首次成交距窗口末不超过此天数，默认 30')
    ap.add_argument('--baseline-days', type=int, default=28, help='基准期天数，默认 28')
    ap.add_argument('--recent-days', type=int, default=7, help='近一周天数，默认 7')
    ap.add_argument('--exclude-pay', default='',
                    help='剔除的支付方式关键词，逗号分隔。⚠️ 默认空 = 不剔除（全渠道动销）。'
                         '下架决策看的是"这款产品还有没有人买"，外卖/团购券卖出的同一款也要算；'
                         '只有当你只想看某一个渠道时才填，如 抖音券,美团券,外部支付')
    ap.add_argument('--judge-season', action='store_true',
                    help='（已废弃，保留仅为兼容旧脚本）季节限定类商品现在默认就参与判定')
    ap.add_argument('--keep-non-sale', action='store_true',
                    help='保留运费/补差价等非售卖行（默认剔除）')
    for k in ('name', 'qty', 'amt', 'price', 'cat', 'date', 'order', 'status', 'pay'):
        ap.add_argument(f'--col-{k}', help=f'{k} 列名（覆盖自动识别）')
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    log = []

    # -------- 读商品表 --------
    gd = read_tables(args.goods, args.sheet)
    log.append(f'商品明细 {len(args.goods)} 个文件：{len(gd)} 行 × {len(gd.columns)} 列')
    c_name = find_col(gd, 'name', args.col_name)
    c_qty = find_col(gd, 'qty', args.col_qty)
    c_amt = find_col(gd, 'amt', args.col_amt)
    if not (c_name and c_qty and c_amt):
        sys.exit(f'缺少必需列：商品名称={c_name} 数量={c_qty} 金额={c_amt}\n'
                 f'实际列名：{list(gd.columns)}')
    c_price = find_col(gd, 'price', args.col_price)
    c_cat = find_col(gd, 'cat', args.col_cat)
    c_date = find_col(gd, 'date', args.col_date)
    c_order = find_col(gd, 'order', args.col_order)
    c_status = find_col(gd, 'status', args.col_status)
    c_pay = find_col(gd, 'pay', args.col_pay)

    # -------- 日期来源 --------
    if c_date:
        gd['_dt'] = pd.to_datetime(gd[c_date], errors='coerce')
        date_src = f'商品表「{c_date}」'
    elif args.order and c_order:
        od = read_tables(args.order, args.sheet)
        oc_order = find_col(od, 'order', args.col_order)
        oc_date = find_col(od, 'date', args.col_date)
        oc_pay = find_col(od, 'pay', args.col_pay)
        if not (oc_order and oc_date):
            sys.exit(f'订单表需要订单号与时间列：order={oc_order} date={oc_date}｜列={list(od.columns)[:25]}')
        keep = [oc_order, oc_date] + ([oc_pay] if oc_pay else [])
        od = od[keep].drop_duplicates(oc_order)
        od['_dt'] = pd.to_datetime(od[oc_date], errors='coerce')
        if oc_pay:
            od['_pay'] = od[oc_pay].astype(str)
        gd = gd.merge(od, left_on=c_order, right_on=oc_order, how='left')
        if oc_pay:
            gd['_pay'] = gd['_pay'].fillna('')
        date_src = f'订单表「{oc_date}」（按 {c_order} 关联）'
        log.append(f'订单表 {len(args.order)} 个文件：{len(od)} 笔，已关联付款时间')
    else:
        sys.exit('商品表没有日期列、也没提供订单表 —— 无法做时间维度分析。'
                 '请加 --order 或 --col-date。')

    gd['_qty'] = pd.to_numeric(gd[c_qty], errors='coerce').fillna(0)
    gd['_amt'] = pd.to_numeric(gd[c_amt], errors='coerce').fillna(0)
    gd['_price'] = pd.to_numeric(gd[c_price], errors='coerce') if c_price else np.nan
    gd['_name'] = gd[c_name].map(norm_name)
    gd['_cat'] = gd[c_cat].astype(str).str.strip().replace('nan', '未分类') if c_cat else '未分类'

    n0 = len(gd)

    # -------- 过滤 --------
    # 0) 先标渠道（无论是否剔除，都要留一份渠道标记用于报告）
    def pay_chan(p):
        """把付款方式归到渠道，用于报告的「销量渠道构成」。"""
        s = str(p)
        if '抖音' in s or '团购' in s and '抖音' in s:
            return '抖音券'
        if '美团' in s or '点评' in s:
            return '美团券'
        if '外部支付' in s:
            return '外卖'
        if '优惠兑换' in s:
            return '兑换'
        if '赠品' in s:
            return '赠品'
        if '储值' in s:
            return '储值'
        return '小程序/门店'

    pay_col0 = '_pay' if '_pay' in gd.columns else (c_pay if c_pay else None)
    if pay_col0 and pay_col0 in gd.columns:
        gd['_chan'] = gd[pay_col0].map(pay_chan)
    else:
        gd['_chan'] = '未知'

    # 1) 支付方式（默认不剔；显式给了 --exclude-pay 才剔）
    if pay_col0 and pay_col0 in gd.columns:
        kws = [x.strip() for x in args.exclude_pay.split(',') if x.strip()]
        if kws:
            gd[pay_col0] = gd[pay_col0].astype(str)
            for kw in kws:
                before = len(gd)
                gd = gd[~gd[pay_col0].str.contains(kw, na=False)]
                log.append(f'⚠️ 已按参数剔除支付方式含「{kw}」：{before - len(gd)} 行（非全渠道口径）')
        else:
            log.append('商品动销统计口径 = 全渠道（含外卖、抖音/美团券核销、储值、赠品），未剔除任何支付方式')
    # 2) 状态（只剔全额退款）
    if c_status:
        before = len(gd)
        gd = gd[~gd[c_status].astype(str).str.contains('全额退款|已退款|退款成功', na=False)]
        if before - len(gd):
            log.append(f'剔除退款行：{before - len(gd)} 行')
    # 3) 非售卖行
    if not args.keep_non_sale:
        before = len(gd)
        gd = gd[~gd['_name'].str.contains(NON_SALE_PAT, na=False)]
        if before - len(gd):
            log.append(f'剔除非售卖行（运费/补差/来图定制等）：{before - len(gd)} 行')
    # 4) 空名 / 无效时间 / 数量异常
    gd = gd[(gd['_name'] != '') & gd['_dt'].notna() & (gd['_qty'] > 0)]
    q99 = gd['_qty'].quantile(0.999) if len(gd) else 0
    cap = max(q99, 50)
    before = len(gd)
    gd = gd[gd['_qty'] <= cap]
    if before - len(gd):
        log.append(f'剔除数量异常（>{cap:.0f} 件，疑金额错位）：{before - len(gd)} 行')
    log.append(f'清洗后 {len(gd)} 行（原始 {n0} 行）')

    if gd.empty:
        sys.exit('清洗后无有效数据，请检查列映射与过滤条件。')

    # -------- 时间窗口 --------
    gd['_date'] = gd['_dt'].dt.normalize()
    data_start, data_end = gd['_date'].min(), gd['_date'].max()
    span_days = (data_end - data_start).days + 1
    win_start = max(data_start, data_end - pd.Timedelta(days=args.days - 1))
    # 对齐到周一，避免首周只有一两天导致日均失真
    aligned = win_start - pd.Timedelta(days=win_start.weekday())
    if aligned >= data_start and (data_end - aligned).days + 1 >= 56:
        win_start = aligned
    win = gd[(gd['_date'] >= win_start) & (gd['_date'] <= data_end)].copy()

    # 全量数据的末售日（用于识别窗口内完全无成交的老品）
    full_last = gd.groupby('_name')['_date'].max()
    full_first = gd.groupby('_name')['_date'].min()
    full_qty = gd.groupby('_name')['_qty'].sum()
    full_amt = gd.groupby('_name')['_amt'].sum()

    # 周（周一起）
    win['_mon'] = win['_date'].map(lambda d: d - pd.Timedelta(days=d.weekday()))
    wks = sorted(win['_mon'].unique())
    wk_meta = []
    for m in wks:
        m = pd.Timestamp(m)
        lo = max(m, win_start)
        hi = min(m + pd.Timedelta(days=6), data_end)
        wk_meta.append(dict(
            起=str(lo.date()), 止=str(hi.date()),
            标签=f'{lo.month}/{lo.day}–{hi.month}/{hi.day}',
            短标=f'{lo.month}/{lo.day}',
            天数=max((hi - lo).days + 1, 0),
        ))
    n_weeks = len(wk_meta)

    # 近 N 天 / 近 30 天
    p_recent = data_end - pd.Timedelta(days=args.recent_days - 1)
    p_30 = data_end - pd.Timedelta(days=29)
    store_recent_amt = win.loc[win['_date'] >= p_recent, '_amt'].sum()
    store_30_amt = win.loc[win['_date'] >= p_30, '_amt'].sum()
    store_recent_qty = win.loc[win['_date'] >= p_recent, '_qty'].sum()

    wk_total_qty = [float(win.loc[win['_mon'] == m, '_qty'].sum()) for m in wks]
    wk_total_amt = [float(win.loc[win['_mon'] == m, '_amt'].sum()) for m in wks]

    # -------- 每周销售额排名分位（新判定规则的基础） --------
    # 在「当周有成交」的商品中排名：0 = 最低，1 = 最高。
    # 当周零成交 → 记为 0（视为最差；这类多半已被「连续2周零销=已下架」先拦下）。
    amt_mat = (win.pivot_table(index='_name', columns='_mon', values='_amt', aggfunc='sum')
                  .reindex(columns=wks).fillna(0.0))
    rank_pct = pd.DataFrame(0.0, index=amt_mat.index, columns=wks)
    rank_pos = pd.DataFrame(0, index=amt_mat.index, columns=wks)   # 名次，1=最高
    pool_size = {}
    for m in wks:
        col = amt_mat[m]
        nz = col[col > 0]
        pool_size[m] = int(len(nz))
        if len(nz):
            rank_pct.loc[nz.index, m] = nz.rank(pct=True, ascending=True)
            rank_pos.loc[nz.index, m] = nz.rank(ascending=False, method='min').astype(int)

    wk_pool = [pool_size[m] for m in wks]
    W3, W2 = wks[-3:], wks[-2:]
    LQ, TOP = args.lq, 1 - args.top_pct

    # 基准期：商品首次出现日（窗口内）起 baseline_days 天
    def baseline(t_first):
        b_lo = max(t_first, win_start)
        b_hi = min(b_lo + pd.Timedelta(days=args.baseline_days - 1), data_end)
        if (b_hi - b_lo).days + 1 < 14:
            # 生命周期太短，退化为「前一半」
            half = b_lo + pd.Timedelta(days=max(((data_end - b_lo).days + 1) // 2, 7))
            b_hi = min(half, data_end)
        return b_lo, b_hi

    # -------- 逐商品 --------
    rows = []
    for name, g in win.groupby('_name'):
        t_first, t_last = g['_date'].min(), g['_date'].max()
        b_lo, b_hi = baseline(t_first)
        b_days = (b_hi - b_lo).days + 1
        gb = g[(g['_date'] >= b_lo) & (g['_date'] <= b_hi)]
        gr = g[g['_date'] >= p_recent]
        g30 = g[g['_date'] >= p_30]

        b_qty, r_qty = float(gb['_qty'].sum()), float(gr['_qty'].sum())
        b_amt, r_amt = float(gb['_amt'].sum()), float(gr['_amt'].sum())
        a30 = float(g30['_amt'].sum())
        b_daily, r_daily = safe_div(b_qty, b_days), safe_div(r_qty, args.recent_days)
        drop = None
        if b_daily and r_daily is not None and b_daily > 0:
            drop = rnd((r_daily - b_daily) / b_daily * 100, 1)

        # 周序列
        wq, wa = [], []
        for m in wks:
            sub = g[g['_mon'] == m]
            wq.append(int(sub['_qty'].sum()))
            wa.append(rnd(float(sub['_amt'].sum()), 0))
        wshare = [rnd(safe_div(a, t) * 100 if safe_div(a, t) is not None else 0, 2)
                  for a, t in zip(wa, wk_total_amt)]

        share7 = rnd(safe_div(r_amt, store_recent_amt) * 100, 2)
        share30 = rnd(safe_div(a30, store_30_amt) * 100, 2)
        b_amt_d = safe_div(b_amt, b_days)
        r_amt_d = safe_div(r_amt, args.recent_days)
        gap = rnd(max((b_amt_d or 0) - (r_amt_d or 0), 0) * 30, 0)   # 月销量缺口（金额）

        # 每周销售额排名分位（供新规则使用）
        pct_all = [float(rank_pct.loc[name, m]) for m in wks]
        pos_all = [int(rank_pos.loc[name, m]) for m in wks]
        pct3 = [float(rank_pct.loc[name, m]) for m in W3]
        pct2 = [float(rank_pct.loc[name, m]) for m in W2]

        # 渠道构成（件数与占比，供报告说明"这个商品的量从哪来"）
        ch_qty = g.groupby('_chan')['_qty'].sum()
        ch_total = float(ch_qty.sum()) or 1.0
        chan_mix = {k: dict(件数=int(v), 占比=rnd(v / ch_total * 100, 1))
                    for k, v in ch_qty.sort_values(ascending=False).items() if v > 0}

        # 长青款判定素材：有成交的周数 / 窗口总周数
        wk_alive = sum(1 for x in wq if x > 0)
        total_amt_all = float(g['_amt'].sum())

        # 连续零销周：从最后一个周段往前数连续 0 销量的周段数
        zero_weeks = 0
        for v in reversed(wq):
            if v == 0:
                zero_weeks += 1
            else:
                break

        # 上架天数：用全量数据的首次成交日（早于窗口起点时以全量为准）
        g_first = full_first.get(name, t_first)
        age = int((data_end - g_first).days)
        off = int((data_end - t_last).days)

        cat = g['_cat'].mode().iat[0] if len(g['_cat'].mode()) else '未分类'
        stype = season_type(cat, name)
        star = bool(share7 is not None and share7 > args.star_share)
        # 新品：上架 ≤ N 天、仍在售；节令（节日）商品单列，不重复计入新品
        new = bool(age <= args.new_days and zero_weeks < args.offline_weeks
                   and off < 14 and stype != '节令')
        tags = (['销量明星'] if star else []) + (['新品'] if new else [])

        price = float(g['_price'].mean()) if g['_price'].notna().any() else None

        rows.append(dict(
            商品=name, 分类=cat,
            均价=rnd(price, 1),
            总件数=int(g['_qty'].sum()), 总金额=rnd(g['_amt'].sum(), 0),
            首售=str(g_first.date()), 末售=str(t_last.date()),
            上架天数=age, 距末售=off, 连续零销周=zero_weeks,
            基准期起始=str(b_lo.date()), 基准期天数=b_days, 基准期件数=int(b_qty),
            基准期日均=rnd(b_daily, 2),
            近期件数=int(r_qty), 近期日均=rnd(r_daily, 2),
            变化=drop,
            近周占比=share7, 近30天占比=share30,
            近7天金额=rnd(r_amt, 0), 近30天金额=rnd(a30, 0),
            缺口金额=gap,
            周销量=wq, 周金额=wa, 周占比=wshare,
            周分位=[rnd(x, 4) for x in pct_all],
            周名次=pos_all,
            近3周分位=[rnd(x, 4) for x in pct3],
            近2周分位=[rnd(x, 4) for x in pct2],
            渠道构成=chan_mix,
            在售周数=wk_alive, 总周数=len(wq),
            季节类型=stype,
            节日词=festival_word(cat, name),
            近30天件数=int(g30['_qty'].sum()),
            零成交=(int(r_qty) == 0),
            是明星=star, 是新品=new, 标签=tags,
            明星分=(2 if star else 0) + (1 if new else 0),
        ))

    # 补：窗口内完全无成交、但历史有售的商品（统一按「已下架」处理）
    seen = {r['商品'] for r in rows}
    for name in full_last.index:
        if name in seen:
            continue
        t_last = full_last[name]
        t_first = full_first[name]
        cat_series = gd.loc[gd['_name'] == name, '_cat']
        cat = cat_series.mode().iat[0] if len(cat_series.mode()) else '未分类'
        price = gd.loc[gd['_name'] == name, '_price']
        rows.append(dict(
            商品=name, 分类=cat,
            均价=rnd(float(price.mean()), 1) if price.notna().any() else None,
            总件数=int(full_qty[name]), 总金额=rnd(full_amt[name], 0),
            首售=str(t_first.date()), 末售=str(t_last.date()),
            上架天数=int((data_end - t_first).days),
            距末售=int((data_end - t_last).days),
            连续零销周=len(wks),
            基准期起始=str(win_start.date()), 基准期天数=0, 基准期件数=0,
            基准期日均=0.0, 近期件数=0, 近期日均=0.0, 变化=None,
            近周占比=0.0, 近30天占比=0.0, 近7天金额=0.0, 近30天金额=0.0, 缺口金额=0.0,
            周销量=[0] * len(wks), 周金额=[0.0] * len(wks), 周占比=[0.0] * len(wks),
            周分位=[0.0] * len(wks), 周名次=[0] * len(wks),
            近3周分位=[0.0] * len(W3), 近2周分位=[0.0] * len(W2),
            渠道构成={},
            在售周数=0, 总周数=len(wks),
            季节类型=season_type(cat, name),
            节日词=festival_word(cat, name),
            近30天件数=0, 零成交=True, 窗口内无成交=True,
            是明星=False, 是新品=False, 标签=[], 明星分=0,
        ))

    df = pd.DataFrame(rows)
    # 补齐布尔列（pandas 会把缺失键填 NaN，而 NaN 在 if 里是真值 → 必须显式转 bool）
    for bcol in ('窗口内无成交', '零成交', '是明星', '是新品'):
        if bcol not in df.columns:
            df[bcol] = False
        df[bcol] = df[bcol].fillna(False).astype(bool)
    for ncol in ('连续零销周', '上架天数', '距末售', '在售周数', '总周数'):
        df[ncol] = pd.to_numeric(df[ncol], errors='coerce').fillna(0).astype(int)

    # -------- 长青款：窗口内每周都有成交 + 全窗口销售占比达标 --------
    # 逻辑：这类商品是货盘骨架，单周回落不足以支撑下架决策，必须放到更长周期里看
    store_total_amt = float(df['总金额'].sum()) or 1.0
    df['全窗口占比'] = (df['总金额'] / store_total_amt * 100).round(2)
    df['每周有成交'] = df['在售周数'] == df['总周数']
    df['是长青款'] = (df['每周有成交']
                  & (df['全窗口占比'] >= args.evergreen_share)
                  & (~df['窗口内无成交']))
    if args.evergreen_cap:
        df['是长青款'] = False

    # 长青款并入标签（与判定并列显示）
    def merge_tags(r):
        tags = list(r['标签'] or [])
        if bool(r['是长青款']) and '长青款' not in tags:
            tags.insert(0, '长青款') if not tags else tags.append('长青款')
        return tags
    df['标签'] = df.apply(merge_tags, axis=1)

    # -------- 判定 --------
    MIN_SPAN = 56
    span_ok = span_days >= MIN_SPAN

    OFF_W = args.offline_weeks

    def is_offline(r):
        """连续 N 周无销量（或整个窗口无成交）→ 已下架，不再进入下架/观察判定。"""
        return (r['连续零销周'] >= OFF_W) or (r['距末售'] >= int(OFF_W * 7)) or bool(r['窗口内无成交'])

    def judge(r):
        """返回 (判定, 判定依据)。依据只对「可以下架 / 准备下架」有意义，用于证据卡。"""
        # 节令（具体节日）商品：统一归入「节令商品·可归档」，不参与下架判定
        if r['季节类型'] == '节令':
            return '节令商品·可归档', ''
        down = is_offline(r)
        # 规则一：连续 2 周无销量 → 已下架
        if down:
            return '已下架', ''
        if r['基准期天数'] < 14 or r['基准期件数'] < args.min_base_qty:
            return '数据不足', ''
        d = r['变化']
        if d is None:
            return '数据不足', ''
        decline = -d
        p3 = r['近3周分位']
        p2 = r['近2周分位']
        # 「在下四分位」= 该周销售额排名分位 <= LQ；「在前 30%」= 分位 >= TOP
        lq3 = all(x <= LQ for x in p3)
        lq2 = all(x <= LQ for x in p2)
        top2 = all(x >= TOP for x in p2)
        evergreen = bool(r['是长青款'])

        # 近 2 周每周的「金额贡献」= 该商品当周销售额 ÷ 当周全店销售额（%）。
        # 这是与周排名同一个池子的绝对量维度：排名说「你在同周排第几」，占比说「你到底占多少」。
        sh2 = [float(x or 0) for x in (r['周占比'] or [])][-2:]
        tiny2 = len(sh2) >= 2 and all(x < args.tiny_share for x in sh2)
        sh_txt = ' / '.join(f'{x:.2f}' for x in sh2)

        # 规则二：跌幅 + 近 N 周销售额排名分位，按顺序命中即止
        # 注：近3周都在下四分位 ⊂ 近2周都在下四分位，所以先判 3 周
        if decline >= args.drop_cut and lq3:
            if evergreen and args.evergreen_downgrade:
                return '观察', ''
            return '可以下架', f'跌幅 {decline:.1f}% · 近 3 周销售额排名都在下四分位'
        # 准备下架 = 二选一：① 跌幅达标 + 近 2 周垫底；② 近 2 周垫底 + 每周金额贡献都极小
        if lq2 and (decline >= args.drop_cut or tiny2):
            if evergreen and args.evergreen_downgrade:
                return '观察', ''
            if decline >= args.drop_cut and tiny2:
                why = f'跌幅 {decline:.1f}%，且近 2 周单周金额贡献 {sh_txt}% 均 < {args.tiny_share}%'
            elif decline >= args.drop_cut:
                why = f'跌幅 {decline:.1f}%'
            else:
                why = f'近 2 周单周金额贡献 {sh_txt}% 均 < {args.tiny_share}%，量太小'
            return '需消耗原料·准备下架', why + ' · 近 2 周销售额排名都在下四分位'
        if decline > args.drop_risk and top2:
            return '主力品下滑预警', ''
        if decline >= 15:
            return '观察', ''
        return '正常', ''

    _j = df.apply(judge, axis=1)
    df['判定'] = [x[0] for x in _j]
    df['判定依据'] = [x[1] for x in _j]

    def off_reason(r):
        if bool(r['窗口内无成交']):
            return '整个窗口无成交'
        if r['连续零销周'] >= OFF_W:
            return f"连续 {int(r['连续零销周'])} 周无销量"
        return f"连续 {int(r['距末售'])} 天无成交"

    df['下架原因'] = df.apply(lambda r: off_reason(r) if r['判定'] in ('已下架',) else '', axis=1)

    # -------- 分类汇总 --------
    def cat_agg():
        out = []
        for cat, g in win.groupby('_cat'):
            if float(g['_amt'].sum()) <= 0 and float(g['_qty'].sum()) <= 0:
                continue
            b = g[g['_date'] < p_recent]
            r = g[g['_date'] >= p_recent]
            bd = (p_recent - win_start).days or 1
            out.append(dict(
                分类=cat, 商品数=int(g['_name'].nunique()),
                件数=int(g['_qty'].sum()), 金额=rnd(g['_amt'].sum(), 0),
                基准日均=rnd(safe_div(float(b['_qty'].sum()), bd), 2),
                近期日均=rnd(safe_div(float(r['_qty'].sum()), args.recent_days), 2),
            ))
        o = pd.DataFrame(out)
        if o.empty:
            return []
        o['变化'] = o.apply(
            lambda r: rnd((r['近期日均'] / r['基准日均'] - 1) * 100, 1) if r['基准日均'] else None, axis=1)
        return o.sort_values('件数', ascending=False).to_dict('records')

    alive = (df['连续零销周'] < OFF_W) & (df['距末售'] < int(OFF_W * 7)) & (~df['窗口内无成交'])

    payload = dict(
        元信息=dict(
            客户=args.client,
            数据区间=[str(win_start.date()), str(data_end.date())],
            原始区间=[str(data_start.date()), str(data_end.date())],
            跨度天数=int(span_days), 窗口天数=args.days, 数据充足=span_ok,
            日期来源=date_src,
            商品数=int(len(df)), 总件数=int(df['总件数'].sum()),
            总金额=rnd(df['总金额'].sum(), 0),
            周标签=[w['标签'] for w in wk_meta],
            周短标=[w['短标'] for w in wk_meta],
            周天数=[w['天数'] for w in wk_meta],
            周起日=[w['起'] for w in wk_meta],
            全店周件数=[int(x) for x in wk_total_qty],
            全店周金额=[rnd(x, 0) for x in wk_total_amt],
            近7天起=str(p_recent.date()), 近30天起=str(p_30.date()),
            近7天店金额=rnd(store_recent_amt, 0), 近30天店金额=rnd(store_30_amt, 0),
            近7天店件数=int(store_recent_qty),
            基准期天数=args.baseline_days, 近周天数=args.recent_days,
            门槛件数=args.min_base_qty,
            下架周数=OFF_W, 下架天数=int(OFF_W * 7),
            明星占比=args.star_share, 新品天数=args.new_days,
            在售数=int(alive.sum()),
            已下架数=int((~alive).sum()),
            明星数=int(df['是明星'].sum()),
            新品数=int(df['是新品'].sum()),
            长青数=int(df['是长青款'].sum()),
            长青占比门槛=args.evergreen_share,
            周池大小=wk_pool,
            下四分位界限=round(args.lq * 100, 1),
            前段界限=round(args.top_pct * 100, 1),
            跌幅门槛=args.drop_cut,
            风险跌幅门槛=args.drop_risk,
            金额贡献门槛=args.tiny_share,
            近3周范围=[str(W3[0])[:10], str(W3[-1])[:10]] if W3 else [],
            近2周范围=[str(W2[0])[:10], str(W2[-1])[:10]] if W2 else [],
            日志=log,
        ),
        分类=cat_agg(),
        商品=df.to_dict('records'),
    )

    jp = os.path.join(args.out, '诊断数据.json')
    json.dump(payload, open(jp, 'w', encoding='utf-8'), ensure_ascii=False, default=str)
    print(f'✅ 数据：{jp}')
    print(f'   窗口 {win_start.date()} – {data_end.date()}（{len(wk_meta)} 周，跨度 {span_days} 天）')
    print(f'   商品 {len(df)} / 件数 {int(df["总件数"].sum())} / 金额 {df["总金额"].sum():,.0f}')
    print('   判定分布：' + '  '.join(f'{k}={v}' for k, v in df['判定'].value_counts().items()))
    if not span_ok:
        print(f'   ⚠️ 数据跨度仅 {span_days} 天，不足 2 个月（{MIN_SPAN} 天），判定结果仅供参考')
    return jp


if __name__ == '__main__':
    main()
